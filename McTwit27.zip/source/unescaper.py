#!/usr/bin/env python

'''
Script para unescape de caracteres especiais ISO-8859-1
Autor: Mayron Cachina
Contato: mayroncachina@gmail.com
Site: http://cachina.wordpress.com

Egg mantainer & unescape digits
Autor: Vsevolod Balashov
mail/xmpp: vsevolod@balashov.name
site: http://vsevolod.balashov.name
'''

import htmlentitydefs, re

_char = re.compile(ur'&(\w+?);', re.UNICODE)
_dec  = re.compile(ur'&#(\d{2,4});', re.UNICODE)
_hex  = re.compile(ur'&#x(\d{2,4});', re.UNICODE)

import locale

sDefaultEncoding = locale.getdefaultlocale()[1]

def StrDefault(sText): return sText.encode(sDefaultEncoding, 'ignore')

def utf16str(sText):
    if sText == None: return''
    # elif isinstance(sText, bool) or isinstance(sText, int): return utf16str(sText)
    elif isinstance(sText, unicode): return unicode(sText)
    # elif isinstance(sText, str): return unicode(sText, sDefaultEncoding, 'ignore')
    elif isinstance(sText, str): return unicode(sText, 'utf-8', 'ignore')
    else: return unicode(sText)

def utf8str(sText): return utf16str(sText).encode('utf-8', 'ignore')

def utf8urlencode(l): return urllib.urlencode([(utf8str(k), utf8str(v)) for k, v in dict(l).items()])

def _char_unescape(m, defs=htmlentitydefs.entitydefs):
    try:
        return defs[m.group(1)]
    except KeyError:
        return m.group(0)

def old_unescape(string):
    """back replace html-safe sequences to special characters
        >>> unescape('&lt; &amp; &gt;')
        '< & >'
        >>> unescape('&#39;')
        "'"
        >>> unescape('&#x27;')
        "'"
    
    full list of sequences: htmlentitydefs.entitydefs
    """
    # string = utf8str(string)
    string = utf16str(string)
    try: result = _hex.sub(lambda x: unichr(int(x.group(1), 16)),\
        _dec.sub(lambda x: unichr(int(x.group(1))),\
            _char.sub(_char_unescape, string)))
    except: print 'Unescape error from: ' + StrDefault(string); return string
    return utf16str(result)
    if string.__class__ != unicode:
        # return result.encode('utf-8')
        print 64
        return result.encode('utf-8', 'ignore')
    else:
        return result


# Removes HTML markup from a text string.
# @param text The HTML source.
# @return The plain text.  If the HTML source contains non-ASCII
#     entities or character references, this is a Unicode string.

def strip_html(text):
    def fixup(m):
        text = m.group(0)
        if text[:1] == "<":
            return "" # ignore tags
        if text[:2] == "&#":
            try:
                if text[:3] == "&#x":
                    return unichr(int(text[3:-1], 16))
                else:
                    return unichr(int(text[2:-1]))
            except ValueError:
                pass
        elif text[:1] == "&":
            import htmlentitydefs
            entity = htmlentitydefs.entitydefs.get(text[1:-1])
            if entity:
                if entity[:2] == "&#":
                    try:
                        return unichr(int(entity[2:-1]))
                    except ValueError:
                        pass
                else:
                    return unicode(entity, "iso-8859-1")
        return text # leave as is
    return re.sub("(?s)<[^>]*>|&#?\w+;", fixup, text)

# Removes HTML or XML character references and entities from a text string.
# @param text The HTML (or XML) source text.
# @return The plain text, as a Unicode string, if necessary.

def unescape(text):
    # print 108
    def fixup(m):
        text = m.group(0)
        if text[:2] == "&#":
            # character reference
            try:
                if text[:3] == "&#x":
                    return unichr(int(text[3:-1], 16))
                else:
                    return unichr(int(text[2:-1]))
            except ValueError:
                pass
        else:
            # named entity
            try:
                text = unichr(htmlentitydefs.name2codepoint[text[1:-1]])
            except KeyError:
                pass
        return text # leave as is
    return re.sub("&#?\w+;", fixup, text)

__all__ = ['unescape']

"""
if __name__ == "__main__":
    import doctest
    doctest.testmod()
else:
    __import__('pkg_resources').declare_namespace(__name__)
"""
