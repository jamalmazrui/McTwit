# SayTools
# Copyright 2008 - 2009 by Jamal Mazrui
# LGPL license

# import wmi
import locale
import wx
import comtypes.client
import comtypes
import ctypes
# import EasyDialogs
import getpass
import lbc
import msvcrt
import os
# import pyAA
# import pySonic
import shutil
import sys
# import readline
import textwrap
import time
import urllib
import win32api
import win32com.client
import win32con
import win32console
import win32gui
#import win32ui
import wx

sDir = os.path.curdir
os.chdir(sys.prefix)
# import pyTTS
os.chdir(sDir)

JFWAPI = None
JFWSayString = None
SAAPI32 = ctypes.windll.SAAPI32
SA_IsRunning = SAAPI32.SA_IsRunning
SA_SayU = SAAPI32.SA_SayU

def StrDefault(text): return text.encode(locale.getdefaultlocale()[1])

class SayTools:

	_reg_class_spec_ = 'SayTools.SayTools'
	_reg_clsid_ = '{8FCBA431-CD41-45FD-8D2F-50693A271D31}'
	_reg_progid_ = 'Say.Tools'
	_reg_desc_ = 'Say Tools COM server'
	_public_methods_ = ['ActivateWindow', 'Exec', 'Eval', 'IsJAWSActive', 'IsSAActive', 'IsWEActive', 'JAWSSay', 'JAWSSilence', 'JAWSRunScript', 'JAWSRunFunction', 'SASay', 'SAPISay', 'SAPIWriteWAV', 'SAPIGetVoices', 'WESay', 'Say', 'PlaySample', 'PlayStream', 'ReadFile', 'WriteFile', 'MSAAGetTree', 'MessageBox', 'ConsoleSetTitle', 'ConsoleMaximizeWindow', 'ConsoleReadLine', 'ConsoleReadPassword', 'ConsoleWrite', 'ConsoleWriteLine', 'ConsoleClearScreen', 'ConsoleIsCharacterWaiting', 'ConsoleReadCharacter', 'WrapText', 'UrlToFile', 'DialogBrowseForFolder', 'DialogChoose', 'DialogConfirm', 'DialogInput', 'DialogMemo', 'DialogMultiInput', 'DialogMultiPick', 'DialogOpenFile', 'DialogPick', 'DialogSaveFile', 'DialogShow']
	_public_attrs_ = ['UseSAPIAsBackup', 'SAPIVoice', 'SAPIRate', 'SAPIVolume']

	def __init__(self):
		global JFWAPI, JFWSayString

		sPath = self.GetExecutablePath('JFW.exe')
		sPath = sPath[:-8]
		# print 'sPath', sPath
		sDLL = os.path.join(sPath, 'jfwapi.dll')
		JFWAPI = ctypes.windll.LoadLibrary(sDLL)
		JFWSayString = JFWAPI.JFWSayString

		self.UseSAPIAsBackup = False
		self.SAPIVoice = ''
		self.SAPIRate = 0
		self.SAPIVolume = 50
		app = wx.GetApp()

	def ActivateWindow(self, hWindow=0):
		return lbc.ActivateWindow(hWindow)
		
	def Exec(self, sCode, v1 = None, v2 = None, v3 = None, v4 = None):
		try:
			exec(sCode)
		except:
			pass

	def Eval(self, sCode, v1 = None, v2 = None, v3 = None, v4 = None):
		aLines = sCode.rstrip().splitlines()
		try:
			if len(aLines) > 1: exec('\n'.join(aLines[0:-1]))
			sLine = aLines[len(aLines) - 1]
			vReturn = eval(sLine)
		except:
			vReturn = None
		return vReturn

	def IsJAWSActive(self):
		sClass = 'JFWUI2'
		sTitle = 'JAWS'
		try:
			h = win32gui.FindWindow(sClass, sTitle)
		except:
			h = 0
		return h

	def IsSAActive(self):
		return SA_IsRunning()
	
	def IsWEActive(self):
		sClass = 'GWMExternalControl'
		sTitle = 'External Control'
		try:
			h = win32gui.FindWindow(sClass, sTitle)
		except:
			h = 0
		return h

	def JAWSSay(self, sText):
		iInterrupt = 0
		iResult = JFWSayString(StrDefault(sText), iInterrupt)
		# print 'result', iResult
		return iResult
		oJFW = win32com.client.Dispatch('FreedomSci.JawsApi')
		# oJFW = comtypes.client.CreateObject('FreedomSci.JawsApi')
		iResult = oJFW.SayString(unicode(sText), iInterrupt)
		oJFW = None
		return iResult
	
	def JAWSSilence(self):
		oJFW = win32com.client.Dispatch('FreedomSci.JawsApi')
		iResult = oJFW.StopSpeech()
		oJFW = None
		return iResult
	
	def JAWSRunScript(self, sScript):
		oJFW = win32com.client.Dispatch('FreedomSci.JawsApi')
		iResult = oJFW.RunScript(str(sScript))
		oJFW = None
		return iResult

	def JAWSRunFunction(self, sFunction):
		oJFW = win32com.client.Dispatch('FreedomSci.JawsApi')
		iResult = oJFW.RunFunction(str(sFunction))
		oJFW = None
		return iResult

	def SASay(self, sText):
		return SA_SayU(unicode(sText))
	
	def OldSAPISay(self, sText):
		oSAPI = win32com.client.Dispatch('SAPI.SPVoice')
		oSAPI.Speak(sText)
		oSAPI = None
	
	def SAPICreate(self):
		sName = 'C866CA3A-32F7-11D2-9602-00C04F8EE628x0x5x0.pyc'
		sSource = os.path.join(sys.prefix, sName)
		sTarget = os.path.join(os.path.curdir, sName)
		win32api.CopyFile(sSource, sTarget)
		reload(pyTTS)
		oTTS = pyTTS.Create()
		win32api.DeleteFile(sTarget)
		return oTTS

	def SAPISay(self, sText):
		oTTS = pyTTS.Create()
		if self.SAPIVoice in oTTS.GetVoiceNames(): oTTS.SetVoiceByName(self.SAPIVoice)
		oTTS.Rate = self.SAPIRate
		oTTS.Volume = self.SAPIVolume
#		oTTS.Speak(sText, pyTTS.tts_async)
		oTTS.Speak(sText)
		oTTS = None
	
	def SAPIWriteWAV(self, sFile, sText):
		oTTS = pyTTS.Create()
		if self.SAPIVoice in oTTS.GetVoiceNames(): oTTS.SetVoiceByName(self.SAPIVoice)
		oTTS.Rate = self.SAPIRate
		oTTS.Volume = self.SAPIVolume
		oTTS.SpeakToWave(sFile, sText)
		oTTS = None
	
	def SAPIGetVoices(self):
		oTTS = pyTTS.Create()
		sVoices = '\n'.join(oTTS.GetVoiceNames())
		oTTS = None
		return sVoices

	def WESay(self, sText):
		oWE = win32com.client.Dispatch('GWSpeak.Speak')
		# oWE = comtypes.client.CreateObject('GWSpeak.Speak')
		oWE.SpeakString(unicode(sText))
		oWE = None
	
	def Say(self, sText):
		bReturn = False
		if self.IsJAWSActive(): bReturn = self.JAWSSay(sText)
		if not bReturn and self.IsWEActive(): bReturn = self.WESay(sText)
		if not bReturn and self.IsSAActive(): bReturn = self.SASay(sText)
		if not bReturn and self.UseSAPIAsBackup: bReturn = self.SAPISay(sText)
		return bReturn
		
	def OldUseSAPI(self, bState):
		bOldState = self.UseSAPIAsBackup
		self.UseSAPIAsBackup = bState
		return bOldState
		
	def PlaySample(self, sWAV, bWait = True):
		oWorld = pySonic.World()
		oSource = pySonic.Source()
		oSource.Sound = pySonic.FileSample(sWAV)
		oSource.Play()
		if not bWait: return
		while oSource.IsPlaying(): time.sleep(0.5)
		oSource = None
		oWorld = None
		
	def PlayStream(self, sMP3, bWait = True):
		oWorld = pySonic.World()
		oSource = pySonic.Source()
		oSource.Sound = pySonic.FileStream(sMP3)
		oSource.Play()
		if not bWait: return
		while oSource.IsPlaying(): time.sleep(0.5)
		oSource = None
		oWorld = None

	def ReadFile(self, sFile):
		try:
			oFile = open(sFile, 'ru')
			sText = oFile.read()
			oFile.close()
		except:
			sText = ''
		return sText

	def WriteFile(self, sFile, sText):
		try:
			oFile = open(sFile, 'wu')
			oFile.write(sText)
			oFile.close()
		except:
			pass

	def ProcessMSAA(self, oParent, sOutline):
		sReturn = '\n' + sOutline + '\n'
		for sProperty in ['RoleText', 'Name', 'Value', 'Description', 'KeyboardShortcut', 'Location', 'Selection', 'StateText', 'Window', 'ChildCount']:
			try:
				sResult = str(eval('oParent.' + sProperty)).strip()
			except:
				sResult = ''
			if len(sResult) > 0 and sResult != 'None' and sResult != '0' and sResult != '[]': sReturn = sReturn + sProperty + ': ' + sResult + '\n'
	
		oChildren = oParent.Children
		if oChildren != None and len(oChildren) > 0:
			for i in range(len(oChildren)): sReturn = sReturn + self.ProcessMSAA(oChildren[i], sOutline + '.' + str(i + 1))
#		print sReturn
		return sReturn
	
	def MSAAGetTree(self, hWindow = win32gui.GetForegroundWindow()):
		try:
			oAccessible = pyAA.AccessibleObjectFromWindow(hWindow, -4) # OBJID_Client
			sReturn = self.ProcessMSAA(oAccessible, '1')
		except:
			sReturn = ''
		return sReturn

	def MessageBox(self, sText, sTitle = 'Show'):
		win32gui.MessageBox(0, sText, sTitle, 0)

	def ConsoleSetTitle(self, sTitle) :
		win32console.SetConsoleTitle(sTitle)

	def ConsoleMaximizeWindow(self) :
		hWindow = win32console.GetConsoleWindow()
		win32gui.ShowWindow(hWindow, win32con.SW_SHOWMAXIMIZED)

	def ConsoleReadLine(self, sPrompt) :
		return raw_input(sPrompt)
		rl = readline.rlmain.Readline()
		return rl.readline(sPrompt)

	def ConsoleReadPassword(self, sPrompt) :
		return getpass.getpass(str(sPrompt))

	def ConsoleWrite(self, sText) :
		print(sText)

	def ConsoleWriteLine(self, sLine) :
		self.ConsoleWrite(sLine + '\n')

	def ConsoleClearScreen(self) :
		os.system('cls')

	def ConsoleIsCharacterWaiting(self):
		return msvcrt.kbhit()

	def ConsoleGetCharacter(self):
		return msvcrt.getche()

	def DialogBrowseForFolder(self, sMessage='', sPath=''):
		v1 = sMessage
		v2 = sPath
		sCode = 'lbc.DialogBrowseForFolder(message=v1, value=v2)'
		sResult = self.Eval(sCode, v1, v2)
		return sResult

	def DialogChoose(self, sTitle='Pick', sMessage='', sNames=''):
		v1 = sTitle
		v2 = sMessage
		v3 = sNames.split('\v')
		sCode = 'lbc.DialogChoose(title=v1, message=v2, names=v3)'
		sResult = self.Eval(sCode, v1, v2, v3)
		return sResult

	def DialogConfirm(self, sTitle = '', sMessage = '', sValue=''):
		v1 = sTitle
		v2 = sMessage
		v3 = sValue
		sCode = 'lbc.DialogConfirm(title=v1, message=v2, value=v3)'
		sResult = self.Eval(sCode, v1, v2, v3)
		return sResult

	def DialogInput(self, sTitle='Input', sLabel='', sValue=''):
		v1 = sTitle
		v2 = sLabel
		v3 = sValue
		sCode = 'lbc.DialogInput(title=v1, label=v2, value=v3)'
		sResult = self.Eval(sCode, v1, v2, v3)
		return sResult

	def DialogMemo(self, sTitle='Input', sLabel='', sValue='', bReadOnly=False):
		v1 = sTitle
		v2 = sLabel
		v3 = sValue
		v4 = bReadOnly
		sCode = 'lbc.DialogMemo(title=v1, label=v2, value=v3, readonly=v4)'
		sResult = self.Eval(sCode, v1, v2, v3)
		return sResult

	def DialogMultiInput(self, sTitle = '', sLabels='', sValues='', sOptions=''):
		v1 = sTitle
		v2 = sLabels.split('\v')
		v3 = sValues.split('\v')
		v4 = sOptions.split('\v')
		sCode = 'lbc.DialogMultiInput(title=v1, labels=v2, values=v3, options=v4)'
		#print 'code:', '\n', sCode
		lResults = self.Eval(sCode, v1, v2, v3, v4)
		sResults = '\v'.join(lResults)
		return sResults

	def DialogMultiPick(self, sTitle='Multi Pick', sMessage='', sNames='', sValues='', bSort=False, iIndex=0):
		v1 = sTitle
		v2 = sNames.split('\v')
		v3 = sValues.split('\v')
		v4 = bSort
		sCode = 'lbc.DialogMultiPick(title=v1, names=v2, values=v3, sort=v4)'
		lResults = self.Eval(sCode, v1, v2, v3, v4)
		sResults = '\v'.join(lResults)
		return sResults

	def DialogOpenFile(self, sMessage='', sPath=''):
		v1 = sMessage
		v2 = sPath
		sCode = 'lbc.DialogOpenFile(message=v1, value=v2)'
		sResult = self.Eval(sCode, v1, v2)
		return sResult

	def DialogPick(self, sTitle='Pick', sMessage='', sNames='', sValues='', bSort=False, iIndex=0):
		v1 = sTitle
		v2 = sNames.split('\v')
		v3 = sValues.split('\v')
		v4 = bSort
		sCode = 'lbc.DialogPick(title=v1, names=v2, values=v3, sort=v4)'
		sResult = self.Eval(sCode, v1, v2, v3, v4)
		return sResult

	def DialogSaveFile(self, sMessage='', sPath=''):
		v1 = sMessage
		v2 = sPath
		sCode = 'lbc.DialogSaveFile(message=v1, value=v2)'
		sResult = self.Eval(sCode, v1, v2)
		return sResult

	def DialogShow(self, sTitle = '', sMessage = ''):
		v1 = sTitle
		v2 = sMessage
		sCode = 'lbc.DialogShow(title=v1, message=v2)'
		self.Eval(sCode, v1, v2)

	def WrapText(sText='', iWidth=70):
		return '\r\n'.join(textwrap.wrap(sText, iWidth))

	def UrlToFile(sUrl='', sFile=''):
		if os.isfile(sFile): 		win32api.DeleteFile(sFile)
		urllib.urlretrieve(sUrl, sFile)
		return os.isfile(sFile)

	def GetExecutablePath(self, exe):
		sName = exe
		if sName.find('.') == -1: sName += '.exe'
		sComputer = '.'
		oWMIService = win32com.client.GetObject(r'winmgmts:' + r'{impersonationLevel=impersonate}!\\' + sComputer  + r'\root\cimv2')
		sQuery = "select name,ProcessID, ExecutablePath from win32_process where name='" + sName + "'"
		oProcesses = oWMIService.ExecQuery(sQuery)
		
		sPath = ''
		for oProcess in oProcesses: sPath = oProcess.ExecutablePath; break
		return sPath
		
	def old_GetExecutablePath(self, exe):
		oWMI = wmi.WMI(find_classes=False)
		lProcesses = oWMI.Win32_Process(['ExecutablePath', 'Caption', 'ProcessID'], Name=exe)
		if lProcesses: return lProcesses[0].ExecutablePath
		else: return ''

	def __del__(self):
		app = wx.GetApp()
		if app: app.Destroy()

# Main routine
if __name__=='__main__':
	import pythoncom,win32com.server.register
	SayTools._reg_clsid=pythoncom.CreateGuid()
	win32com.server.register.UseCommandLine(SayTools)

# oST = SayTools()sCode = 'ctypes.windll.URLMon.URLDownloadToFileA(0, v1, v2, 0, 0)'
# v1 = r'http://EmpowermentZone.com/appstamp.ini'
# v2 = r'C:\Program Files\SayTools\Samples\download.tmp'
# vReturn = oST.Eval(sCode, v1, v2, '', '')
# print vReturn

#oST = SayTools()
#sCode = oST.ReadFile(r'c:\saytools\samples\hello.py')
#print sCode
#oST.Exec(sCode, 0, 0, 0, 0)

#oST = SayTools()
#sText = 'Hello world'
#sFile  = 'test.wav'
#for sVoice in oST.SAPIGetVoices().split('\n'):
#	oST.SAPIVoice = sVoice
#	oST.SAPIWriteWAV(sFile, sText)
#oST.PlaySample(sFile, True)
#print oST.SAPIGetVoices()

#oST = SayTools()
#h = win32gui.GetForegroundWindow()
#h = 197390
#sText = oST.MSAAGetTree(h)
#print sText

#oST = SayTools()
#oST.ConsoleSetTitle('SayTools Demo')
#oST.ConsoleMaximizeWindow()
#sText = oST.ConsoleReadLine('Input:')
#sText = oST.ConsoleReadPassword('Password:')
#oST.ConsoleWriteLine('line is ' + sText)
#oST.ConsoleClearScreen()
#sText = oST.ConsoleReadLine('after cls')

#oST = SayTools()
#sFile = r'C:\SayTools\DialogInput.py'
#sCode = oST.ReadFile(sFile)
#sResult = oST.Eval(sCode, 'Test Title', 'Test label', 'test value')
#print 'Result=', sResult

'''
oST = SayTools()
sLabels = 'Field1\vField2\vField3'
sValues = 'Value1\vValue2\vValue3'
sResults = oST.DialogMultiInput(' multi input', sLabels, sValues)
print 'Result=', sResults

oST = SayTools()
oST.ActivateWindow(131804)
'''