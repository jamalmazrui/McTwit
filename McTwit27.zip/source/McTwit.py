"""
McTwit
Version 2.7
March 7, 2010
Copyright 2009 - 2010 by Jamal Mazrui
Lesser General Public License (LGPL)
"""

import wx
# import pywinauto
from pywinauto import findwindows
import glob, locale
import sys, os, re, urllib, urllib2
from winsound import PlaySound, SND_FILENAME, SND_ASYNC
import time  
from datetime import datetime, timedelta, tzinfo
from configobj import ConfigObj
from StringIO import StringIO
import simplejson
import pprint
from twyt import twitter, data
import win32api
# import win32clipboard
import win32gui
import lbc
import McSay
# import tinyurl
from googlemaps import GoogleMaps
import htmllib
import pywapi
import urlunshort
from sunlightapi import sunlight, SunlightApiError
import feedfinder
import feedparser
import deliciousapi
import twill
import html2text
import comtypes
import uri
from yahoo.search.term import TermExtraction
import xml.etree.ElementTree as ET

# Custom event handler
class Timer(wx.Timer):
	def Notify(*args, **kwds): OnTimer()

def OnEvent(dlg, event, name):
	if name.startswith('Button_'): 
		win32api.WriteProfileVal('Configuration', 'EventStart', name, file_extensions)
		win32api.WriteProfileVal('Configuration', 'EventEnd', '', file_extensions)

	# return OnRealEvent(dlg, event, name)
	try: OnRealEvent(dlg, event, name)
	except Exception, e: AddStatus('Error!  ' + utf16str(e))
	win32api.WriteProfileVal('Configuration', 'RefreshView', 'n', file_extensions)
	if name.startswith('Button_'): 	
		win32api.WriteProfileVal('Configuration', 'EventStart', '', file_extensions)
		win32api.WriteProfileVal('Configuration', 'EventEnd', name, file_extensions)
		win32api.WriteProfileVal('Configuration', 'RefreshView', 'n', file_extensions)
		win32api.WriteProfileVal('Configuration', 'MainIni', file_ini, file_extensions)

def OnRealEvent(dlg, event, name):
	global sb, sUserID, sUserName, sUserFullName, s1otherName, s1otherFullName, s1otherID, iPageBoundary, sQueryExp, b4get, iPeriodAuto, bDuplic8, sMyUserFullName, sMyUserName, sMyUserID, sMyPassword, sOldSourceLabel, sOldSourceType, lOldSourceItems, lOldSourceOriginal, iOldSelectedIndex, sOldView, iOldPoint, lOldItemData, bFullName, file_chimes, sOrderItems, sPriorityQuery, sJunkFilter, sCombinedProcessing, bEnhancedSpeech, bRelativeTime, file_ini, iOldEventIndex
	# oSt.Say(utf16str(event))
	# oSt.Say(name)
	# oSt.Say('escape id = ' + utf16str(dlg.GetEscapeId()))
	# print 'event', event, 'eventID', event.GetId(), 'eventType', event.GetEventType()
	# if lbc.IsCloseEvent(event): SetStatus('Close'); return event.Skip()
	if lbc.IsCloseEvent(event):
		if name == 'Button_Close': 
			sChoice = lbc.DialogConfirm(title='Confirm', message='Close McTwit?', value='Y')
			if sChoice == 'Y': AddStatus('Yes'); return dlg.EndModal(dlg.Controls['Button_Close'].GetId())
			elif sChoice == 'N': AddStatus('No'); return
			else: return
		else: SetStatus('Close'); return dlg.EndModal(dlg.Controls['Button_Close'].GetId())

	sb = dlg.Controls['StaticText_Status']
	lbl = dlg.Controls['StaticText_Items']
	lst = dlg.Controls['ListBox_Items']
	iIndex = lst.GetSelection()
	memo = dlg.Controls['Memo_View']
	msg = None
	user = None
	if iIndex == -1: pass
	elif lst.SourceType.endswith('Message'): 
		# msg = lst.SourceItems[iIndex]
		msg = GetSourceItem(iIndex)
		user = GetUser(msg, msg.Type)
	elif lst.SourceType.endswith('User'): user = lst.SourceItems[iIndex]

	sUserID = ''
	sUserName = 'My'; sUserFullName = sMyUserFullName; sUserID = sMyUserID
	cfg_ini = ConfigObj(file_ini, list_values=False, create_empty=False, interpolation=False, indent_type='', write_empty_values= False, encoding='utf-8', default_encoding=sDefaultEncoding)
	s1otherName = ReadValue('1otherName', '', cfg_ini=cfg_ini)
	s1otherFullName = ReadValue('1otherFullName', '', cfg_ini=cfg_ini)
	s1otherID = ReadValue('1otherID', '', cfg_ini=cfg_ini)
	
	if s1otherName: sUserName = s1otherName; sUserFullName = s1otherFullName; sUserID = s1otherID
	elif user:sUserID = utf16str(user.id); sUserName = user.screen_name; sUserFullName = user.name

	# if lbc.IsInitEvent(event): return SetCurrentView()
	if lbc.IsInitEvent(event):
		dlg.Controls['Button_New'].SetDefault()
		dlg.CenterOnScreen()
		return
		if iPeriodAuto: AddStatus('.auto = ' + utf16str(iPeriodAuto))
		if s1otherName: AddStatus('1other = ' + sUserName + ' (' + sUserFullName + ')')
		if b4get: AddStatus('4get = Yes')
		if bDuplic8: AddStatus('Duplic8 = Yes')
		if iPageBoundary: AddStatus('Boundary = ' + utf16str(iPageBoundary))


	# if lbc.IsInitEvent(event): name = 'Button_New'

	sCommand = name
	i = sCommand.find('_')
	if i >= 0: sCommand = sCommand[i + 1:]
	if lbc.IsFocusEvent(event): 
		# sLabel = dlg.FindFocus().GetLabel()
		if sCommand == '=balance': sText = 'Alt+=, Show your current rate limit on Twitter'
		elif sCommand == 'Extra': sText = 'Alt+X, Display extra information about the selected user'
		else: sText = ReadValue(key=sCommand, default='', ini=file_help, section='Hotkeys')
		i = sText.find(',')
		if i >= 0: sText = sText[i + 1:].strip()
		SetStatus(sText, silent=True)
		return event.Skip()

	# print 'name', name
	if name == 'ListBox_Items': return SetCurrentView()
	iIndex = lst.GetSelection()
	if iIndex != iOldEventIndex: iOldEventIndex = iIndex; SetCurrentView()
	bRefresh = str2bool(win32api.GetProfileVal('Configuration', 'RefreshView', 'n', file_extensions))
	# if bRefresh: SetCurrentView(); win32api.WriteProfileVal('Configuration', 'RefreshView', 'n', file_extensions)
	if bRefresh: SetCurrentView()
	
	SetStatus(sCommand)
	iPageBoundary = str2int(ReadValue('PageBoundary', '0', cfg_ini=cfg_ini))
	iPeriodAuto = str2int(ReadValue('PeriodAuto', '0', cfg_ini=cfg_ini))
	b4get = str2bool(ReadValue('4get', 'n', cfg_ini=cfg_ini))
	bDuplic8 = str2bool(ReadValue('Duplic8', 'n', cfg_ini=cfg_ini))
	bEnhancedSpeech = str2bool(ReadValue('EnhancedSpeech', 'y', cfg_ini=cfg_ini))
	bFullName = str2bool(ReadValue('FullName', 'n', cfg_ini=cfg_ini))
	bRelativeTime = str2bool(ReadValue('RelativeTime', 'n', cfg_ini=cfg_ini))
	sCombinedProcessing = ReadValue('CombinedProcessing', 'DRN', cfg_ini=cfg_ini)
	sOrderItems = ReadValue('OrderItems', '', cfg_ini=cfg_ini)
	sPriorityQuery = ReadValue('PriorityQuery', '', cfg_ini=cfg_ini)
	sJunkFilter = ReadValue('JunkFilter', '', cfg_ini=cfg_ini)
	file_chimes = ReadValue('SoundFile', file_chimes, cfg_ini=cfg_ini)

	if name == 'Button_Again': FindKeywords(lst, again=True)
		
	elif name == 'Button_Boundary': 
		sText = lbc.DialogInput(title='Page Limit', label='Number', value=utf16str(iPageBoundary))
		if sText == None: return
		try: iPageBoundary = int(sText)
		except: iPageBoundary = 0
		WriteValue('PageBoundary', utf16str(iPageBoundary))
		if iPageBoundary: return AddStatus('Set to ' + Pluralize('page', iPageBoundary))
		else: return AddStatus('No page limit')

	elif name == 'Button_Configure': 
		lButtons = 'Dialog Reset Manual Create Switch'.split()
		sButton = lbc.DialogChoose(title='Choose', message='', names =lButtons)
		if sButton == 'Cancel': return
		AddStatus(sButton)
		if sButton == 'Manual': return os.startfile(file_ini)
		if sButton == 'Switch':
			lValues = glob.glob(dir_data + r'\*.ini')
			for sValue in lValues:
				if sValue.lower().endswith(r'\extensions.ini'): lValues.remove(sValue); break
			if not lValues: return AddStatus('No .ini files found!')
			lNames = [os.path.basename(sValue) for sValue in lValues]
			sValue = lbc.DialogPick(title='Ini Files', names=lNames, values=lValues, sort=True)
			if not sValue: return
			file_ini = sValue
			return LoadIni()

		sPeriodAuto = utf16str(iPeriodAuto)
		s4get = bool2str(b4get)
		sDuplic8 = bool2str(bDuplic8)
		sPageBoundary = utf16str(iPageBoundary)
		sNewCombinedProcessing = sCombinedProcessing
		sEnhancedSpeech = bool2str(bEnhancedSpeech)
		sFullName = bool2str(bFullName)
		sNewJunkFilter = sJunkFilter
		sNewOrderItems = sOrderItems
		sNewPriorityQuery = sPriorityQuery
		sRelativeTime = bool2str(bRelativeTime)
		sSoundFile = file_chimes
		sNewUserName = sMyUserName
		sNewPassword = sMyPassword

		if sButton == 'Create': 
			sName = lbc.DialogInput(title='File Name', label='Text', value='NoName.ini')
			if not sName: return
			file_ini = os.path.join(dir_data, sName)

		if sButton == 'Reset' or sButton == 'Create':
			sPeriodAuto = '0'
			s1otherName = ''
			s4get = 'n'
			sDuplic8 = 'n'
			sPageBoundary = '0'
			sNewCombinedProcessing = 'DRN'
			sEnhancedSpeech = 'y'
			sFullName = 'n'
			sNewJunkFilter = ''
			sNewOrderItems = 'r'
			sNewPriorityQuery = ''
			sRelativeTime = 'n'
			sSoundFile = os.path.join(dir_app, 'chimes.wav')
			sNewUserName = ''
			sNewPassword = ''
	
		lLabels = ['.Auto', '1Other', '4Get', 'Duplic&8', 'Boundary', 'CombinedProcessing', 'EnhancedSpeech', 'FullName', 'JunkFilter', 'OrderItems', 'PriorityQuery', 'RelativeTime', 'SoundFile', 'User', 'Pass&word']
		lValues = [sPeriodAuto, s1otherName, s4get, sDuplic8, sPageBoundary, sNewCombinedProcessing, sEnhancedSpeech, sFullName, sNewJunkFilter, sNewOrderItems, sNewPriorityQuery, sRelativeTime, sSoundFile, sNewUserName, sNewPassword]
		lResults = lbc.DialogMultiInput(title='Settings', labels=lLabels, values=lValues, statusbar=True, ini=file_help)
		if not lResults: return

		if (sButton == 'Reset' or sButton == 'Create') and os.path.isfile(file_ini): os.remove(file_ini)
		sPeriodAuto = lResults[0].strip()
		iPeriodAuto = str2int(sPeriodAuto)
		WriteValue('PeriodAuto', utf16str(iPeriodAuto))
		if tmr.IsRunning(): tmr.Stop()
		if lResults[0] != lValues[0]: 
			if not iPeriodAuto: AddStatus('No auto check')
			else:
				bResult = tmr.Start(iPeriodAuto * 60000)
				AddStatus('Auto check set to ' + Pluralize('minute', iPeriodAuto))

		s1otherName = lResults[1].strip()
		if s1otherName: 
			try: result = t.user_show(id=s1otherName)
			except: return AddStatus('Not found!')
			d = simplejson.loads(result)
			s1otherID = utf16str(d['id'])
			s1otherName = d['screen_name']
			s1otherFullName = d['name']

		if lResults[1] != lValues[1]:
			if s1otherName: AddStatus('1other set to ' + s1otherName + ' (' + s1otherFullName + ')')
			else:
				AddStatus('No other user')
				s1otherName = ''
				s1otherFullName = ''
				s1otherID = ''

		WriteValue('1otherName', s1otherName)
		WriteValue('1otherFullName', s1otherFullName)
		WriteValue('1otherID', s1otherID)

		s4get = lResults[2].strip()
		b4get = str2bool(s4get)
		WriteValue('4get', bool2str(b4get))
		if lResults[2] != lValues[2]:
			if b4get: AddStatus('Forget whether messages have been shown')
			else: AddStatus('Remember whether messages have been shown')

		sDuplic8 = lResults[3].strip()
		bDuplic8 = str2bool(sDuplic8)
		WriteValue('Duplic8', bool2str(bDuplic8))
		if lResults[3] != lValues[3]:
			if bDuplic8: AddStatus('Record to file')
			else: AddStatus('No recording')

		sPageBoundary = lResults[4].strip()
		iPageBoundary = str2int(sPageBoundary)
		WriteValue('PageBoundary', utf16str(iPageBoundary))
		if lResults[4] != lValues[4]:
			if iPageBoundary: AddStatus('Page boundary set to ' + utf16str(iPageBoundary))
			else: AddStatus('No page boundary')

		sCombinedProcessing = lResults[5].strip()
		WriteValue('CombinedProcessing', sCombinedProcessing)
		if lResults[5] != lValues[5]: 
			d = {'D' : 'Speak Direct', 'R' : 'Speak Replies', 'N' : 'Speak New', 'd' : 'Direct', 'r' : 'Replies', 'n' : 'New'}
			for c in sCombinedProcessing: 
				if d.has_key(c): AddStatus(d[c])

		sEnhancedSpeech = lResults[6].strip()
		bEnhancedSpeech = str2bool(sEnhancedSpeech)
		WriteValue('EnhancedSpeech', bool2str(bEnhancedSpeech))
		if lResults[6] != lValues[6]:
			if bEnhancedSpeech: AddStatus('Enhanced speech with screen readers')
			else: AddStatus('No enhanced speech')

		sFullName = lResults[7].strip()
		bFullName = str2bool(sFullName)
		WriteValue('FullName', bool2str(bFullName))
		if lResults[7] != lValues[7]:
			if bFullName: AddStatus('Use full name in message list')
			else: AddStatus('Use screen name in message list')

		sJunkFilter = lResults[8]
		WriteValue('JunkFilter', sJunkFilter)
		if lResults[8] != lValues[8]: 
			if sJunkFilter: AddStatus('Junk filter set to ' + sJunkFilter)
			else: AddStatus('No junk filter')

		sOrderItems = lResults[9].lower().strip()
		if sOrderItems not in 'rca': sOrderItems = 'r'
		WriteValue('OrderItems', sOrderItems)
		if lResults[9] != lValues[9]: 
			d = {'r' : 'Recent', 'c' : 'Chronological', 'a' : 'Alphabetical'}
			if sOrderItems: AddStatus('Order set to ' + d[sOrderItems])
			else: AddStatus('Default order')

		sPriorityQuery = lResults[10]
		WriteValue('PriorityQuery', sPriorityQuery)
		if lResults[10] != lValues[10]: 
			if sPriorityQuery: AddStatus('Priority query set to ' + sPriorityQuery)
			else: AddStatus('No priority query')

		sRelativeTime = lResults[11].strip()
		bRelativeTime = str2bool(sRelativeTime)
		WriteValue('RelativeTime', bool2str(bRelativeTime))
		if lResults[11] != lValues[11]:
			if bRelativeTime: AddStatus('Use relative times in viewing area')
			else: AddStatus('Use absolute times in viewing area')

		file_chimes = lResults[12].strip()
		WriteValue('SoundFile', file_chimes)
		if lResults[12] != lValues[12]: 
			if file_chimes: AddStatus('Sound file set to ' + file_chimes)
			else: AddStatus('No sound file')

		sMyUserName = lResults[13].strip()
		WriteValue('User', sMyUserName)
		# if lResults[13] != lValues[13]: AddStatus('My user name set to ' + sMyUserName); LoadIni()
		if lResults[13] != lValues[13]: LoadIni()

		sMyPassword = lResults[14]
		WriteValue('Password', sMyPassword)
		if lResults[14] != lValues[14]: AddStatus('New password set')

		t.set_auth(sMyUserName, sMyPassword)
		win32api.WriteProfileVal('Configuration', 'MainIni', file_ini, file_extensions)

	elif name == 'Button_Yield': 
		if iIndex == -1: return AddStatus('No items!')
		dYield = GetYield()
		for k, v in dYield.items(): 
			if v: AddStatus(Pluralize(k, v))
		# AddStatus(Pluralize('item', lst.GetCount()))
		for i in range(lst.GetCount()): SetStatus(lst.GetString(i))

	elif name == 'Button_Zap': 
		msg = GetSourceItem()
		if not msg: return AddStatus('No items!')
		sType = msg.Type
		# print sType
		sLabel = lbl.GetLabel()
		# print sLabel
		lButtons = ['Leader User', 'Follower User']
		lButtons.append(sType)
		sButton = lbc.DialogChoose(title='Choose', message='', names =lButtons)
		if sButton == 'Cancel': return
		AddStatus(sButton)

		if sButton.startswith('Favorite') and sType.endswith('Favorite Message'):
			sId = utf16str(msg.id)
			sUrl = r'http://twitter.com/favorites/destroy/' + sId + '.json'
			dParams = {}
			sQuery = utf8urlencode(dParams)
			req = urllib2.Request(sUrl, sQuery)
			req.add_header(u'Authorization', t.auth)
			handle = urllib2.urlopen(req)
			response = handle.read()
			results = simplejson.loads(response)
			ShowResult(response)
			return

		if sButton.endswith('Message') and sType.endswith('Message'):
			if lbc.DialogConfirm(title='Confirm', message='Delete ' + sType + '\n' + GetUser(msg, sType).screen_name + ': ' + msg.text, value='Y') != 'Y': return
			if sType == 'Status Message' or sType == 'Reply Message': result = t.status_destroy(msg.id)
			elif sType == 'Direct Message': result = t.direct_destroy(msg.id)
			else: return AddStatus('Not possible with ' + sType + '!')

		# elif sType.endswith('User'):
		elif sButton.endswith('User'):
			# if sType.startswith('Follower'):
			if sButton.startswith('Follower'):
				if lbc.DialogConfirm(title='Confirm', message='Block\n' + sUserName + '\nfrom following you?', value='Y') <> 'Y': return
				if lbc.DialogConfirm(title='Confirm', message='Also report\n' + sUserName + '\nas a spammer to Twitter?', value='Y') == 'Y':
					sAddress = '            http://twitter.com/report_spam.json'
					dData = {'user_id' : sUserID}
					result = WebRequestPost(sAddress, dData)
					# request = simplejson.loads(sResponse)
				else: result = t.block_create(id=sUserID)
			# elif sType.startswith('Leader'):
			elif sButton.startswith('Leader'):
				if lbc.DialogConfirm(title='Confirm', message='Quit following ' + sUserName + ' (' + sUserFullName + ')?', value='Y') != 'Y': return
				result = t.friendship_destroy(id=sUserID)
			# elif sType.startswith('Blocked'):
			elif sButton.startswith('Blocked'):
				if lbc.DialogConfirm(title='Confirm', message='Unblock\n' + sUserName + '( ' + sUserFullName + ')\nso you can be followed?', value='Y') <> 'Y': return
				result = t.block_destroy(id=sUserID)
			else: return AddStatus('Not possible with ' + sType + '!')

		ShowResult(result)


	elif name == 'Button_Export': 
		if iIndex == -1: return AddStatus('No items!')
		sText = memo.GetValue()
		AppendExport(sText)

	elif name == 'Button_Followers': 
		sItemType = 'Follower User'
		# lUser = data.UserList(t.user_followers(id=sUserID))
		lUser = data.UserList()
		iPage = 1
		iCursor = -1
		while True:
			if b4get: sTime = ''; sID = ''
			# l = data.UserList(t.user_followers(id=sUserID, page=iPage), itemType=sItemType)
			# l = data.UserList(t.user_followers(id=GetIDName(sUserName, sUserID), page=iPage), itemType=sItemType)
			l = data.UserList(t.user_followers(id=GetIDName(sUserName, sUserID), cursor=iCursor), itemType=sItemType)
			iCursor = l.cursor
			if l.error: AddStatus('Error!'); break
			if not l: break
			if iPage > 1: AddStatus('Page ' + utf16str(iPage))
			lUser.extend(l)
			# if len(l) < 100: break
			if not iCursor: break
			if iPageBoundary and iPage == iPageBoundary: break
			iPage += 1

		PopulateUsers(dlg, lUser, sItemType)
		# PopulateMessages(dlg, lUser, sItemType)

	elif name == 'Button_Go': 
		item = GetSourceItem()
		# if not item: return AddStatus('No items!')
		if not item:
			iPosition = memo.GetInsertionPoint()
			iCol, iRow = memo.PositionToXY(iPosition)
			sLine = memo.GetLineText(iRow)
			if (memo.FindFocus() == memo) and sLine.find('://') >= 0: return os.startfile(sLine)
			sLines = oSt.ReadFile(file_urls)
			sLines = sLines.replace('\r', '').strip()
			aLines = sLines.split('\n')
			lNames = list(aLines)
			lNames.sort(cmp=lambda x, y: cmp(x.upper(), y.upper()))
			lValues = lNames[:]
			sName = ReadValue('Go', '')
			try: iIndex = lNames.index(sName)
			except: iIndex = 0
			# print sName, iIndex
			# sText = lbc.DialogPick(title='Twitter URLs', names=lNames, values=lValues, sort=True, index=iIndex)
			sText = lbc.DialogPick(title='Twitter URLs', names=lNames, values=lValues, sort=False, index=iIndex)
			if not sText: return
			WriteValue('Go', sText)
			sUrl = sText.split('=')[1].strip()
			return os.startfile(sUrl)

		elif isattr(item, 'url'): sText = item.url
		else: sText = item.text

		# sMatch = r'(\bwww\.|\w+://)\S+'
		sMatch = r'(\bwww\.|\w+://)[^\s"]+'
		regexp = re.compile(sMatch, re.I)
		oMatch = regexp.search(sText)
		if not oMatch: return AddStatus('No URL found!')
		sUrl = oMatch.group()
		# print 'item', item
		# if item: sUrl = lbc.DialogInput(title='URL', label='Text', value=sUrl)
		if sUrl: sUrl = sUrl.strip()
		# if not sUrl: return
		lButtons = ['Open', 'Background', 'Inquire']
		# sUrl = 'http://is.gd/lznv'
		# if item: sButton = lbc.DialogChoose(title='Choose', message=sUrl, names=lButtons)
		if item: sButton = lbc.DialogChoose(title='Choose', message='', names=lButtons)
		if sButton == 'Cancel': return
		AddStatus(sButton)
		if sButton == 'Open': return os.startfile(sUrl)
		if sButton == 'Background': return RunBackground(sUrl)

		sAddress = 'http://api.tweetmeme.com/url_info.json'
		dParams = {'url' : sUrl}
		sParams = utf8urlencode(dParams)
		sAddress += '?' + sParams
		req = urllib2.Request(sAddress)
		fResponse = urllib2.urlopen(req)
		sResponse = fResponse.read()
		dResponse = simplejson.loads(sResponse)
		# dStory = dResponse['story']
		dStory = dResponse.get('story', None)
		if not dStory: return AddStatus('No information available!')
		lKeys = 'media_type excerpt created_at url'.split()  
		sText = GetDictionaryText(dStory, lKeys)
		sTitle = dStory['title']
		return lbc.DialogShow(title=sTitle, message=sText)
		memo.SetValue(sText)
		memo.SetFocus()
		# print sText
		
		
		
		



	elif name == 'Button_Join': 
		if not sUserName and sUserName != 'My' and iIndex == -1: return AddStatus('No user specified!')
		lButtons = 'Follow Notify Silent'.split()
		sButton = lbc.DialogChoose(title='Choose', message='', names =lButtons)
		if not sButton or sButton == 'Cancel': return

		AddStatus(sButton)
		if sButton == 'Notify' or sButton == 'Silent':
			if sButton == 'Notify': sUrl = r'http://twitter.com/notifications/follow/' + sMyUserID + '.json'
			else: sUrl = r'http://twitter.com/notifications/leave/' + sMyUserID + '.json'
			dParams = {'screen_name' : sUserName}
			sData = utf8urlencode(dParams)
			# print 'url', sUrl
			# print 'data', sData
			req = urllib2.Request(sUrl, sData)
			req.add_header(u'Authorization', t.auth)
			fResponse = urllib2.urlopen(req)
			sResponse = fResponse.read()
			# print 'response', sResponse
			# dResponse = simplejson.loads(sResponse)
			return ShowResult(sResponse)
	
		sChoice = lbc.DialogConfirm(title='Confirm', message='Notify your mobile phone about tweets from ' + sUserName + ' (' + sUserFullName + ')?', value='N')
		if sChoice == 'Y': AddStatus('Yes'); bChoice = True
		elif sChoice == 'N': AddStatus('No'); bChoice = False
		else: return
		result = t.friendship_create(id=GetIDName(sUserName, sUserID), follow=bChoice)
		return ShowResult(result)

	elif name == 'Button_Keywords': FindKeywords(lst, again=False)

	elif name == 'Button_Leaders': 
		sItemType = 'Leader User'
		# lUser = data.UserList(t.user_friends(id=sUserID))
		lUser = data.UserList()
		iPage = 1
		iCursor = -1
		while True:
			if b4get: sTime = ''; sID = ''
			# l = data.UserList(t.user_friends(id=sUserID, page=iPage), itemType=sItemType)
			# sID = GetUserID(sUserName)
			# print sUserName, sUserID, sID, GetIDName(sUserName, sUserID)
			# l = data.UserList(t.user_friends(id=GetIDName(sUserName, sUserID), page=iPage), itemType=sItemType)
			l = data.UserList(t.user_friends(id=GetIDName(sUserName, sUserID), cursor=iCursor), itemType=sItemType)
			iCursor = l.cursor
			# l = data.UserList(t.user_friends(id=sID, page=iPage), itemType=sItemType)
			if l.error: AddStatus('Error!'); break
			if not l: break
			if iPage > 1: AddStatus('Page ' + utf16str(iPage))
			lUser.extend(l)
			# if len(l) < 100: break
			if not iCursor: break
			if iPageBoundary and iPage == iPageBoundary: break
			iPage += 1

		PopulateUsers(dlg, lUser, sItemType)

	elif name == 'Button_Direct':
		sUserName= 'My'
		sUserID = ''
		sItemType = 'Direct Message'
		sTime = ReadValue(sItemType + 'Time', section=sUserName)
		sID = ReadValue(sItemType + ' ID', section=sUserName)
		# lMsg = data.DirectList(t.direct_messages(since=sTime, since_id=sID))
		lMsg = data.DirectList()
		iPage = 1
		# print 'itemType', sItemType, 'sTime', sTime, 'sID', sID
		while True:
			if b4get: sTime = ''; sID = ''
			l = data.DirectList(t.direct_messages(since=sTime, since_id=sID, page=iPage), itemType='Direct Message')
			if l.error: AddStatus('Error!'); break
			if not l: break
			if iPage > 1: AddStatus('Page ' + utf16str(iPage))
			lMsg.extend(l)
			# if len(l) < 20: break
			if iPageBoundary and iPage == iPageBoundary: break
			iPage += 1

		PopulateMessages(dlg, lMsg, sItemType)

	elif name == 'Button_New':
		sUserName = 'My'
		sUserID = ''
		sItemType = 'Leader Message'
		sTime = ReadValue(sItemType + ' Time', section=sUserName)
		sID = ReadValue(sItemType + ' ID', section=sUserName)
		# lMsg = data.StatusList(t.status_friends_timeline(since=sTime, since_id=sID))
		lMsg = data.StatusList()
		iPage = 1
		while True:
			if b4get: sTime = ''; sID = ''
			l = data.StatusList(t.status_friends_timeline(since=sTime, since_id=sID, page=iPage), itemType='Status Message')
			if l.error: AddStatus('Error!'); break
			if not l: break
			if iPage > 1: AddStatus('Page ' + utf16str(iPage))
			lMsg.extend(l)
			# if len(l) < 20: break
			if iPageBoundary and iPage == iPageBoundary: break
			iPage += 1

		PopulateMessages(dlg, lMsg, sItemType)

	elif name == 'Button_Messages':
		sItemType = 'Status Message'
		sTime = ReadValue(sItemType + ' Time', section=sUserName)
		sID = ReadValue(sItemType + ' ID', section=sUserName)
		# lMsg = data.StatusList(t.status_user_timeline(since=sTime, since_id=sID, id=sUserID))
		lMsg = data.StatusList()
		iPage = 1
		while True:
			if b4get: sTime = ''; sID = ''
			# l = data.StatusList(t.status_user_timeline(since=sTime, since_id=sID, id=sUserID, page=iPage), itemType='Status Message')
			l = data.StatusList(t.status_user_timeline(since=sTime, id=GetIDName(sUserName, sUserID), page=iPage), itemType='Status Message')
			if l.error: AddStatus('Error!'); break
			if not l: break
			if iPage > 1: AddStatus('Page ' + utf16str(iPage))
			lMsg.extend(l)
			# if len(l) < 20: break
			if iPageBoundary and iPage == iPageBoundary: break
			iPage += 1

		PopulateMessages(dlg, lMsg, sItemType)

	elif name == 'Button_Order': 
		lButtons = 'Recent Chronological Alphabetical'.split()
		iIndex = 'rca'.find(sOrderItems)
		if iIndex == -1: iIndex = 0
		sButton = lbc.DialogChoose(title='Choose', message='', names =lButtons, index=iIndex)
		if sButton == 'Cancel': return
		AddStatus(sButton)
		sOrderItems = sButton[0].lower()
		WriteValue('OrderItems', sOrderItems)
		if lst.GetCount() == 0: return

		l = lst.SourceOriginal[:]
		# lOld = [(lst.GetString(i), lst.GetClientData(i)) for i in range(lst.GetCount())]
		l = []
		for iIndex in range(lst.GetCount()):
			sItem = lst.GetString(iIndex)
			iData = lst.GetClientData(iIndex)
			item = lst.SourceItems[iData]
			sDateTime = item.created_at
			dt = GetEpochTime(sDateTime)
			a = (dt, sItem, iData)
			l.append(a)

		if sOrderItems == 'a': l.sort(cmp=lambda x, y: cmp(x[1].lower(), y[1].lower()))
		elif sOrderItems == 'c': l.sort()
		else: l.sort(reverse=True)
		lst.Clear()
		for a in l: lst.Append(item=a[1], clientData=a[2])
		lst.SetSelection(0)
	
	elif name == 'Button_Public':
		sItemType = 'Public Message'
		sUserName = 'My'
		sUserID = ''
		sTime = ReadValue(sItemType + ' Time', section=sUserName)
		sID = ReadValue(sItemType + ' ID', section=sUserName)
		lMsg = data.StatusList(t.status_public_timeline(), itemType='Status Message')
		PopulateMessages(dlg, lMsg, sItemType)

	elif name == 'Button_Query': 
		lButtons = 'Priority Rest Input All'.split()
		sButton = lbc.DialogChoose(title='Choose', message='', names =lButtons)
		if sButton == 'Cancel': return
		AddStatus(sButton)

		if (sButton == 'Priority' or sButton == 'Rest') and not sPriorityQuery: return AddStatus('no priority query defined!')
		sMatch = ''
		if sButton == 'All': sMatch = ' '
		if sButton == 'Priority' or sButton == 'Other': sMatch = sPriorityQuery
		if sButton == 'Input': sMatch = lbc.DialogInput(title='Regular Expression', label='Text', value=sQueryExp)
		if sMatch == None: return
		if sButton == 'Input': sQueryExp = sMatch
		# print 'sMatch', sMatch
		try: regexp = re.compile(sMatch, re.I)
		except: return AddStatus('Invalid expression!')

		lMatches = []
		lOriginal = lst.SourceOriginal[:]
		# lOriginal.reverse()
		# for iIndex in range(len(lOriginal)):
		iIndex = len(lOriginal)
		while iIndex > 0:
			iIndex -= 1
		# for iIndex in range(0, len(lOriginal), -1):
		# for item in lst.SourceItems:
			# print 'count', len(lOriginal), 'index', iIndex
			# i = len(lOriginal) - iIndex - 1
			# iData = lOriginal[i][1]
			iData = lOriginal[iIndex][1]
			item = lst.SourceItems[iData]
			# sText = GetItemText(item)
			# sText = utf16str(item)
			sText = GetAttributeText(item)
			# print sText
			# sText = GetMemoText(iData)
			if sButton == 'Rest' and not regexp.search(sText): lMatches.append(iIndex)
			elif sButton != 'Rest' and regexp.search(sText): lMatches.append(iIndex)

		iCount = len(lMatches)
		if not iCount: return AddStatus('No matches!')
		AddStatus(utf16str(iCount) + ' match' + ('' if iCount == 1 else 'es'))
		lNew = [(lOriginal[i][0], lOriginal[i][1]) for i in lMatches]
		lst.Clear()
		for a in lNew: lst.Append(item=a[0], clientData=a[1])
		lst.SetFocus()
		lst.SetSelection(0)
		SetCurrentView()
		
	elif name == 'Button_Replies':
		sUserName = 'My'
		sUserID = ''
		sItemType = 'Reply Message'
		sTime = ReadValue(sItemType + ' Time', section=sUserName)
		sID = ReadValue(sItemType + ' ID', section=sUserName)
		# lMsg = data.StatusList(t.status_replies(since=sTime, since_id=sID))		lMsg = []
		lMsg = data.StatusList()
		iPage = 1
		while True:
			if b4get: sTime = ''; sID = ''
			l = data.StatusList(t.status_replies(since=sTime, since_id=sID, page=iPage), itemType='Reply Message')
			if l.error: AddStatus('Error!'); break
			if not l: break
			if iPage > 1: AddStatus('Page ' + utf16str(iPage))
			lMsg.extend(l)
			# if len(l) < 20: break
			if iPageBoundary and iPage == iPageBoundary: break
			iPage += 1

		PopulateMessages(dlg, lMsg, sItemType)

	elif name == 'Button_Sent':
		sUserName = 'My'
		sUserID = ''
		sItemType = 'Sent Message'
		sTime = ReadValue(sItemType + ' Time', section=sUserName)
		sID = ReadValue(sItemType + ' ID', section=sUserName)
		# lMsg = data.DirectList(t.direct_sent(since=sTime, since_id=sID))
		lMsg = data.DirectList()
		iPage = 1
		while True:
			if b4get: sTime = ''; sID = ''
			l = data.DirectList(t.direct_sent(since=sTime, since_id=sID, page=iPage), itemType='Direct Message')
			if l.error: AddStatus('Error!'); break
			if not l: break
			if iPage > 1: AddStatus('Page ' + utf16str(iPage))
			lMsg.extend(l)
			# if len(l) < 20: break
			if iPageBoundary and iPage == iPageBoundary: break
			iPage += 1

		PopulateMessages(dlg, lMsg, sItemType, sent=True)

	elif name == 'Button_Tweet': PostTweet()

	elif name == 'Button_2tweet':
		item = GetSourceItem()
		if not item: return AddStatus('No items!')
		sItemType = lst.SourceType
		if sItemType.startswith('Direct'):
			sChoice = lbc.DialogConfirm(title='Confirm', message='Reply publicly to direct message?', value='N')
			if not sChoice: return
			elif sChoice == 'N': return AddStatus('No')

		AddStatus('Yes')
		PostTweet(reply=True)

	# elif name == 'Button_3tweet': PostTweet(rt=True)
	elif name == 'Button_3tweet':
		lButtons = 'Standard Custom'.split()
		sButton = lbc.DialogChoose(title='Choose', message='', names =lButtons)
		if sButton == 'Cancel': return
		AddStatus(sButton)

		if sButton == 'Custom': return PostTweet(rt=True)

		sId = GetSourceItem().id
		dData = {'id' : sMyUserID}
		dData = {}
		# sAddress = 'http://api.twitter.com/1/statuses/retweet/' + sMyUserID + '.json'  
		sAddress = 'http://api.twitter.com/1/statuses/retweet/' + str(sId) + '.json'  
		sResponse = WebRequestPost(sAddress, {'id' : sId}, {})
		dResponse = simplejson.loads(sResponse)
		# print sResponse
		ShowResult(dResponse)

	elif name == 'Button_Utilities': 
		lButtons = []
		lButtons.append('Email Forward')
		lButtons.append('Export.txt file')
		lButtons.append('Junk.txt file')
		lButtons.append('@User Stats')
		lButtons.append('#Hashtag Lookup')
		lButtons.append(':Dictionary Lookup')
		lButtons.append('-Trend Topics')
		lButtons.append('508 Check')
		lButtons.append('Address Lookup')
		lButtons.append('Business Reviews')
		lButtons.append('Common URLs')
		lButtons.append('Driving Directions')
		lButtons.append('Feed Find')
		lButtons.append('Google Search and Set Suggestions')
		lButtons.append('Help on twitter.com')
		lButtons.append('Interesting Places')
		lButtons.append('Language Translation')
		lButtons.append('Members of Congress')
		lButtons.append('Neighborhood Search')
		lButtons.append('Original URL')
		lButtons.append('Quotes of the Day')
		lButtons.append('Recommended URLs')
		lButtons.append('Short URL')
		lButtons.append('Twitter Name Search')
		lButtons.append('URL Downloads')
		lButtons.append('Virtual White Pages')
		lButtons.append('Weather Check')
		lButtons.append('E&xtra Word Info')
		lButtons.append('Yahoo! Term Extractions')
		lButtons.append('ZoomInfo Contact Search')
		sButton = lbc.DialogChoose(title='Choose', message='', names =lButtons)
		if sButton == 'Cancel': return
		AddStatus(sButton)

		if sButton.startswith('Email'): 
			item = GetSourceItem()
			if not item: return AddStatus('No items!')
			sSubject = 'Fwd from ' + item.user.screen_name + ' on Twitter'
			sBody = item.text
			d = {'SUBJECT' : sSubject.encode('utf-8', 'ignore'), 'Body' : sBody.encode('utf-8', 'ignore')}
			# sUrl = 'mailto:?' + utf8urlencode(d)
			sUrl = 'mailto:?SUBJECT=' + MailEncode(sSubject) + '&BODY=' + MailEncode(sBody)
			os.startfile(sUrl)
		elif sButton.startswith('Export.txt'): os.startfile(file_export)
		elif sButton.startswith('Junk.txt'): os.startfile(file_junk)

		elif sButton.startswith('-Trend'): 
			sAddress = 'http://letsbetrends.com/api/current_trends  '
			# sAddress = 'http://www.whatthetrend.com/api/trend/listAll/json'
			dParams = {}
			sParams = utf8urlencode(dParams)
			if dParams: sAddress += '?' + sParams
			req = urllib2.Request(sAddress)
			fResponse = urllib2.urlopen(req)
			sResponse = fResponse.read()
			dResponse = simplejson.loads(sResponse)
			lTrends = dResponse.get('trends', None)
			if not lTrends: return AddStatus('No information available!')
			sText = ''
			for dTrend in lTrends: 
				s = utf16str(dTrend['name']).strip() + '\r\n' + utf16str(dTrend['description']['text']).strip()
				s = s.replace('\r\n\r\n', '\r\n')
				sText += s + '\r\n\r\n'
			sText = sText.strip()
			sText = sText.replace('\nUrl: ', '\r\n')
			# sText = sText.replace('\nUrl: ', '')
			sTitle = Pluralize('Trend Topic', len(lTrends)) + ' from Letsbetrends.com'
			sText = sTitle + '\r\n\r\n' + sText
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)

		elif sButton.startswith('Driving'): 
			aLabels = ['Start Address', 'End Address']
			sStartAddress = ReadValue('StartAddress')
			if not sStartAddress: sStartAddress = ReadValue('NeighborhoodAddress')
			sEndAddress = ReadValue('EndAddress')
			aValues = [sStartAddress, sEndAddress]
			aResults = lbc.DialogMultiInput(title='Directions', labels=aLabels, values=aValues)
			if not aResults: return
			
			sStartAddress = aResults[0]
			sEndAddress = aResults[1]
			WriteValue('StartAddress', sStartAddress)
			WriteValue('EndAddress', sEndAddress)
			aResults = GetGoogleDrivingDirections(sStartAddress, sEndAddress)
			sDistance = FormatDecimal(aResults[0] / 1000.0)
			sDuration = FormatDecimal(aResults[1] / 3600.0)
			aSteps = aResults[2]
			sText = 'Driving Directions\r\nFrom ' + sStartAddress + '\r\nTo ' + sEndAddress + '\r\n\r\n'
			sText += sDistance + ' kilometers\r\n' + sDuration + ' hours\r\n\r\n'
			for sStep in aSteps: sText += sStep + '\r\n'
			sMatch = r'\<div.*?\>'
			sReplace = '\r\n\r\n'
			sText = RegExpReplace(sText, sMatch, sReplace)
			sMatch = r'\<.*?\>'
			sReplace = ''
			sText = RegExpReplace(sText, sMatch, sReplace)
			sText = sText.strip()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)
	
		elif sButton.startswith('Language'): 
			sText = ''
			item = GetSourceItem()
			if item: sText = item.text
			DialogTranslateLanguage(sText)
		elif sButton.startswith('Original'): 
			sShortUrl = GetUrl()
			if not sShortUrl: sShortUrl = ReadValue('ShortUrl')
			sText = lbc.DialogInput(title='Input', label='Short URL', value=sShortUrl)
			if not sText: return
			if not sText.lower().find('://') >= 0: sText = 'http://' + sText
			WriteValue('ShortUrl', sText)
			sUrl = urlunshort.resolve(sText)
			AddStatus(sUrl)
			AddStatus('Copied to clipboard')
			SetClipboard(sUrl)

		elif sButton.startswith('Feed'): 
			sWebSource = GetUrl()
			if not sWebSource: sWebSource = ReadValue('WebSource')
			sWebSource = lbc.DialogInput(title='Input', label='Web Source', value=sWebSource)
			if not sWebSource: return
			
			WriteValue('WebSource', sWebSource)
			AddStatus('Please wait')
			lFeeds = feedfinder.feeds(sWebSource)
			if not lFeeds: return AddStatus('No feeds found!')
			sText = Pluralize('Feed', len(lFeeds)) + ' from ' + sWebSource + '\r\n\r\n'
			for sFeed in lFeeds: sText += sFeed + '\r\n\r\n'
			sText = sText.strip()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)

		elif sButton.startswith('Help'): 
			sAddress = 'http://help.twitter.com/portal'
			os.startfile(sAddress)

		elif sButton.startswith('Interesting'): 
			dNames = {'Location' : 'address', 'Kilometers' : 'rad', 'Query' : 'q'}
			# lNames = 'Address Rad Q'.split()
			lNames = 'Location Kilometers Query'.split()
			lValues = []
			for sName in lNames: sValue = ReadValue('Interesting' + sName); lValues.append(sValue)
			lResults = lbc.DialogMultiInput(title='Multi Input', labels=lNames, values=lValues)
			if not lResults: return

			sAddress = 'http://api.nextstop.com/search/'
			sApiKey = '1LfiUaiDqYdpUFpor'
			dData = {'key' : sApiKey, 'result_type' : 'places'}
			for i, sName in enumerate(lNames): 
				sResult = lResults[i].strip()
				WriteValue('Interesting' + sName, sResult)
				# if sResult: dData[sName.lower()] = sResult
				if sResult: dData[dNames[sName]] = sResult

			AddStatus('Please wait')
			sResponse = WebRequestGet(sAddress, dData)
			# print sResponse
			dResponse = simplejson.loads(sResponse)
			lPlaces = dResponse['data']['resultsList']
			if not lPlaces: return AddStatus('No information available!')
			sText = Pluralize('Place', len(lPlaces)) + ' from NextStop.com\r\n\r\n'
			for dPlace in lPlaces:
				sText += AddLine(dPlace.get('category', ''))
				sText += AddLine(dPlace.get('name', ''))
				sText += AddLine(dPlace.get('address', ''))
				sText += AddLine(dPlace.get('locationName', ''))
				sText += AddLine(dPlace.get('phone', ''))
				sText += AddLine(dPlace.get('website', ''))
				try: s = dPlace['recommendationsInfo']['bestRecommendation']['shortText']
				except: s = ''
				if s: sText += '"' + s + '"' + '\r\n'
				sText += '\r\n'

			# for sKey in dResponse.keys(): print sKey
			sText = sText.strip()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)

		elif sButton.startswith('Dictionary'): 
			sDictionaryLookup = ReadValue('DictionaryLookup')
			if not sDictionaryLookup: sDictionaryLookup = ReadValue('WordInfo')
			sDictionaryLookup = lbc.DialogInput(title='Input', label='Lookup', value=sDictionaryLookup)
			if not sDictionaryLookup: return
			WriteValue('DictionaryLookup', sDictionaryLookup)
			AddStatus('Please wait')
			# sAddress = 'http://en.wikipedia.org/wiki/' + sDictionaryLookup.replace(' ', '_')
			sAddress = 'http://wiktionary.org'
			oBrowser = twill.get_browser()
			oBrowser.go(sAddress)
			twill.commands.formvalue(1, 'search', sDictionaryLookup)
			twill.commands.submit()
			sHtml = oBrowser.result.get_page()
			sHtml = utf8str(sHtml)
			sText = HtmlToText(sHtml)
			sText = RegExpReplace(sText, r'\[edit\]', '')
			sText = RegExpReplace(sText, r'\r\nJump to\:.*?\n', '')
			sText = RegExpReplace(sText, r'\A.*?\n', '')
			sText = RegExpReplace(sText, r'Wikipedia has an article on\:\s*.*?\s*Wikipedia', '')
			while '\r\n\r\n\r\n' in sText: sText = sText.replace('\r\n\r\n\r\n', '\r\n\r\n')
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)

		elif sButton.startswith('Google'): 
			sProposedSearch = ReadValue('ProposedSearch')
			sProposedSearch = lbc.DialogInput(title='Input', label='Proposed Search', value=sProposedSearch)
			if not sProposedSearch: return
			
			WriteValue('ProposedSearch', sProposedSearch)
			sAddress = 'http://labs.google.com/sets'
			dData = {'hl' : 'en', 'btn' : 'Large Set'}
			lTerms = sProposedSearch.split(',')
			lTerms = [sTerm.strip() for sTerm in lTerms]
			for i in range(len(lTerms)):
				sKey = 'q' + str(i)
				dData[sKey] = lTerms[i]
			sResponse = WebRequestGet(sAddress, dData)
			# print StrDefault(sResponse)
			sText = HtmlToText(sResponse)
			sMatch = r'Predicted Items(.|\n)+labs\.google\.com'
			sPrefix = 'Predicted Items'
			iPrefix = len(sPrefix)
			sSuffix = 'labs.google.com'
			iSuffix = len(sSuffix)
			iIndex = sText.find(sPrefix)
			sText = sText[iIndex + iPrefix:]
			iIndex = sText.find(sSuffix)
			sText = sText[0:iIndex]
			sText = sText.strip()
			lItems = sText.split('\n')
			lItems = [sItem.strip() for sItem in lItems]
			lItems.sort()
			sText = '\r\n'.join(lItems)
			# lItems = RegExpExtract(sText, sMatch)
			# sText = lItems[0]
			sSetText = Pluralize('Google Set Suggestion', len(lItems)) + ' for ' + sProposedSearch + '\r\n\r\n' + sText
			# memo.SetValue(sText)
			# memo.SetFocus()
			# memo.SetIndex(0)

			sAddress = 'http://google.com/complete/search'
			dData = {'output' : 'toolbar', 'q' : sProposedSearch}
			sXml = WebRequestGet(sAddress, dData)
			sMatch = 'suggestion data\=\".*?\"' 
			lSuggestions = RegExpExtract(sXml, sMatch)
			sText = Pluralize('Google Search Suggestion', len(lSuggestions)) + ' for ' + sProposedSearch + '\r\n\r\n'
			for sSuggestion in lSuggestions: sText += sSuggestion[17:-1] + '\r\n'
			sText = sText.strip()
			sText += '\r\n\r\n' + sSetText
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)


		elif sButton.startswith('#Hash'): 
			sHash = ''
			item = GetSourceItem()
			if item: sHash = item.text
			sMatch = r'\#(\w|\d)+'
			regexp = re.compile(sMatch, re.I)
			oMatch = regexp.search(sHash)
			if oMatch: sHash = oMatch.group(); sHash = sHash[1:]
			if not sHash: sHash = ReadValue('HashTag')
			sHash = lbc.DialogInput(title='Hashtag', label='Text', value=sHash)
			if sHash: sHash = sHash.strip()
			if sHash.startswith('#'): sHash = sHash[1:]
			if not sHash: return

			WriteValue('HashTag', sHash)
			sText = ''
			sAddress = 'http://api.tagdef.com/' + sHash
			try: sXml = WebRequestGet(sAddress)
			except: sXml = ''
			# sMatch = '\<text\>(.|\n)*?\<\/text\>'
			sMatch = '\<text\>.*?\<\/text\>'
			lDefs = RegExpExtract(sXml, sMatch)
			if sXml and lDefs:
				sText = Pluralize('Definition', len(lDefs)) + ' of #' + sHash + ' from TagDef.com\r\n\r\n'
				for sDef in lDefs: sText += sDef + '\r\n\r\n'
				sText = sText.replace('<text>', '')
				sText = sText.replace('</text>', '')

			sAddress = 'http://api.tagal.us/definition/' + sHash + '/show.json'
			dParams = {}
			sParams = utf8urlencode(dParams)
			if dParams: sAddress += '?' + sParams
			req = urllib2.Request(sAddress)
			fResponse = urllib2.urlopen(req)
			sResponse = fResponse.read()
			lDefinitions = simplejson.loads(sResponse)
			if not lDefs and not lDefinitions: return AddStatus('No information available!')
			if lDefinitions:
				sText += '\r\n' + Pluralize('Definition', len(lDefinitions)) + ' of #' + sHash + ' from Tagalus.com\r\n\r\n'
				for dDefinition in lDefinitions: sText += dDefinition['definition']['the_definition'] + '\r\n\r\n'
			sText = sText.strip()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)

		elif sButton.startswith('Neighborhood'): 
			aLabels = ['Address', 'Keywords']
			sNeighborhoodAddress = ReadValue('NeighborhoodAddress')
			if not sNeighborhoodAddress: sNeighborhoodAddress = ReadValue('StartAddress')
			sNeighborhoodKeywords = ReadValue('NeighborhoodKeywords')
			aValues = [sNeighborhoodAddress, sNeighborhoodKeywords]
			aResults = lbc.DialogMultiInput(title='Neighborhood Search', labels=aLabels, values=aValues)
			if not aResults: return
			
			sNeighborhoodAddress = aResults[0]
			sNeighborhoodKeywords = aResults[1]
			WriteValue('NeighborhoodAddress', sNeighborhoodAddress)
			WriteValue('NeighborhoodKeywords', sNeighborhoodKeywords)
			iResult, sResult = GetGoogleLocalSearch(sNeighborhoodAddress, sNeighborhoodKeywords)
			sText = 'Neighborhood Search\r\n' + sNeighborhoodAddress + '\r\n' + str(iResult) + ' Matching ' + sNeighborhoodKeywords + '\r\n\r\n'
			sText += sResult
			sText = sText.strip()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)
	
		elif sButton.startswith('Members'): 
			sZipCode = ReadValue('ZipCode')
			sZipCode = lbc.DialogInput(title='Input', label='ZipCode', value=sZipCode)
			if not sZipCode: return
			
			WriteValue('ZipCode', sZipCode)
			try: sText = GetLegislators(sZipCode)
			except: return AddStatus('Invalid U.S. zip code!')
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)


		elif sButton.startswith('Address'): 
			sToken = 'svzsnwdpnvyzy3y6v9j6tb2k'
			sAddress = 'http://www.jigsaw.com/rest/searchCompany.json'
			lNames = 'Name AreaCode ZipCode Country WebSiteType FortuneRank'.split()
			lValues = []
			for sName in lNames: sValue = ReadValue('Address' + sName); lValues.append(sValue)
			lResults = lbc.DialogMultiInput(title='Multi Input', labels=lNames, values=lValues)
			if not lResults: return
			dData = {'token' : sToken}
			for i, sName in enumerate(lNames): 
				sResult = lResults[i].strip()
				WriteValue('Address' + sName, sResult)
				if sResult: dData[sName[0:1].lower() + sName[1:]] = sResult

			AddStatus('Please wait')
			sResponse = WebRequestGet(sAddress, dData)
			dResponse = simplejson.loads(sResponse)
			# print dResponse
			lCompanies = dResponse['companies']
			if not lCompanies: return AddStatus('No information available!')
			if len(lCompanies) == 1: sText = str(len(lCompanies)) + ' Organization Found via jigsaw.com\r\n\r\n'
			else: sText = str(len(lCompanies)) + ' Organizations Found via jigsaw.com\r\n\r\n'
			lKeys = 'name address city state zip country'.split()
			for dCompany in lCompanies: sText += GetDictionaryText(dCompany, lKeys) + '\r\n\r\n'
			sText = sText.strip()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)

		elif sButton.startswith('508'): 
			sWebAddress = GetUrl()
			if not sWebAddress: sWebAddress = ReadValue('WebAddress')
			sWebAddress = lbc.DialogInput(title='Input', label='Web Address', value=sWebAddress)
			if not sWebAddress: return
			if sWebAddress.find('://') == -1: sWebAddress = 'http://' + sWebAddress
			WriteValue('WebAddress', sWebAddress)
			AddStatus('Please wait')
			sAddress = 'http://CynthiaSays.com'
			oBrowser = twill.get_browser()
			oBrowser.go(sAddress)
			twill.commands.formvalue(1, 'url', sWebAddress)
			twill.commands.submit()
			sHtml = oBrowser.result.get_page()
			sHtml = utf8str(sHtml)
			# print sHtml
			# sText = html2text.html2text(sHtml)
			sText = HtmlToText(sHtml)
			sMatch = r'HiSoftware can help you meet (.|\n)*?show all detail.' 
			sText = RegExpReplace(sText, sMatch, '')
			sAlpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
			for s in sAlpha: sText = sText.replace('\r\n' + s + '. ', '\r\n\r\n' + s + '. ')
			while sText.find('\r\n\r\n\r\n') >= 0: sText = sText.replace('\r\n\r\n\r\n', '\r\n\r\n')
			sText = sText.strip()
			AddStatus('Setting view area and opening web page')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)
			os.startfile('http://wave.webaim.org/report?url=' + sWebAddress)
			return

			# sAddress = 'http://www.34alabs.com/achecker/checkacc.php'
			# sAppKey = 'ff38290cfdbad5f4d54a0772c05d77e7184a7002'
			sAddress = 'http://achecker.ca/checkacc.php'
			sAppKey = 'f06d23ded5b6c1a37da25ac4066d9bbc2a997826'
			# dData = {'uri' : sWebAddress, 'id' : sAppKey, 'guide' : 'WCAG2-AA', 'output' : 'html'}
			dData = {'uri' : sWebAddress, 'id' : sAppKey}
			sResponse = WebRequestGet(sAddress, dData)
			# print sResponse

		elif sButton.startswith('Business'): 
			sPhoneNumber = ReadValue('PhoneNumber')
			sPhoneNumber = lbc.DialogInput(title='Input', label='Phone Number', value=sPhoneNumber)
			if not sPhoneNumber: return
			WriteValue('PhoneNumber', sPhoneNumber)
			AddStatus('Please wait')
			sAddress = 'http://api.yelp.com/phone_search'
			dData = {'phone' : sPhoneNumber, 'ywsid' : '31pKr9tfZrTHlOSDsbrHSg'}
			lBusinesses = []
			try:
				sResponse = WebRequestGet(sAddress, dData)
				dResponse = simplejson.loads(sResponse)
				lBusinesses = dResponse['businesses']
			except Exception, e: return AddStatus('Error!  ' + utf16str(e))
			if not lBusinesses: return AddStatus('No information available!')
			sText = ''
			for dBusiness in lBusinesses:
				iReviews = dBusiness['review_count']
				if not iReviews: continue
				sText += Pluralize('Business Review', iReviews) + ' for Phone Number ' + sPhoneNumber + ' from yelp.com\r\n'
				sText += dBusiness['name'] + '\r\n'
				sText += 'Average Rating: ' + str(dBusiness['avg_rating']) + '\r\n\r\n'
				lReviews = dBusiness['reviews']
				for dReview in lReviews:
					sText += dReview['text_excerpt'] + '\r\n'
					sText += 'Rating: ' + str(dReview['rating']) + '\r\n\r\n'

			sText = sText.strip()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)

		elif sButton.startswith('Common'): 
			sAddress = '  http://api.tweetmeme.com/stories/popular.json'
			dParams = {'page' : 1, 'count' : 100}
			sParams = utf8urlencode(dParams)
			sAddress += '?' + sParams
			req = urllib2.Request(sAddress)
			fResponse = urllib2.urlopen(req)
			sResponse = fResponse.read()
			dResponse = simplejson.loads(sResponse)
			lStories = dResponse.get('stories', None)
			if not lStories: return AddStatus('No information available!')
			lKeys = 'title excerpt url'.split()  
			sText = ''
			for dStory in lStories: sText += GetDictionaryText(dStory, lKeys) + '\n'
			sText = ('\n' +sText).replace('\nTitle: ', '\r\n\r\n')
			sText = ('\n' +sText).replace('\nExcerpt: ', '\r\n\r\n')
			sText = sText.strip()
			sText = sText.replace('\nUrl: ', '\r\n')
			sTitle = '100 Most Common URLs from TweetMeme.com'
			sText = sTitle + '\r\n\r\n' + sText
			# return lbc.DialogShow(title=sTitle, message=sText)
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)

		elif sButton.startswith('Quotes'):
			sAddress = 'http://www.iheartquotes.com/api/v1/random?show_source=1&show_permalink=0&source=humorists+humorix_misc+humorix_stories'
			sText = WebRequestGet(sAddress)
			lLines = sText.strip().split('\n')
			sText = '\r\n'.join(lLines[0:-1]).strip()
			# sText = sText.replace('\n\n   --  From ', '\r\nFrom ')
			sText = RegExpReplace(sText, '[\r\n]+[ -]+', '\r\n')
			sText = '1 Funny Quote from IHeartQuotes.com\r\n\r\n' + sText
			sText += '\r\n\r\n\r\n' + GetQuotesOfTheDay()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)

		elif sButton.startswith('Recommended'): 
			dapi = deliciousapi.DeliciousAPI()
			sBookmarkTag = ReadValue('BookmarkTag')
			sBookmarkTag = lbc.DialogInput(title='Input', label='Bookmark Tag', value=sBookmarkTag)
			if not sBookmarkTag: return
			WriteValue('BookmarkTag', sBookmarkTag)
			AddStatus('Please wait')
			lUrls = dapi.get_urls(tag=sBookmarkTag)
			if not lUrls: return AddStatus('No URLs found!')
			sText = Pluralize('Recommended Bookmark', len(lUrls)) + ' for ' + sBookmarkTag + ' from delicious.com\r\n\r\n'
			i = 0
			for sUrl in lUrls: 
				i += 1
				oLink = dapi.get_url(sUrl)
				sText += oLink.title + '\r\n' + oLink.url + '\r\n\r\n'
				AddStatus(str(100 * i / len(lUrls)) + '%')
			sText = sText.strip()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)

		elif sButton.startswith('Short'): 
			sOriginalUrl = GetUrl()
			if not sOriginalUrl: sOriginalUrl = ReadValue('OriginalUrl')
			sText = lbc.DialogInput(title='Input', label='Original URL', value=sOriginalUrl)
			if not sText: return
			if not sText.lower().find('://') >= 0: sText = 'http://' + sText
			WriteValue('OriginalUrl', sText)
			# sAddress = 'http://api.bit.ly/shorten'
			sAddress = 'http://api.j.mp/shorten'
			dData = {'version' : '2.0.1', 'longUrl': sText, 'login': 'mctwit', 'apiKey' : 'R_bd192f2656f1d5857cdbf2fc97156941'}
			sResponse = WebRequestGet(sAddress, dData)
			dResponse = simplejson.loads(sResponse)
			# print 'url=' + dResponse['results'][sAddress][shortUrl]
			sUrl = dResponse['results'][sText]['shortUrl']
			# sUrl = tinyurl.create_one(sText)
			AddStatus(sUrl)
			AddStatus('Copied to clipboard')
			SetClipboard(sUrl)

		elif sButton.startswith('Virtual'): 
			lNames = 'FirstName LastName HouseNumber Street City State Zip AreaCode'.split()
			lValues = []
			for sName in lNames: sValue = ReadValue('Virtual' + sName); lValues.append(sValue)
			lResults = lbc.DialogMultiInput(title='Multi Input', labels=lNames, values=lValues)
			if not lResults: return

			sAddress = 'http://api.whitepages.com/find_person/1.0/'
			sApiKey = '809fe67b9341f44573d4dd441ef4e95f'
			dData = {'api_key' : sApiKey, 'outputtype' : 'JSON', 'metro' : '1'}
			for i, sName in enumerate(lNames): 
				sResult = lResults[i].strip()
				WriteValue('Virtual' + sName, sResult)
				if sResult: dData[sName.lower()] = sResult

			AddStatus('Please wait')
			sResponse = WebRequestGet(sAddress, dData)
			# print sResponse
			dResponse = simplejson.loads(sResponse)
			# for sKey in dResponse.keys(): print sKey
			lListings = dResponse['listings']
			sText = Pluralize('Result', len(lListings)) + ' from WhitePages.com\r\n\r\n'
			for dListing in lListings:
				# for sKey in dListing.keys(): print sKey
				lPeople = dListing.get('people', None)
				lPhoneNumbers = dListing.get('phonenumbers', None)
				dAddress = dListing.get('address', None)
				if lPeople: 
					for dPerson in lPeople: sText += dPerson['firstname'] + ' ' + dPerson['lastname'] + '\r\n' 
				if dAddress: sText += dAddress['fullstreet'] + '\r\n' + dAddress['city'] + ', ' + dAddress['state'] + '  ' + dAddress['zip'] + '-' + dAddress['zip4'] + '\r\n' + dAddress['country'] + '\r\n'
				if lPhoneNumbers: 
					for dPhone in lPhoneNumbers: sText += dPhone['fullphone'] + '\r\n'
				sText += '\r\n'

			sText = sText.strip()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)


		elif sButton.startswith('Twitter'): 
			sPeopleSearch = ReadValue('PeopleSearch')
			sPeopleSearch = lbc.DialogInput(title='Input', label='Search', value=sPeopleSearch)
			if not sPeopleSearch: return
			
			WriteValue('PeopleSearch', sPeopleSearch)

			sAddress = 'http://twitter.com/search/users'
			dData = {'q' : sPeopleSearch, 'category' : 'people', 'source' : 'find_on_twitter'}
			sData = utf8urlencode(dData)
			sAddress += '?' + sData
			os.startfile(sAddress)
			
			

		elif sButton.startswith('@User'): 
			# sAddress = 'http://api.foller.me/' + sUserName + '/all.json'
			AddStatus('Setting view area and opening web page')
			sAddress = 'http://followcost.com/' + sUserName + '.json'
			dParams = {}
			sParams = utf8urlencode(dParams)
			if dParams: sAddress += '?' + sParams
			req = urllib2.Request(sAddress)
			fResponse = urllib2.urlopen(req)
			sResponse = fResponse.read()
			dStats = simplejson.loads(sResponse)
			if not dStats: return AddStatus('No information available!')
			# print GetObjectText(dStats, [])
			lKeys = 'twitter_created_at statuses_count average_tweets_per_day average_tweets_per_day_recently'.split()
			sText = GetDictionaryText(dStats, lKeys)
			sText = sText.strip()
			sTitle = 'FollowCost.com Stats for ' + sUserName + ' (' + sUserFullName + ')'
			sText = sTitle + '\r\n\r\n' + sText
			# return lbc.DialogShow(title=sTitle, message=sText)
			# AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)
			sAddress = 'http://api.foller.me/' + sUserName + '/all.xhtml'
			os.startfile(sAddress)

		elif sButton.startswith('URL'):  
			sInitialUrl = GetUrl()
			if not sInitialUrl: sInitialUrl = ReadValue('InitialUrl')
			sInitialUrl = lbc.DialogInput(title='Input', label='Initial URL', value=sInitialUrl)
			if not sInitialUrl: return
			AddStatus('Please wait')
			WriteValue('InitialUrl', sInitialUrl)
			if sInitialUrl.find('://') == -1: sInitialUrl = 'http://' + sInitialUrl
			oBrowser = twill.get_browser()
			oBrowser.go(sInitialUrl)
			l = list(oBrowser._browser.links())
			dUrls = {sInitialUrl : 'Initial URL'}
			oLink = uri.URI(sInitialUrl)
			oLink.url = sInitialUrl
			oLink.text = 'Initial URL'
			lLinks = [oLink,]
			for o in l:
				sUrl = utf16str(o.absolute_url)
				sText = utf16str(o.text)
				if dUrls.has_key(sUrl) and len(dUrls[sUrl]) >= len(sText): continue
				oLink = uri.URI(sUrl)
				oLink.url = sUrl
				oLink.text = sText
				if not dUrls.has_key(sUrl): lLinks.append(oLink)
				dUrls[sUrl] = sText

			lExtensions = []
			for sUrl in dUrls.keys():
				oUri = uri.URI(sUrl)
				sPath = oUri.path
				sExtension = os.path.splitext(sPath)[1]
				if not sExtension: continue
				sExtension = sExtension[1:].lower()
				if not sExtension in lExtensions: lExtensions.append(sExtension)

			lExtensions.sort()
			sExtensions = ' '.join(lExtensions)
			sExtensions = lbc.DialogInput(title='Input', label='Extensions', value=sExtensions)
			if not sExtensions: return
			lExtensions = sExtensions.split()
			lExtensions = ['.' + sExtension for sExtension in lExtensions if sExtension]
			lUrls = [utf16str(oLink.text) + ' = ' + utf16str(oLink.url) for oLink in lLinks if os.path.splitext(oLink.path)[1].lower() in lExtensions]
			# print 'count', len(lUrls)
			# for sUrl in lUrls: print sUrl
			DialogDownload(lUrls)
		elif sButton.startswith('Weather'):  
			# google_result = pywapi.get_weather_from_google('10001')
			sLocation = ReadValue('LocationID')
			if not sLocation: sLocation = ReadValue('ZipCode')
			sLocation = lbc.DialogInput(title='Input', label='Location', value=sLocation)
			if not sLocation: return
			
			WriteValue('LocationID', sLocation)
			try: dYahoo = pywapi.get_weather_from_yahoo(sLocation) ; bFound = True
			except: bFound = False
			if bFound:
				AddStatus('Setting view area and opeing web page')
				# print "Yahoo says: It is " + string.lower(yahoo_result['condition']['text']) + " and " + yahoo_result['condition']['temp'] + "C now in New York.\n\n"
				sText = RemoveHtmlTags(dYahoo['html_description'])
				sText = RegExpReplace(sText, r'Full Forecast(.|\n)+', '')
				sTitle = dYahoo['condition']['title']
				# sText = 'Yahoo and Weather Channel Information\r\n' + 'Location ID ' + sLocation + '\r\n\r\n' + sText
				sText = 'Yahoo and Weather Channel Information\r\n' + sTitle + '\r\n\r\n' + sText
				sText = sText.strip()
				# AddStatus('Setting view area')
				memo.SetValue(sText)
				memo.SetFocus()
				memo.SetInsertionPoint(0)
			else: AddStatus('Opening web page')

			sAddress = 'http://braille.wunderground.com/cgi-bin/findweather/hdfForecast'
			dData = {'brand' : 'braille', 'query' : sLocation}
			sQuery = utf8urlencode(dData)
			sAddress += '?' + sQuery
			os.startfile(sAddress)

		elif sButton.startswith('Extra'):    
			sWordInfo = ReadValue('WordInfo')
			if not sWordInfo: sWordInfo = ReadValue('DictionaryLookup')
			sWordInfo = lbc.DialogInput(title='Input', label='Word', value=sWordInfo)
			if not sWordInfo: return
			WriteValue('WordInfo', sWordInfo)
			AddStatus('Please wait')
			sAddress = 'http://api.wordnik.com/api/word.json/' + sWordInfo + '/definitions'
			dData = {'api_key' : '582e51dde9940b44120020cf4c80f871af2430e98b76dd698'}
			try: sResponse = WebRequestGet(sAddress, dData)
			except: AddStatus('No information available!')
			lDefinitions = simplejson.loads(sResponse)
			sText = Pluralize('Definition', len(lDefinitions)) + ' of ' + sWordInfo + ' from wordnik.com\r\n\r\n'
			# for dDefinition in lDefinitions: sText += dDefinition['headword'] + (', ' + dDefinition['partOfSpeech'] if dDefinition.has_key('partOfSpeech') else '') + '\r\n' + dDefinition['defTxtSummary'] + ('\r\n' + dDefinition.get('defTxtExtended', '')).rstrip() + '\r\n\r\n'
			for dDefinition in lDefinitions: sText += (dDefinition['partOfSpeech'] + '\r\n' if dDefinition.has_key('partOfSpeech') else '').lstrip() + dDefinition['defTxtSummary'] + ('\r\n' + dDefinition.get('defTxtExtended', '')).rstrip() + '\r\n\r\n'
			sDefinitions = sText.strip()

			sAddress = 'http://api.wordnik.com/api/word.json/' + sWordInfo + '/examples'
			dData = {'api_key' : '582e51dde9940b44120020cf4c80f871af2430e98b76dd698'}
			sResponse = WebRequestGet(sAddress, dData)
			lExamples = simplejson.loads(sResponse)
			sText = Pluralize('Example', len(lExamples)) + ' of ' + sWordInfo + ' from wordnik.com\r\n\r\n'
			# for dExample in lExamples: print dExample.keys()
			for dExample in lExamples: sText += (str(dExample['year']) + '\r\n' if dExample.has_key('year') else '') + dExample['title'] + '\r\n' + dExample['url'] + ('\r\n' + dExample.get('display', '')).rstrip() + '\r\n\r\n'
			sExamples = sText.strip()

			sApiKey = '20f06c210d4894da53dcb065925e0158'
			# sAddress = 'http://words.bighugelabs.com/api/2/' + sApiKey + '/' + sWordInfo + ' + '/json'
			sAddress = 'http://words.bighugelabs.com/api/2/' + sApiKey + '/' + sWordInfo + '/'
			sResponse = WebRequestGet(sAddress)
			sResponse = sResponse.replace('|syn|', '|synonym|')
			sResponse = sResponse.replace('|ant|', '|antonym|')
			sResponse = sResponse.replace('|rel|', '|related term|')
			sResponse = sResponse.replace('|sim|', '|similar term|')
			sResponse = sResponse.replace('|usr|', '|user suggestion|')
			sResponse = sResponse.strip()
			lResults = sResponse.split('\n')
			sText = Pluralize('Result', len(lResults)) + ' from BigHugeLabs.com\r\n\r\n'
			for sResult in lResults:
				lParts = sResult.split('|')
				sText += lParts[0] + ', ' + lParts[1] + '\r\n' + lParts[2] + '\r\n\r\n'

			sText = (sDefinitions + '\r\n\r\n\r\n' + sExamples + '\r\n\r\n\r\n' + sText).strip()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)

		elif sButton.startswith('Yahoo!'):    
			sWebContent = GetUrl()
			if not sWebContent: sWebContent = ReadValue('WebContent')
			sWebContent = lbc.DialogInput(title='Input', label='Web Content', value=sWebContent)
			if not sWebContent: return
			AddStatus('Please wait')
			WriteValue('WebContent', sWebContent)
			if sWebContent.find('://') == -1: sWebContent = 'http://' + sWebContent
			sHtml = WebRequestGet(sWebContent)
			sText = HtmlToText(sHtml)
			oSearch = TermExtraction(app_id="ofjjsj7V34FERPRQJW.uOeIOJcBSpM8fMZ.0S2rC7j45C9o3L4v.NbTjIkVPCHOJU9Q-", query="Yahoo")
			oSearch.context = sText
			lTerms = oSearch.parse_results()
			# print type(lTerms)
			sText = ''
			i = 0
			for sTerm in lTerms: i += 1; sText += sTerm + '\r\n'
			sText = Pluralize('Yahoo! Term Extraction', i) + ' from ' + sWebContent + '\r\n\r\n' + sText
			sText = sText.strip()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)

		elif sButton.startswith('ZoomInfo'): 
			sApiKey = 'bc3txdwxaktwdekkttjqdgp5'
			sAddress = 'http://api.zoominfo.com/PartnerAPI/XmlOutput.aspx'
			lNames = 'FirstName LastName EmailAddress'.split()
			dData = {'query_type' : 'people_search_query', 'pc' : sApiKey}
			lValues = []
			for sName in lNames: sValue = ReadValue('ZoomInfo' + sName); lValues.append(sValue)
			lResults = lbc.DialogMultiInput(title='Multi Input', labels=lNames, values=lValues)
			if not lResults: return
			for i, sName in enumerate(lNames): 
				sResult = lResults[i].strip()
				WriteValue('ZoomInfo' + sName, sResult)
				if sResult and sName.startswith('Email'): dData[sName] = sResult
				elif sResult: dData[sName[0:1].lower() + sName[1:]] = sResult

			AddStatus('Please wait')
			# sResponse = WebRequestGet(sAddress, dData)
			sAddress += '?' + utf8urlencode(dData)
			fResponse = urllib.urlopen(sAddress)
			sPrefix = '{http://partners.zoominfo.com/PartnerAPI/XSD/PeopleQuery.xsd}'
			oRoot = ET.parse(fResponse).getroot()
			# lPersons = oRoot[2]
			lPersons = oRoot.findall('.//' + sPrefix + 'PersonRecord')
			if not lPersons: return AddStatus('No information available!')
			sText = Pluralize('Result', len(lPersons)) + ' from ZoomInfo.com\r\n\r\n'
			for oPerson in lPersons: 
				sText += oPerson.findtext(sPrefix + 'FirstName') + ' ' + oPerson.findtext(sPrefix + 'LastName') + '\r\n'
				sText += oPerson.findtext('.//' + sPrefix + 'JobTitle') + '\r\n'
				sText += oPerson.findtext('.//' + sPrefix + 'CompanyName') + '\r\n'
				sText += '\r\n'

			sText = sText.strip()
			AddStatus('Setting view area')
			memo.SetValue(sText)
			memo.SetFocus()
			memo.SetInsertionPoint(0)



	elif name == 'Button_Unblock': 
		if lbc.DialogConfirm(title='Confirm', message='Unblock\n' + sUserName + '\nso you can be followed?', value='Y') <> 'Y': return
		t.block_destroy(id=sUserID)

	elif name == 'Button_Write': 
		if not sUserName: return AddStatus('No user specified!')
		DirectSend()

	elif name == 'Button_Extra': 
		sText = ''
		item = GetSourceItem()
		if isattr(item, 'in_reply_to_status_id'):
			result = t.status_show(item.in_reply_to_status_id)
			sText = 'Prior Message\n'
			sText += GetPriorMessage(result) + '\n\n'

		if not sUserID: sUserID = sMyUserID
		# print 'userID', sUserID
		# result = t.user_show(id=sUserID)
		result = t.user_show(id=GetIDName(sUserName, sUserID))
		sText += 'Selected User\n'
		sText += GetResultText(result)
		# pp = pprint.PrettyPrinter()
		# sText = pp.pformat(d)
		# d = eval(sText)
		iIndex = memo.GetInsertionPoint()
		memo.SetValue(sText)
		memo.SetFocus()
		memo.SetInsertionPoint(0)

	elif name == 'Button_Help': 
		AddStatus('Setting view area and opening two web pages')
		sText = oSt.ReadFile(file_help)
		i = sText.index(']')
		sText = 'McTwit 2.7\nMarch 7, 2010\nSummary of Commands\n\n' + sText[i + 1:].replace('\n', '\n\n').strip()
		memo.SetFocus()
		memo.SetValue(sText)
		memo.SetInsertionPoint(0)
		os.startfile(file_guide)
		time.sleep(1)
		os.startfile(twitter_guide)

	elif name == 'Button_0items':
		lst.Clear()
		lbl.SetLabel('&Items')
		memo.Clear()

	elif name == 'Button_1other':
		sText = lbc.DialogInput(title='Screen Name', label='Text', value=s1otherName)
		if sText == None: return
		s1otherName = sText.strip()
		if s1otherName: 
			try: result = t.user_show(id=s1otherName)
			except: return AddStatus('Not found!')
			d = simplejson.loads(result)
			s1otherID = utf16str(d['id'])
			s1otherName = d['screen_name']
			s1otherFullName = d['name']
			AddStatus('Set to ' + s1otherName + ' (' + s1otherFullName + ')')
		else:
			AddStatus('No other user')
			s1otherName = ''
			s1otherFullName = ''
			s1otherID = ''

		WriteValue('1otherName', s1otherName)
		WriteValue('1otherFullName', s1otherFullName)
		WriteValue('1otherID', s1otherID)
		# print 'here', s1otherName, s1otherFullName, s1otherID

	elif name == 'Button_4get':
		sChoice = lbc.DialogConfirm(title='Confirm', message='Ignore whether messages have been previously shown?', value=('Y' if b4get else 'N'))
		if not sChoice: return
		if sChoice == 'Y': AddStatus('Yes'); b4get = True
		else: AddStatus('No'); b4get = False
		WriteValue('4get', bool2str(b4get))

	elif name == 'Button_5orite':
		msg = GetSourceItem()
		if not msg: return AddStatus('No message to mark as favorite!')
		sId = utf16str(msg.id)
		sUrl = r'http://twitter.com/favorites/create/' + sId + '.json'
		# sParams = {'screen_name':sMyUserName}
		dParams = {}
		sQuery = utf8urlencode(dParams)
		# sUrl += sQuery
		# print sUrl
		req = urllib2.Request(sUrl, sQuery)
		req.add_header(u'Authorization', t.auth)
		# req.add_header(u'X-Twitter-Client', t.agent)
		handle = urllib2.urlopen(req)
		response = handle.read()
		results = simplejson.loads(response)
		# print 'response\n', response
		ShowResult(response)

	elif name == r'Button_\cache':
		sItemType = 'Favorite Message'

		lMsg = data.StatusList()
		iPage = 1
		while True:
			sUrl = r'http://twitter.com/favorites.json?'
			sParams = {'screen_name':sMyUserName, 'id' : sUserID, 'page' : utf16str(iPage)}
			sQuery = utf8urlencode(sParams)
			sUrl += sQuery
			req = urllib2.Request(sUrl)
			req.add_header(u'Authorization', t.auth)
			handle = urllib2.urlopen(req)
			response = handle.read()
			l = data.StatusList(response, itemType='Favorite Message')

			if l.error: AddStatus('Error!'); break
			if not l: break
			if iPage > 1: AddStatus('Page ' + utf16str(iPage))
			lMsg.extend(l)
			# if len(l) < 20: break
			if iPageBoundary and iPage == iPageBoundary: break
			iPage += 1

		PopulateMessages(dlg, lMsg, sItemType)

	elif name == 'Button_|blocked':
		sItemType = 'Blocked User'

		lUser = data.UserList()
		iPage = 1
		while True:
			sUrl = r'http://twitter.com/blocks/blocking.json?'
			sParams = {'page' : utf16str(iPage)}
			sQuery = utf8urlencode(sParams)
			sUrl += sQuery
			req = urllib2.Request(sUrl)
			req.add_header(u'Authorization', t.auth)
			handle = urllib2.urlopen(req)
			response = handle.read()
			# print 'response', response
			l = data.UserList(response, itemType=sItemType)
			# print 'l', len(l)

			if l.error: AddStatus('Error!'); break
			if not l: break
			if iPage > 1: AddStatus('Page ' + utf16str(iPage))
			lUser.extend(l)
			# if len(l) < 20: break
			if iPageBoundary and iPage == iPageBoundary: break
			iPage += 1

		# print 'lUser', len(lUser)
		PopulateUsers(dlg, lUser, sItemType)

	elif name == 'Button_7update':
		"""
name. Optional. Maximum of 20 characters.
email. Optional. Maximum of 40 characters. Must be a valid email address.
url. Optional. Maximum of 100 characters. Will be prepended with "http://" if not present.
location. Optional. Maximum of 30 characters. The contents are not normalized or geocoded in any way.
description. Optional. Maximum of 160 characters.
		"""

		AddStatus('Please wait')
		sResponse = t.user_show(id=sMyUserName)
		dResponse = simplejson.loads(sResponse)
		for k, v in dResponse.items(): dResponse[k] = utf16str(v)
		# return
		sNewUserFullName = dResponse['name']
		# sEmail = dResponse['email']
		sUrl = dResponse['url']
		sDescription = dResponse['description']
		sLocation = dResponse['location']
		# print sNewUserFullName, sEmail, sUrl, sDescription, sLocation
		
		# lLabels = 'Name Email URL Description Location'.split()
		lLabels = ('Full Name', 'URL', 'Description', 'Location')
		# lValues = [sNewUserFullName, sEmail, sUrl, sDescription, sLocation]
		lValues = [sNewUserFullName, sUrl, sDescription, sLocation]
		lResults = lbc.DialogMultiInput(title='Profile', labels=lLabels, values=lValues, statusbar=True, ini=file_help)
		if not lResults: return
		# dParams = {'name' : sNewUserFullName, 'email' : sEmail, 'url' : sUrl, 'description' : sDescription, 'location' : sLocation}
		sNewUserFullName = lResults[0]
		# sEmail = lResults[1]
		sUrl = lResults[1]
		sDescription = lResults[2]
		sLocation = lResults[3]
		dParams = {'name' : sNewUserFullName, 'url' : sUrl, 'description' : sDescription, 'location' : sLocation}
		sParams = utf8urlencode(dParams)
		sUrl = 'http://twitter.com/account/update_profile.json'
		req = urllib2.Request(sUrl, sParams)
		req.add_header(u'Authorization', t.auth)
		fResponse = urllib2.urlopen(req)
		sResponse = fResponse.read()
		# print sResponse
		dResponse = simplejson.loads(sResponse)
		# print dResponse['name'], dResponse['url']
		ShowResult(sResponse)

	elif name == 'Button_Duplic8':
		if bDuplic8: 
			AddStatus('No recording')
			bDuplic8 = False
		else:
			AddStatus('Record to file')
			bDuplic8 = True

		WriteValue('Duplic8', bool2str(bDuplic8))

	elif name == 'Button_9rewind':
		sItemType = 'Reply Message'
		lMsg = data.StatusList(itemType=sItemType)
		item = GetSourceItem()
		if not isattr(item, 'in_reply_to_status_id'): return AddStatus('No reply chain found!')
		while isattr(item, 'in_reply_to_status_id'):
			lMsg.append(item)
			result = t.status_show(item.in_reply_to_status_id)
			d = simplejson.loads(result)
			item = data.Status(d, itemType=sItemType)
			# print 'd', d
			# print 'item', item

		if isattr(item, 'id'): lMsg.append(item)
		# print 'count', len(lMsg)
		PopulateMessages(dlg, lMsg, sItemType)

	elif name == 'Button_,bine': GetCombinedMessages()

	elif name == 'Button_.auto': 
		sText = lbc.DialogInput(title='Time between Combined Checks', label='Minutes', value=utf16str(iPeriodAuto))
		if sText == None: return
		iPeriodAuto = str2int(sText)
		WriteValue('PeriodAuto', utf16str(iPeriodAuto))
		if tmr.IsRunning(): tmr.Stop()
		if not iPeriodAuto: return AddStatus('No auto check')
		bResult = tmr.Start(iPeriodAuto * 60000)
		return AddStatus('Set to ' + Pluralize('minute', iPeriodAuto))

	elif name == 'Button_[store':  
		lOldSourceItems = lst.SourceItems[:]
		sOldSourceLabel = lbl.GetLabel()
		sOldSourceType = lst.SourceType
		lOldSourceOriginal = lst.SourceOriginal[:]
		iOldSelectedIndex = lst.GetSelection()
		sOldView = memo.GetValue()
		iOldPoint = memo.GetInsertionPoint()
		lOldItemData = [(lst.GetString(i), lst.GetClientData(i)) for i in range(lst.GetCount())]

	elif name == 'Button_]restore':  
		if lOldSourceItems == None: return AddStatus('No items to restore!')
		lbl.SetLabel(sOldSourceLabel)
		lst.SourceType = sOldSourceType
		lst.Clear()
		for a in lOldItemData: lst.Append(item=a[0], clientData=a[1])
		lst.SourceItems = lOldSourceItems[:]
		lst.SourceOriginal = lOldSourceOriginal[:]
		if iOldSelectedIndex >= 0: lst.SetSelection(iOldSelectedIndex)
		memo.SetValue(sOldView)
		memo.SetInsertionPoint(iOldPoint)

	elif name == 'Button_/search':  
		lButtons = 'Messages Users'.split()
		sButton = lbc.DialogChoose(title='Choose', message='', names =lButtons)
		if sButton == 'Cancel': return
		AddStatus(sButton)
		if sButton == 'Users':
			sPeopleSearch = ReadValue('PeopleSearch')
			sPeopleSearch = lbc.DialogInput(title='Input', label='Search', value=sPeopleSearch)
			if not sPeopleSearch: return
			
			WriteValue('PeopleSearch', sPeopleSearch)
	
			sItemType = 'Found User'
	
			lUser = data.UserList()
			iPage = 1
			while True:
				sUrl = r'http://api.twitter.com/1/users/search.json?'
				sParams = {'q' : sPeopleSearch, 'page' : iPage}
				sQuery = utf8urlencode(sParams)
				sUrl += sQuery
				req = urllib2.Request(sUrl)
				req.add_header(u'Authorization', t.auth)
				handle = urllib2.urlopen(req)
				response = handle.read()
				# print 'response', response
				l = data.UserList(response, itemType=sItemType)
				# print 'l', len(l)
	
				if l.error: AddStatus('Error!'); break
				if not l: break
				if iPage > 1: AddStatus('Page ' + utf16str(iPage))
				lUser.extend(l)
				# if len(l) < 20: break
				if iPageBoundary and iPage == iPageBoundary: break
				iPage += 1
	
			# print 'lUser', len(lUser)
			PopulateUsers(dlg, lUser, sItemType)
			return
	
		else:
			sMessageSearch = ReadValue('MessageSearch')
			sMessageSearch = lbc.DialogInput(title='Input', label='Search', value=sMessageSearch)
			if not sMessageSearch: return
			
			WriteValue('MessageSearch', sMessageSearch)
	
			sUserName = ''
			sUserID = ''
			sItemType = 'Search Message'
			lMsg = data.SearchList()
			iPage = 1
			while True:
				params = {'q':sMessageSearch, 'page' : utf16str(iPage)}
				query = utf8urlencode(params)
				sUrl = "http://search.twitter.com/search.json?%s" % query
				results = simplejson.load(urllib.urlopen(sUrl))['results']
				l = data.SearchList(results)
				if l.error: AddStatus('Error!'); break
				if not l: break
				if iPage > 1: AddStatus('Page ' + utf16str(iPage))
				lMsg.extend(l)
				# # if len(l) < 20: break
				if len(l) < 15: break
				if iPageBoundary and iPage == iPageBoundary: break
				iPage += 1
	
			PopulateMessages(dlg, lMsg, sItemType)
			return
	
		params = {'q':sMessageSearch}
		query = utf8urlencode(params)
		sUrl = "http://search.twitter.com/search.json?%s" % query
		results = simplejson.load(urllib.urlopen(sUrl))['results']
		lMsg = data.SearchList(results)
		sItemType = 'Search Message'
		PopulateMessages(dlg, lMsg, sItemType)

	elif name == 'Button_?relationship':    
		if not user and not s1otherName: return AddStatus('Comparison needs two users!')
		if user:sUserAName = user.screen_name; sUserAFullName = user.name
		else:sUserAName = s1otherName; sUserAFullName = s1otherFullName
		if user and s1otherName:sUserBName = s1otherName; sUserBFullName = s1otherFullName
		else: sUserBName = sMyUserName; sUserBFullName = sMyUserFullName
		
		sResult = IsUserAFollowingUserB(sUserAName, sUserBName)
		if len(sResult) > 5: return AddStatus(sResult)
		l = []

		if sResult == 'true': l.append(sUserAName + ' (' + sUserAFullName + ') follows ' + sUserBName + ' (' + sUserBFullName + ')')
		if IsUserAFollowingUserB(sUserBName, sUserAName) == 'true': l.append(sUserBName + ' (' + sUserBFullName + ') follows ' + sUserAName + ' (' + sUserAFullName + ')')
		if not l: return AddStatus('None')
		for s in l: AddStatus(s)


	elif name == 'Button_-trends':  
		sUrl = 'http://search.twitter.com/trends.json'
		results = simplejson.load(urllib.urlopen(sUrl))['trends']
		# return lbc.DialogShow(title='Trends', message=utf16str(results))
		lMsg = data.TrendList(results)
		sItemType = 'Trend Message'
		PopulateMessages(dlg, lMsg, sItemType)

	elif name == 'Button_=balance':  
		sUrl = 'http://twitter.com/account/rate_limit_status.json?'
		sParams = {'screen_name':sMyUserName}
		sQuery = utf8urlencode(sParams)
		sUrl += sQuery
		req = urllib2.Request(sUrl)
		req.add_header(u'Authorization', t.auth)
		handle = urllib2.urlopen(req)
		response = handle.read()
		results = simplejson.loads(response)
		# results = simplejson.load(t.account_rate_limit_status(True))
		# lKeys = ['remaining_hits', 'reset_time']
		lKeys = ['remaining_hits']
		sText = ''
		for sKey in lKeys:
			sValue = utf16str(results[sKey])
			if not sValue.strip(): continue
			if sKey == 'reset_time': sValue = FormatDateTime(sValue)
			sKey = sKey.replace('_', ' ')
			sText += sKey +': ' + sValue + '\n'
	
		sText = sText.strip()
		sText = utf16str(results['remaining_hits'])
		return AddStatus(sText)
		memo.SetValue(sText)
		memo.SetInsertionPoint(0)
		memo.SetFocus()
	
	elif name == 'Button_+elevate':    
		# win32api.WinExec('"' + file_elevate + '" "' + file_elevate_ini + '"')
		# os.spawnv(0, file_elevate, ('.', file_elevate_ini))
		win32api.ShellExecute(0, None, file_elevate, file_elevate_ini, '', 1)

"""
self.timer = wx.Timer(self)
self.Bind(wx.EVT_TIMER, self.OnTimer, self.timer)
self.timer.Start(1000)
t = time.localtime(time.time())
st = time.strftime("%I:%M:%S", t)
wx.FutureCall(interval, callable, *args, **kwargs)
"""

def AddLine(sText):
	sReturn = sText.strip()
	if sReturn: sReturn += '\r\n'
	return sReturn


def GetQuotesOfTheDay():
	dResult = feedparser.parse('http://www.quotationspage.com/data/mqotd.rss')
	dFeed = dResult.feed
	lEntries = dResult.entries
	sText = Pluralize('Motivational Quote', len(lEntries)) + ' of the Day from QuotationsPage.com\r\n\r\n'
	for oEntry in lEntries:
		sTitle_detail = oEntry.title_detail
		s = oEntry.description
		sMatch = r'\".*?\"'
		sItem = RegExpExtract(s, sMatch)[0]
		sText += sItem + '\r\n' + oEntry.title + '\r\n\r\n'
	sText = sText.strip()
	return sText
	
	
def HtmlToText(sHtml):
	oDoc = comtypes.client.CreateObject('HTMLFile')
	oDoc.write(sHtml)
	oBody = oDoc.body
	sText = oBody.innerText
	return sText

def GetUrl():
	sText = ''
	item = GetSourceItem()
	if isattr(item, 'url'): sText = item.url
	elif item: sText = item.text
	sMatch = r'(\bwww\.|\w+://)[^\s"]+'
	regexp = re.compile(sMatch, re.I)
	oMatch = regexp.search(sText)
	if oMatch: sUrl = oMatch.group()
	else: sUrl = GetIEUrl()
	return sUrl
	
def GetIEUrl():
	url = ''
	# shell = win32com.client.Dispatch('Shell.Application')
	shell = comtypes.client.CreateObject('Shell.Application')
	windows = shell.Windows()
	count = windows.Count
	if count == 0: return url
	try:
		i = count - 1
		window = windows.Item(i)
		url = window.LocationURL
	except: pass
	return url
	
def ShellRun(sFile, iStyle, bWait):
	# Launch a program or file, indicating its window style and whether to wait before returning
	# window styles:
	# 0 Hides the window and activates another window.
	# 1 Activates and displays a window. If the window is minimized or maximized, the
	# system restores it to its original size and position. This flag should be used
	# when specifying an application for the first time.
	# 2 Activates the window and displays it minimized.
	# 3 Activates the window and displays it maximized.
	# 4 Displays a window in its most recent size and position. The active window
	# remains active.
	# 5 Activates the window and displays it in its current size and position.
	# 6 Minimizes the specified window and activates the next top-level window in the Z
	# order.
	# 7 Displays the window as a minimized window. The active window remains active.
	# 8 Displays the window in its current state. The active window remains active.
	# 9 Activates and displays the window. If it is minimized or maximized, the system
	# restores it to its original size and position. An application should specify
	# this flag when restoring a minimized window.
	# 10 Sets the show state based on the state of the program that started the
	# application.
	
	oShell =comtypes.client.CreateObject('Wscript.Shell')
	try: iReturn = oShell.Run(sFile, iStyle, bWait)
	except: iReturn = -2
	return iReturn
	
# def RunBackground(sCommand): win32api.ShellExecute(0, None, sCommand, '', '', 4)
# def RunBackground(sCommand): ShellRun(sCommand, 7, 0)
# def RunBackground(sCommand): ShellRun('IExplore.exe ' + sCommand, 7, 0)
def RunBackground(sCommand):
	h = dlg.GetHandle()
	os.startfile(sCommand)
	# win32api.Sleep(1000)
	win32api.Sleep(500)
	lbc.ActivateWindow(h)

def GetContentType(sUrl):
	fResponse = urllib2.urlopen(sUrl)
	sFinalUrl = fResponse.geturl()
	dInfo = fResponse.info()
	dHeaders = fResponse.headers
	sType = dHeaders.type
	# print 'url', sFinalUrl
	# print 'type', sType
	return sType

def IsWebPage(url): return GetContentType(url).startswith('text/html')

def DialogDownload(lItems =[]):
	dlgDownload = lbc.Dialog(title='URLs')
	lNames = lItems
	lValues = lNames[:]
	lstUrls = dlgDownload.AddListBox(label='Links', names=lNames, values=lValues, style=lbc.DEFAULT_STYLE | wx.LB_MULTIPLE, sort=False)
	for i in range(len(lItems)): lstUrls.SetSelection(i)
	lstUrls.SetSelection(0)
	# dlgDownload.AddBand()
	# lButtons = 'Download All None Close'.split()
	# if dlgDownload.Complete(lButtons) != wx.ID_OK: return
	if dlgDownload.Complete() != wx.ID_OK: return
	sDownloadFolder = ReadValue('DownloadFolder')
	sDownloadFolder = lbc.DialogBrowseForFolder(value=sDownloadFolder)
	if not sDownloadFolder: return
	WriteValue('DownloadFolder', sDownloadFolder)
	lNames = [lstUrls.GetString(i) for i in lstUrls.GetSelections()]
	lUrls = [sItem.split(' = ')[1] for sItem in lItems]
	AddStatus('Downloading')
	for sUrl in lUrls:
		oUrl = uri.URI(sUrl)
		sPath = oUrl.path
		sBase = os.path.basename(sPath)
		sFile = os.path.join(sDownloadFolder, sBase)
		AddStatus(sBase)
		try: urllib.urlretrieve(sUrl, sFile)
		except: AddStatus('Error!')
	
def DialogTranslateLanguage(sText=''):
	dDetectLanguages = {}
	dDetectLanguages['AFRIKAANS'] = 'af'
	dDetectLanguages['ALBANIAN'] = 'sq'
	dDetectLanguages['AMHARIC'] = 'am'
	dDetectLanguages['ARABIC'] = 'ar'
	dDetectLanguages['ARMENIAN'] = 'hy'
	dDetectLanguages['AZERBAIJANI'] = 'az'
	dDetectLanguages['BASQUE'] = 'eu'
	dDetectLanguages['BELARUSIAN'] = 'be'
	dDetectLanguages['BENGALI'] = 'bn'
	dDetectLanguages['BIHARI'] = 'bh'
	dDetectLanguages['BULGARIAN'] = 'bg'
	dDetectLanguages['BURMESE'] = 'my'
	dDetectLanguages['CATALAN'] = 'ca'
	dDetectLanguages['CHEROKEE'] = 'chr'
	dDetectLanguages['CHINESE'] = 'zh'
	dDetectLanguages['CHINESE_SIMPLIFIED'] = 'zh-CN'
	dDetectLanguages['CHINESE_TRADITIONAL'] = 'zh-TW'
	dDetectLanguages['CROATIAN'] = 'hr'
	dDetectLanguages['CZECH'] = 'cs'
	dDetectLanguages['DANISH'] = 'da'
	dDetectLanguages['DHIVEHI'] = 'dv'
	dDetectLanguages['DUTCH'] = 'nl'
	dDetectLanguages['ENGLISH'] = 'en'
	dDetectLanguages['ESPERANTO'] = 'eo'
	dDetectLanguages['ESTONIAN'] = 'et'
	dDetectLanguages['FILIPINO'] = 'tl'
	dDetectLanguages['FINNISH'] = 'fi'
	dDetectLanguages['FRENCH'] = 'fr'
	dDetectLanguages['GALICIAN'] = 'gl'
	dDetectLanguages['GEORGIAN'] = 'ka'
	dDetectLanguages['GERMAN'] = 'de'
	dDetectLanguages['GREEK'] = 'el'
	dDetectLanguages['GUARANI'] = 'gn'
	dDetectLanguages['GUJARATI'] = 'gu'
	dDetectLanguages['HEBREW'] = 'iw'
	dDetectLanguages['HINDI'] = 'hi'
	dDetectLanguages['HUNGARIAN'] = 'hu'
	dDetectLanguages['ICELANDIC'] = 'is'
	dDetectLanguages['INDONESIAN'] = 'id'
	dDetectLanguages['INUKTITUT'] = 'iu'
	dDetectLanguages['ITALIAN'] = 'it'
	dDetectLanguages['JAPANESE'] = 'ja'
	dDetectLanguages['KANNADA'] = 'kn'
	dDetectLanguages['KAZAKH'] = 'kk'
	dDetectLanguages['KHMER'] = 'km'
	dDetectLanguages['KOREAN'] = 'ko'
	dDetectLanguages['KURDISH'] = 'ku'
	dDetectLanguages['KYRGYZ'] = 'ky'
	dDetectLanguages['LAOTHIAN'] = 'lo'
	dDetectLanguages['LATVIAN'] = 'lv'
	dDetectLanguages['LITHUANIAN'] = 'lt'
	dDetectLanguages['MACEDONIAN'] = 'mk'
	dDetectLanguages['MALAY'] = 'ms'
	dDetectLanguages['MALAYALAM'] = 'ml'
	dDetectLanguages['MALTESE'] = 'mt'
	dDetectLanguages['MARATHI'] = 'mr'
	dDetectLanguages['MONGOLIAN'] = 'mn'
	dDetectLanguages['NEPALI'] = 'ne'
	dDetectLanguages['NORWEGIAN'] = 'no'
	dDetectLanguages['ORIYA'] = 'or'
	dDetectLanguages['PASHTO'] = 'ps'
	dDetectLanguages['PERSIAN'] = 'fa'
	dDetectLanguages['POLISH'] = 'pl'
	dDetectLanguages['PORTUGUESE'] = 'pt'
	dDetectLanguages['PUNJABI'] = 'pa'
	dDetectLanguages['ROMANIAN'] = 'ro'
	dDetectLanguages['RUSSIAN'] = 'ru'
	dDetectLanguages['SANSKRIT'] = 'sa'
	dDetectLanguages['SERBIAN'] = 'sr'
	dDetectLanguages['SINDHI'] = 'sd'
	dDetectLanguages['SINHALESE'] = 'si'
	dDetectLanguages['SLOVAK'] = 'sk'
	dDetectLanguages['SLOVENIAN'] = 'sl'
	dDetectLanguages['SPANISH'] = 'es'
	dDetectLanguages['SWAHILI'] = 'sw'
	dDetectLanguages['SWEDISH'] = 'sv'
	dDetectLanguages['TAJIK'] = 'tg'
	dDetectLanguages['TAMIL'] = 'ta'
	dDetectLanguages['TAGALOG'] = 'tl'
	dDetectLanguages['TELUGU'] = 'te'
	dDetectLanguages['THAI'] = 'th'
	dDetectLanguages['TIBETAN'] = 'bo'
	dDetectLanguages['TURKISH'] = 'tr'
	dDetectLanguages['UKRAINIAN'] = 'uk'
	dDetectLanguages['URDU'] = 'ur'
	dDetectLanguages['UZBEK'] = 'uz'
	dDetectLanguages['UIGHUR'] = 'ug'
	dDetectLanguages['VIETNAMESE'] = 'vi'
	dDetectLanguages['UNKNOWN'] = ''
	
	dTranslateLanguages = {}
	dTranslateLanguages['Arabic'] = ''
	dTranslateLanguages['Bulgarian'] = ''
	dTranslateLanguages['Chinese'] = ''
	dTranslateLanguages['Catalan'] = ''
	dTranslateLanguages['Croatian'] = ''
	dTranslateLanguages['Czech'] = ''
	dTranslateLanguages['Danish'] = ''
	dTranslateLanguages['Dutch'] = ''
	dTranslateLanguages['English'] = ''
	dTranslateLanguages['Filipino'] = ''
	dTranslateLanguages['Finnish'] = ''
	dTranslateLanguages['French'] = ''
	dTranslateLanguages['German'] = ''
	dTranslateLanguages['Greek'] = ''
	dTranslateLanguages['Hebrew'] = ''
	dTranslateLanguages['Hindi'] = ''
	dTranslateLanguages['Indonesian'] = ''
	dTranslateLanguages['Italian'] = ''
	dTranslateLanguages['Japanese'] = ''
	dTranslateLanguages['Korean'] = ''
	dTranslateLanguages['Latvian'] = ''
	dTranslateLanguages['Lithuanian'] = ''
	dTranslateLanguages['Norwegian'] = ''
	dTranslateLanguages['Polish'] = ''
	dTranslateLanguages['Portuguese'] = ''
	dTranslateLanguages['Romanian'] = ''
	dTranslateLanguages['Russian'] = ''
	dTranslateLanguages['Spanish'] = ''
	dTranslateLanguages['Serbian'] = ''
	dTranslateLanguages['Slovak'] = ''
	dTranslateLanguages['Slovenian'] = ''
	dTranslateLanguages['Swedish'] = ''
	dTranslateLanguages['TURKISH'] = 'tr'
	dTranslateLanguages['Ukrainian'] = ''
	dTranslateLanguages['Vietnamese'] = ''
	dTranslateLanguages['Unknown'] = ''
	
	dLanguages = {}
	for sLanguage in dDetectLanguages.keys():
		if dTranslateLanguages.has_key(sLanguage):
			sAbbreviation = dDetectLanguages[sLanguage]
			dLanguages[sLanguage] = sAbbreviation
		
	dReverseLanguages = {}
	for sKey, sValue in dDetectLanguages.items(): dReverseLanguages[sValue] = sKey
	dlgTranslate = lbc.Dialog(title='Translate Language')
	lNames = [sKey for sKey in dDetectLanguages.keys()]
	lValues = lNames[:]
	lstSource = dlgTranslate.AddListBox(label='Source', names=lNames, values=lValues, sort=True)
	sSourceLanguage = ReadValue('SourceLanguage')
	if sText: sSourceLanguage = 'UNKNOWN'
	if sSourceLanguage: lstSource.SetStringSelection(sSourceLanguage)
	lNames = [sKey for sKey in dTranslateLanguages.keys()]
	lValues = lNames[:]
	lstTarget = dlgTranslate.AddListBox(label='Target', names=lNames, values=lValues, sort=True)
	sTargetLanguage = ReadValue('TargetLanguage')
	if not sTargetLanguage: sTargetLanguage = 'ENGLISH'
	if sTargetLanguage: lstTarget.SetStringSelection(sTargetLanguage)
	dlgTranslate.AddBand()
	memoContent = dlgTranslate.AddMemo(label='Text', value=sText)
	if dlgTranslate.Complete() != wx.ID_OK: return
	sSourceLanguage = lstSource.GetStringSelection()
	WriteValue('SourceLanguage', sSourceLanguage)
	sTargetLanguage = lstTarget.GetStringSelection().upper()
	WriteValue('TargetLanguage', sTargetLanguage)
	sSourceText = memoContent.GetValue()
	sDetectedLanguage = sSourceLanguage
	sText = sTargetLanguage
	sSourceLanguage = dDetectLanguages[sSourceLanguage.upper()]
	# print 'source', sSourceLanguage
	sTargetLanguage = dDetectLanguages[sTargetLanguage.upper()]
	sAddress = 'http://ajax.googleapis.com/ajax/services/language/translate'
	dData = {'q' : sSourceText, 'v' : '1.0', 'langpair' : sSourceLanguage + '|' + sTargetLanguage}
	dHeaders = {'Referer' : 'http://EmpowermentZone.com'}
	sResponse = WebRequestPost(sAddress, dData, dHeaders)
	try: 
		sResponse = WebRequestPost(sAddress, dData, dHeaders)
		# print 'response\n', sResponse
		dResponse = simplejson.loads(sResponse)
		# print dResponse
		dResult = dResponse['responseData']
		try: sDetectedLanguage = dResult['detectedSourceLanguage']; sDetectedLanguage = dReverseLanguages[sDetectedLanguage]
		except: pass
		sTargetText = dResult['translatedText']
		# print sTargetText
	except: return AddStatus('Error!')
	sText = 'Translation from ' + sDetectedLanguage + ' to ' + sText + '\r\n' + sSourceText + '\r\n\r\n'
	sText += sTargetText.strip()
	memo.SetValue(sText)
	memo.SetFocus()
	memo.SetInsertionPoint(0)

def GetLegislators(sZip):
	sText = ''
	sunlight.apikey = '1bf1192622ffc0bc7bc1de1bb470daf5'
	iCount = 0
	for legislator in sorted(sunlight.legislators.allForZip(sZip)):
		iCount += 1
		sText += '\r\n' + utf16str(legislator) + '\r\n'
		for sAttribute in sorted(legislator.__dict__.keys()): sText += sAttribute + ': ' + utf16str(legislator.__dict__[sAttribute]) + '\r\n'
		for com in sorted(sunlight.committees.allForLegislator(legislator.bioguide_id)):
			sText += utf16str(com) + '\r\n'
			for sc in sorted(com.subcommittees): sText += utf16str(sc) + '\r\n'

	sText = sText.strip()
	sText = Pluralize('Member', iCount) + ' of Congress\r\nFor zip code ' + sZip + '\r\n\r\n' + sText
	return sText

def RemoveHtmlTags(sHtml):
	sMatch = r'\<.*?\>'
	sReplace = ''
	sReturn = RegExpReplace(sHtml, sMatch, sReplace)
	sReturn = sReturn.strip()
	return sReturn
	
def FormatDecimal(n):
	sNumber = str(n)
	sMatch = r'(\.\d\d)\d+'
	sReplace = r'\1'
	sReturn = RegExpReplace(sNumber, sMatch, sReplace)
	return sReturn

def RegExpExtract(sText, sMatch):
	oRegExp = re.compile(sMatch, re.I)
	lReturn = oRegExp.findall(sText)
	return lReturn

def RegExpReplace(sText, sMatch, sReplace):
	oRegExp = re.compile(sMatch, re.I)
	sReturn = oRegExp.sub(sReplace, sText)
	return sReturn

def ParseHtml(sHtml):
	oParser = htmllib.HTMLParser(None)
	# print type(oParser)
	oParser.save_bgn()
	oParser.feed(sHtml)
	sText = oParser.save_end()
	return sText

def GetGoogleLocalSearch(sKeywords, sAddress):
	oMaps = GoogleMaps()
	oSearch = oMaps.local_search(sKeywords + ' ' + sAddress)
	aPlaces = oSearch['responseData']['results']
	sText = ''
	for dPlace in aPlaces: 
		sText += dPlace['titleNoFormatting'] + '\r\n'
		sText += dPlace['streetAddress'] + '\r\n'
		if len(dPlace['phoneNumbers']): sText += dPlace['phoneNumbers'][0]['number'] + '\r\n'
		# for dPhone in dPlace['phoneNumbers']: sText += dPhone['number'] + ' ' + dPhone['type'] + '\r\n'
		sText += '\r\n'

	for dPlace in aPlaces:
		for sKey in dPlace: print sKey + ': ' + type(dPlace[sKey]).__name__
	sText = sText.strip()
	return (len(aPlaces), sText)
	
def GetGoogleDrivingDirections(sStartAddress, sEndAddress):
	oMaps = GoogleMaps()
	oDirections = oMaps.directions(sStartAddress, sEndAddress)
	sDistance = oDirections['Directions']['Distance']['meters']
	sDuration = oDirections['Directions']['Duration']['seconds']
	lSteps = []
	for oStep in oDirections['Directions']['Routes'][0]['Steps']: lSteps.append(oStep['descriptionHtml'])
	return (sDistance, sDuration, lSteps)
	
def WebRequestPost(sUrl, dData=None, dHeaders=None, sUser=None, sPassword=None):
	sData = None
	if dData: sData = utf8urlencode(dData)
	# print 'data', sData
	oRequest = urllib2.Request(sUrl, sData)
	oRequest.add_header(u'Authorization', t.auth)
	for sKey, sValue in dHeaders.items(): oRequest.add_header(sKey, sValue)
	fResponse = urllib2.urlopen(oRequest)
	sResponse = fResponse.read()
	fResponse.close()
	return sResponse
	
def WebRequestGet(sUrl, dData=None, dHeaders=None, sUser=None, sPassword=None):
	sData = None
	if dData: sData = utf8urlencode(dData)
	if dData: sUrl += '?' + sData
	# print sUrl
	oRequest = urllib2.Request(sUrl)
	fResponse = urllib2.urlopen(oRequest)
	sResponse = fResponse.read()
	fResponse.close()
	return sResponse
	
def SetClipboard(sText):
	"""
	win32clipboard.OpenClipboard()
	win32clipboard.SetClipboardText(sText)
	return win32clipboard.CloseClipboard()
	"""

	oText = wx.TextDataObject(sText)
	wx.TheClipboard.Open()
	wx.TheClipboard.SetData(oText)
	wx.TheClipboard.Close()

def GetEpochTime(sCreatedAt):
	try: dt = datetime.strptime(sCreatedAt + ' UTC', '%a %b %d %H:%M:%S +0000 %Y %Z')
	except: dt = datetime.strptime(sCreatedAt, '%a, %d %b %Y %H:%M:%S +0000')
	return dt

def StrDefault(sText): return sText.encode(sDefaultEncoding, 'ignore')

def utf16str(sText):
	if sText == None: return''
	# elif isinstance(sText, bool) or isinstance(sText, int): return utf16str(sText)
	elif isinstance(sText, unicode): return unicode(sText)
	# elif isinstance(sText, str): return unicode(sText, sDefaultEncoding, 'ignore')
	elif isinstance(sText, str): return unicode(sText, 'utf-8', 'ignore')
	else: return unicode(sText)

def utf8str(sText): return utf16str(sText).encode('utf-8', 'ignore')

def utf8urlencode(l): return urllib.urlencode([(utf8str(k), utf8str(v)) for k, v in dict(l).items()])

def GetAttributeText(item):
	sText = ''
	lAttributes = [sAttribute for sAttribute in dir(item) if not sAttribute.startswith('_')]
	for sAttribute in lAttributes:
		# print 'attribute', sAttribute
		sValue = getattr(item, sAttribute, None)
		# print 'value', sValue
		# if sValue == None: continue
		if utf16str(sValue).find('method') >= 0: continue
		if isinstance(sValue, str) or isinstance(sValue, int) or isinstance(sValue, bool): sText += sAttribute.replace('_', ' ').title() + ': ' + utf16str(sValue) + '\n'
		else: sText += GetAttributeText(sValue)
	return sText

def GetUserID(sScreenName):
	f = t.user_show(id=sScreenName)
	d = simplejson.loads(f)
	return utf16str(d['id'])

def GetIDName(sUserName, sUserID):
	# print 'UserName', sUserName, 'userID', sUserID
	if sUserName == 'My': return sUserID
	elif str2int(sUserID): return sUserID
	# else: return sUserName
	else: return GetUserID(sUserName)

def StringMessage(msg): return '\t'.join((msg.text, msg.user.screen_name, msg.user.name))

def ExtensionEnhanced(): return str2bool(win32api.GetProfileVal('Configuration', 'EnhancedSpeech', 'y', file_extensions))

def MailEncode(text):
	sBody = text
	sBody = sBody.replace('\r\n', '\r')
	sBody = sBody.replace('\n', '\r')
	sBody = sBody.replace('\r', '\r\n')
	sBody = sBody.replace('\r\n', '%0D%0A')
	sBody = sBody.replace(' ', '%20')
	sBody = sBody.replace('\t', '%09')
	sBody = sBody.replace('"', '%22')
	sBody = sBody.replace("'", '%27')
	sBody = sBody.replace('\\', '%5C')
	return sBody
	
def LoadIni():
	global sb, sUserID, sUserName, sUserFullName, s1otherName, s1otherFullName, s1otherID, iPageBoundary, sQueryExp, b4get, iPeriodAuto, bDuplic8, sMyUserName, sMyUserID, sMyUserFullName, sMyPassword, lOldSourceItems, lOldSourceOriginal, iOldSelectedIndex, sOldView, iOldPoint, lOldItemData, bFullName, file_chimes, sOrderItems, sPriorityQuery, sJunkFilter, sCombinedProcessing, bEnhancedSpeech, bRelativeTime, file_ini
	tmr.Stop()
	iPeriodAuto = str2int(ReadValue('PeriodAuto', '0'))
	if iPeriodAuto: bResult = tmr.Start(iPeriodAuto * 60000)
	s1otherName = ReadValue('1otherName', '')
	s1otherFullName = ReadValue('1otherFullName', '')
	s1otherID = ReadValue('1otherID', '')
	b4get = str2bool(ReadValue('4get', 'n'))
	bDuplic8 = str2bool(ReadValue('Duplic8', 'n'))
	iPageBoundary = str2int(ReadValue('PageBoundary', '0'))
	sCombinedProcessing = ReadValue('CombinedProcessing', 'DRN')
	bEnhancedSpeech = str2bool(ReadValue('EnhancedSpeech', 'y'))
	bFullName = str2bool(ReadValue('FullName', 'n'))
	sJunkFilter = ReadValue('JunkFilter', '')
	sOrderItems = ReadValue('OrderItems', 'r')
	sPriorityQuery = ReadValue('PriorityQuery', '')
	bRelativeTime = str2bool(ReadValue('RelativeTime', 'n'))
	file_chimes = ReadValue('SoundFile', file_chimes)
	sMyUserName = ReadValue('User')
	sMyUserID = ReadValue('UserID')
	sMyUserFullName = ReadValue('FullName')
	sMyPassword = ReadValue('Password')
	t.set_auth(sMyUserName, sMyPassword)

	lOldSourceItems = None
	lOldSourceOriginal = None
	iOldSelectedIndex = None
	sOldView = None
	iOldPoint = None
	lOldItemData = []

	dlg.SetTitle('McTwit - ' + sMyUserName)
	lbl.SetLabel('&Items')
	lst.Clear()
	memo.Clear()
	# AddStatus('User set to ' + sMyUserName + ' (' + sMyUserFullName + ')')  
	AddStatus('User set to ' + sMyUserName)
	win32api.WriteProfileVal('Configuration', 'MainIni', file_ini, file_extensions)
	# print 'mainini', file_ini

def IsUserAFollowingUserB(sUserA, sUserB):
	sUrl = 'http://twitter.com/friendships/exists.json'	
	dParams = {'user_a' : sUserA, 'user_b' : sUserB}
	sParams = utf8urlencode(dParams)
	sUrl+= '?' + sParams
	req = urllib2.Request(sUrl)
	req.add_header(u'Authorization', t.auth)
	# fResponse = urllib.urlopen(sUrl)
	# fResponse = urllib.urlopen(req)
	fResponse = urllib2.urlopen(req)
	sResponse = fResponse.read()
	# print sUserA, sUserB, sResponse
	if sResponse == 'true' or sResponse == 'false': return sResponse
	dResponse = simplejson.loads(sResponse)
	# print 'dResponse', type(dResponse)
	return dResponse['error']

def UpdateTimeAndID(sOldType, sNewType):
	sTime = ReadValue(sOldType + 'Time', section=sUserName)
	sID = ReadValue(sOldType + ' ID', section=sUserName)
	WriteValue(sNewType + ' Time', sTime, section=sUserName)
	WriteValue(sNewType + ' ID', sID, section=sUserName)
	return sNewType

def FormatDateTime(sCreatedAt):
	sFormat = '%A, %B %d, %Y at %I:%M %p'
	try: dt = datetime.strptime(sCreatedAt, '%a %b %d %H:%M:%S +0000 %Y')
	except: dt = datetime.strptime(sCreatedAt, '%a, %d %b %Y %H:%M:%S +0000')
	iDelta = (datetime.utcnow() - datetime.now()).seconds / 3600
	if iDelta >=0: dt -= timedelta(hours=iDelta)
	else: dt += timedelta(hours=iDelta)
	sText = dt.strftime(sFormat)
	return sText

def GetDateAndTime(sCreatedAt):
	# print 'created_at', sCreatedAt
	sDateFormat = '%A, %B %d, %Y'
	sTimeFormat = '%I:%M %p'
	# try: dt = datetime.strptime(sCreatedAt, '%a %b %d %H:%M:%S +0000 %Y')
	try: dt = datetime.strptime(sCreatedAt + ' UTC', '%a %b %d %H:%M:%S +0000 %Y %Z')
	except: dt = datetime.strptime(sCreatedAt, '%a, %d %b %Y %H:%M:%S +0000')
	sDate = dt.strftime(sDateFormat)
	iDelta = (datetime.utcnow() - datetime.now()).seconds / 3600
	if iDelta >=0: dt -= timedelta(hours=iDelta)
	else: dt += timedelta(hours=iDelta)
	sTime = dt.strftime(sTimeFormat)
	return sDate, sTime


def GetRelativeTime(sCreatedAt):
	try: dt = datetime.strptime(sCreatedAt, '%a %b %d %H:%M:%S +0000 %Y')
	except: dt = datetime.strptime(sCreatedAt, '%a, %d %b %Y %H:%M:%S +0000')
	dtUtc = datetime.utcnow()
	delta = dtUtc - dt
	iDays = delta.days
	iSeconds = delta.seconds
	iHours = iSeconds / 3600
	if iHours < 1: iHours = 0
	iSeconds -= iHours * 3600
	iMinutes = iSeconds / 60
	if iMinutes < 1: iMinutes = 0
	iSeconds -= 60* iMinutes
	sText = ''
	if iDays: sText += Pluralize('day', iDays) + ', '
	if iHours: sText += Pluralize('hour', iHours) + ', '
	if not sText and iMinutes: sText += Pluralize('minute', iMinutes) + ', '
	if not sText and iSeconds: sText += Pluralize('second', iSeconds) + ', '
	sText = sText.strip(', ') + ' ago'
	return sText

def AppendExport(sText):
		if os.path.isfile(file_export): sOld = oSt.ReadFile(file_export)
		else: sOld = ''
		if sOld: sOld += '\n----------\n\f\n'
		sBody = sOld + sText
		oSt.WriteFile(file_export, sBody)
		# SetStatus('Done!')
		app.Export = True

def AppendJunk(sText):
		if os.path.isfile(file_junk): sOld = oSt.ReadFile(file_junk)
		else: sOld = ''
		# if sOld: sOld += '\n----------\n\f\n'
		# if sOld: sOld += '\n'
		sBody = sOld + sText
		oSt.WriteFile(file_junk, sBody)

def isattr(item, attribute): return hasattr(item, attribute) and getattr(item, attribute)

def GetSourceItem(iIndex=None):
	if iIndex == None: iIndex = lst.GetSelection()
	if iIndex == -1: return None
	iData = lst.GetClientData(iIndex)
	item = lst.SourceItems[iData]
	return item

def GetSourceOriginal(iIndex=None):
	if iIndex == None: iIndex = lst.GetSelection()
	if iIndex == -1: return None
	iData = lst.GetClientData(iIndex)
	iData = len(lst.SourceOriginal) - iData - 1
	a = lst.SourceOriginal[iData]
	return a

def GetDisplayText(iIndex=None):
	a = GetSourceOriginal(iIndex)
	if not a: return ''
	sText = a[0]
	return sText

def GetMemoText(iIndex=None):
	sText = GetDisplayText(iIndex)
	if not sText: return ''
	item = GetSourceItem(iIndex)
	# try: print item.retweeted_status[u'text']
	try: 
		sRetweet = item.retweeted_status[u'user']['screen_name'] + ' (' + item.retweeted_status[u'user']['name'] + ')'
		# print sRetweet
		sText += '\nRetweet from ' + sRetweet
	except: print 'None'
	sText += '\n\n'
	item = GetSourceItem(iIndex)
	# print 'sText', type(sText), 'itemText', type(GetItemText(item))
	sText = utf16str(sText)
	sText += GetItemText(item)
	sType = item.Type
	sText = sType + '\n' + sText
	if sType.endswith('User'): return sText
	if sType == 'Direct Message':
		sText += '\n\nSender ' + GetItemText(item.sender)
		sText += '\n\nRecipient ' + GetItemText(item.recipient)
		return sText
	user = GetUser(item)
	if user: sText += '\n\n' + GetItemText(user)
	return sText

def GetItemText(item=None):
	if not item: item = GetSourceItem()
	if not item: return ''
	sType = item.Type
	# print 'sType', sType, 'item', item
	# if sType.endswith('User'): sKeys = 'user_id description location name profile_image_url protected screen_name url'
	if sType.endswith('User'): sKeys = 'screen_name name description location notifications profile_image_url protected url'
	# elif sType.startswith('Direct' or sType.startswith('Sent'): sKeys = ''
	# elif sType.endswith('Message'): sKeys = 'message_id created_at description from_user_id from_user location name profile_image_url source text to_user_id to_user'
	elif sType.endswith('Message'): sKeys = 'created_at description from_user location name profile_image_url source text to_user url'
	elif sType.startswith('Search'): sKeys = 'screen_name url'
	elif sType.startswith('Trend'): sKeys = ''
	
	# print sType, sKeys
	lKeys = sKeys.split()
	sText = ''
	for sKey in lKeys:
		if not hasattr(item, sKey): continue
		sValue = utf16str(getattr(item, sKey))
		sValue = sValue.strip()
		if not sValue or sValue == 'None': continue
		# if sKey == 'created_at': sValue = FormatDateTime(sValue)
		if sKey == 'created_at':
			if bRelativeTime:
				sTime = GetRelativeTime(sValue)
				sText += 'Relative Time: ' + sTime + '\n'
				continue

			sDate, sTime = GetDateAndTime(sValue)
			sText += 'Date: ' + sDate + '\nTime: ' + sTime + '\n'
			continue

		sKey = sKey.replace('_', ' ').title()
		sText += sKey +': ' + sValue + '\n'

	sText = sText.strip()
	return sText
	
def OnTimer(*args, **kwds):
	# sLabel = dlg.Controls['StaticText_Items'].GetLabel()
	sLabel = lbl.GetLabel()
	iCount = lst.GetCount()
	if iCount and sLabel != 'My Combined Message &Items': return
	if sLabel != 'My Combined Message &Items': 
		lst.SourceItems = []
		lst.SourceOriginal = []
		lst.Combined = []
	
	# lbl.SetName('My Combined Message Items')
	SetStatus('McTwit check', silent=True)
	# tmr.Stop()
	GetCombinedMessages(auto=True)
	if tmr.IsRunning(): tmr.Stop()
	bResult = tmr.Start(iPeriodAuto * 60000)
	# wx.FutureCall(10000, OnTimer, dlg, None)

def GetCombinedMessages(auto=False):
	# for i in range(1):
	iCount = lst.GetCount()
	lMsg = data.DirectList()

	if 'd' in sCombinedProcessing.lower():
		sUserName= 'My'
		sUserID = ''
		# sItemType = 'Direct Message'
		sItemType = 'Direct Combined Message'
		sTime = ReadValue(sItemType + 'Time', section=sUserName)
		sID = ReadValue(sItemType + ' ID', section=sUserName)
		# if iCount: sItemType = 'Direct Combined Message'
		if not auto: AddStatus('Getting Direct', silent=False)
		# lMsg = data.DirectList()

		iPreCount = len(lMsg)
		iPage = 1
		while True:
			if b4get: sTime = ''; sID = ''
			l = data.DirectList(t.direct_messages(since=sTime, since_id=sID, page=iPage), itemType='Direct Message')
			if not auto and l.error: AddStatus('Error!'); break
			if not l: break
			if not auto and iPage > 1: AddStatus('Page ' + utf16str(iPage))
			lMsg.extend(l)
			# if len(l) < 20: break

			if iPageBoundary and iPage == iPageBoundary: break
			iPage += 1

		if lMsg and not l.error:
			msg = lMsg[0]
			sTime = msg.created_at
			if sTime:  WriteValue(sItemType + ' Time', sTime, section=sUserName)
			sID = utf16str(msg.id)
			if sID: WriteValue(sItemType + ' ID', sID, section=sUserName)

		iPostCount = len(lMsg)
		if not auto: AddStatus(Pluralize('item', iPostCount - iPreCount))

	if 'r' in sCombinedProcessing.lower():
		sUserName = 'My'
		sUserID = ''
		# sItemType = 'Reply Message'
		sItemType = 'Reply Combined Message'
		sTime = ReadValue(sItemType + ' Time', section=sUserName)
		sID = ReadValue(sItemType + ' ID', section=sUserName)
		# if iCount: sItemType = 'Reply Combined Message'
		if not auto: AddStatus('Getting Replies')
		# lMsg = data.StatusList()
		iPreCount = len(lMsg)
		iPage = 1
		while True:
			if b4get: sTime = ''; sID = ''
			l = data.StatusList(t.status_replies(since=sTime, since_id=sID, page=iPage), itemType='Reply Message')
			if not auto and l.error: AddStatus('Error!'); break
			if not l: break
			if not auto and iPage > 1: AddStatus('Page ' + utf16str(iPage))
			lMsg.extend(l)
			# if len(l) < 20: break

			if iPageBoundary and iPage == iPageBoundary: break
			iPage += 1

		if lMsg and not l.error:
			msg = lMsg[0]
			sTime = msg.created_at
			if sTime:  WriteValue(sItemType + ' Time', sTime, section=sUserName)
			sID = utf16str(msg.id)
			if sID: WriteValue(sItemType + ' ID', sID, section=sUserName)

		iPostCount = len(lMsg)
		if not auto: AddStatus(Pluralize('item', iPostCount - iPreCount))

	if 'n' in sCombinedProcessing.lower():
		sUserName = 'My'
		sUserID = ''
		# sItemType = 'Leader Message'
		sItemType = 'Leader Combined Message'
		sTime = ReadValue(sItemType + ' Time', section=sUserName)
		sID = ReadValue(sItemType + ' ID', section=sUserName)
		# if iCount: sItemType = 'Leader Combined Message'
		if not auto: AddStatus('Getting New')
		# lMsg = data.StatusList()
		iPreCount = len(lMsg)
		iPage = 1
		while True:
			if b4get: sTime = ''; sID = ''
			l = data.StatusList(t.status_friends_timeline(since=sTime, since_id=sID, page=iPage), itemType='Status Message')
			if not auto and l.error: AddStatus('Error!'); break
			if not l: break
			if not auto and iPage > 1: AddStatus('Page ' + utf16str(iPage))
			lMsg.extend(l)
			# if len(l) < 20: break

			if iPageBoundary and iPage == iPageBoundary: break
			iPage += 1

		if lMsg and not l.error:
			msg = lMsg[0]
			sTime = msg.created_at
			if sTime:  WriteValue(sItemType + ' Time', sTime, section=sUserName)
			sID = utf16str(msg.id)
			if sID: WriteValue(sItemType + ' ID', sID, section=sUserName)

		iPostCount = len(lMsg)
		if not auto: AddStatus(Pluralize('item', iPostCount - iPreCount))

		sItemType = 'Combined Message'
		if not auto: AddStatus('Combining')

		# """
		iCount = len(lMsg)
		l = []
		for msg in lMsg:
			iID = msg.id
			if iID in lst.Combined: continue
			msg.DateTime = datetime.strptime(msg.created_at, '%a %b %d %H:%M:%S +0000 %Y')
			l.append(msg)
			lst.Combined.append(iID)

		lMsg = l[:]
		# """

		if lMsg and auto and os.path.isfile(file_chimes): PlaySound(file_chimes, SND_FILENAME|SND_ASYNC)
		# if not auto: AddStatus(Pluralize('item', len(lMsg)))
		# lMsg.sort(cmp=SortMessage, reverse=True)
		lMsg.sort(cmp=lambda x, y: cmp(x.DateTime, y.DateTime), reverse=True)
		# lMsg.reverse()
		PopulateMessages(dlg, lMsg, sItemType, combined=True, auto=auto)
		if not auto: lbc.ActivateWindow(dlg.GetHandle())

def SortMessage(x, y):
	dt1 = datetime.strptime(x.created_at, '%a %b %d %H:%M:%S +0000 %Y')
	# try: dt1 = datetime.strptime(x.created_at, '%a %b %d %H:%M:%S +0000 %Y')
	# except: dt1 = datetime.strptime(x.created_at, '%a, %d %b %Y %H:%M:%S +0000')
	dt2 = datetime.strptime(y.created_at, '%a %b %d %H:%M:%S +0000 %Y')
	# try: dt2 = datetime.strptime(y.created_at, '%a %b %d %H:%M:%S +0000 %Y')
	# except: dt2 = datetime.strptime(y.created_at, '%a, %d %b %Y %H:%M:%S +0000')
	return cmp(dt1, dt2)

def GetYield():
	# dYield = {'Direct Message' : 0, 'Status Message' : 0, 'User' : 0}
	dYield = {}
	iCount = lst.GetCount()
	for i in range(iCount):
		iData = lst.GetClientData(i)
		item = lst.SourceItems[iData]
		sType = item.Type
		if not dYield.has_key(sType): dYield[sType] = 0
		dYield[sType] += 1
		
	return dYield

def str2int(s):
	try: i = int(s)
	except: i = 0
	return i

def bool2str(b): return 'y' if b else 'n'

def str2bool(s):
	sText = s.strip().lower()
	i = (s in ('yes', 'y', 'true', 't', 'on'))
	# print  type(i), i
	if i: return True
	try: i = abs(int(s))
	except: i = 0
	if i > 0: return True
	else: return False

def FormatUser(user): return user.screen_name + ' (' + user.name + ')'

def Pluralize(sText, iCount): return utf16str(iCount) + ' ' + sText + ('' if iCount == 1 else 's')

def GetPriorMessage(msg):
	d = simplejson.loads(msg)
	sText = 'Created At: ' + FormatDateTime(d[u'created_at']) + '\n'
	sText += 'User: ' + d[u'user'][u'screen_name'] + ' (' + d[u'user'][u'name'] + ')\n'
	sText += 'Text: ' + d[u'text']
	return sText

def GetResultText(result):
	sText = ''
	if type(result).__name__ != 'dict': d = simplejson.loads(result)
	else: d = result
	# for k in sorted(d.keys()): sText += utf16str(k).replace('_', ' ').title() + ': ' + utf16str(d[k]) + '\n'
	lKeys = sorted(d.keys())
	for sKey in lKeys:
		if sKey == 'status': continue
		if sKey.startswith('profile_'): continue
		sValue = utf16str(d[sKey])
		sValue = sValue.strip()
		if not sValue or sValue == 'None': continue
		if type(result) == 'string' and sKey == 'created_at': sValue = FormatDateTime(sValue)
		elif False: 
		# elif sKey == 'created_at':
			sDate, sTime = GetDateAndTime(sValue)
			sText += 'Date: ' + sDate + '\nTime: ' + sTime + '\n'
			continue

		sKey = sKey.replace('_', ' ').title()
		sText += sKey +': ' + sValue + '\n'

	sText = sText.strip()
	return sText

def GetObjectText(o, lKeys):
	sText = ''
	sType = type(o).__name__
	# print sType
	if sType == 'list':
		for oItem in o: sText += GetObjectText(oItem)
	elif sType == 'dict': 
		# for sKey in o: sText += GetObjectText(o[sKey], lKeys)
		sText += GetDictionaryText(o, lKeys)
	else: sText += utf16str(o) + '\n'
	return sText

def GetDictionaryText(d, lKeys=None):
	sText = ''
	if not lKeys: lKeys = d.keys()
	for sKey in lKeys:
		if not d.has_key(sKey): continue
		sValue = utf16str(d[sKey])
		sValue = sValue.strip()
		if not sValue or sValue == 'None': continue
		sKey = utf16str(sKey)
		sKey = sKey.replace('_', ' ').title()
		sText += sKey +': ' + sValue + '\n'

	sText = sText.strip()
	return sText

def GetUser(item, itemType=None, sent=False):
	# print 'sent', sent
	if not itemType: itemType = item.Type
	# print itemType, itemType.startswith('Direct')
	if sent: user = item.recipient
	elif itemType.startswith('Direct'): user = item.sender
	elif itemType.endswith('User'): user = item
	else: user = item.user
	# print 'user', user.screen_name
	return user

def ShowResult(result):
	try: d = simplejson.loads(result)
	except: d = None
	if d and d.has_key('id') and d['id']: return AddStatus('Done!')
	return AddStatus(utf16str(result))
	sText = GetResultText(result)
	return lbc.DialogShow(title='Result from twitter.com', message=sText)
	try:
		msg = data.Status()
		msg.load_json(result)
		sText = msg.user.screen_name + ': ' + msg.text
	except: sText = utf16str(result)
	lbc.DialogShow(title='Result from twitter.com', message=sText)

def SetStatus(text='', silent=False):
	sb.SetLabel('')
	AddStatus(text, silent)

def AddStatus(text='', silent=False):
	if ExtensionEnhanced() and bEnhancedSpeech and not silent: oSt.Say(text, dir_data)
	# sb = dlg.Controls['StaticText_Status']
	sText = sb.GetLabel()
	if sText: sText += '   '
	sText += text
	sb.SetLabel(sText)

def DirectSend():
	sPrefix = 'd ' + sUserName + ' '
	iPrefix = len(sPrefix)
	iMax = 140 - iPrefix
	sTitle = 'Direct to ' + sUserName + ' (' + sUserFullName + '), max length ' + utf16str(iMax)
	sText = ''
	sText = lbc.DialogTweet(title=sTitle, label='Text', value=sText, max=iMax)
	if sText == None: return
	sText = sPrefix + sText
	# print 'sText', sText
	# result = t.direct_new(user=sUserName, text=sText)
	result = t.status_update(sText)
	ShowResult(result)

	"""
	sText = ''
	while True:
		sText = lbc.DialogInput(title=sTitle, label='Text', value=sText)
		if sText == None: return
		sText = sText.strip()
		if not sText: return
		iCount = len(sText)
		if iCount <= 140: break
		lbc.DialogShow(title='Alert', message='Text cannot be more than 140 characters.\n' + utf16str(iCount) + ' were entered.')

	result = t.direct_new(user=sUserName, text=sText)
	ShowResult(result)
	"""

def PostTweet(reply=False, rt=False):
	if reply: sTitle = 'Reply to ' + sUserName + ' (' + sUserFullName + ')'; sPrefix = '@' + sUserName + ' '
	elif rt: sTitle = 'Retweet from' + sUserName + ' (' + sUserFullName + ')'; sPrefix = 'RT @' + sUserName + ': '
	else: sTitle = 'Tweet'; sPrefix = ''
	iPrefix = len(sPrefix)
	iMax = 140 - iPrefix
	sTitle +=', max length ' + utf16str(iMax)
	if rt: 
		# sText = memo.GetValue().split('\n')[0]
		sText = GetDisplayText()
		i = sText.index(':')
		if i: sText = sText[i + 2:]
	else: sText = ''
	sText = lbc.DialogTweet(title=sTitle, label='Text', value=sText, max=iMax)
	"""
	if reply: sTitle = 'Reply to ' + sUserName + ' (' + sUserFullName + ')'
	else: sTitle = 'Tweet'
	sText = ''
	while True:
		sText = lbc.DialogInput(title=sTitle, label='Text', value=sText)
		if sText == None: return
		sText = sText.strip()
		if not sText: return
		if reply: sText = '@' + sUserName + ' ' + sText
		iCount = len(sText)
		if iCount <= 140: break
		lbc.DialogShow(title='Alert', message='Text cannot be more than 140 characters.\n' + utf16str(iCount) + ' were entered.')
		"""

	if sText == None: return

	if reply or rt:
		i = sText.find('|')
		if i >= 0: sText = sText[0:i] + ' ' + sPrefix + sText[i + 1:]
		else: sText = sPrefix + sText
	else: 	sText = sPrefix + sText
	sID = None
	item = GetSourceItem()
	if not s1otherName and item and item.Type.endswith('Message'): sID = item.id
	result = t.status_update(sText, in_reply_to=sID)
	ShowResult(result)

def FindKeywords(lst, again=False):
	iIndex = lst.GetSelection()
	if iIndex == -1: return AddStatus('No items!')
	sKeywords = ReadValue('Keywords')
	if not again:
		sKeywords = lbc.DialogInput(title='Input', label='Text', value=sKeywords)
		if not sKeywords: return
		WriteValue('Keywords', sKeywords)
	if again: iStart = lst.GetSelection() + 1
	else: iStart = 0
	iFound = -1
	for i in range(iStart, lst.GetCount()):
		if sKeywords.lower() in lst.GetString(i).lower(): iFound = i; break
	if iFound == -1: return AddStatus('Not found!')
	else: 
		lst.SetSelection(iFound)
		lst.Refresh()
		SetCurrentView()

def PopulateMessages(dlg, lMsg, itemType='Message', combined=False, auto=False, sent=False):
	global sUserID, sUserName, bFullName
	h = dlg.GetHandle()
	if sJunkFilter and itemType != 'Search Message' and itemType != 'Trend Message':
		regexp = re.compile(sJunkFilter, re.I)
		sText = ''
		l = lMsg[:]
		lMsg = []
		for msg in l:
			# print StringMessage(msg)
			if regexp.search(StringMessage(msg)): 
				# sText = GetMemoText(msg)
				# sText = utf16str(msg)
				sText += msg.user.screen_name + ', ' + msg.user.name + ', ' + msg.text + ', ' + msg.created_at + '\n'
				# print msg.user.screen_name, msg.user.name, msg.text, msg.created_at >> file_junk
				# lMsg.remove(msg)
			else: lMsg.append(msg)
			AppendJunk(sText)
			# print StrDefault(sText) >> file_junk

	lMsg.reverse()
	sNameType = 'screen_name'
	if bFullName: sNameType = 'name'
	if sOrderItems == 'a' and len(lMsg) and GetUser(lMsg[0]): lMsg.sort(cmp=lambda x, y: cmp(getattr(GetUser(x), sNameType).lower(), getattr(GetUser(y), sNameType).lower()), reverse=True)
	elif sOrderItems == 'c': lMsg.reverse()
	iCount = len(lMsg)
	# if not combined: AddStatus(Pluralize('item', iCount))
	if not auto: AddStatus(Pluralize('item', iCount))
	memo = dlg.Controls['Memo_View']
	memo.Clear()
	lbl = dlg.Controls['StaticText_Items']
	if combined: sPrefix = 'My '
	elif itemType.startswith('Public') or itemType.startswith('Search') or itemType.startswith('Trend'): sPrefix = ''
	else: sPrefix = sUserName
	lbl.SetLabel(sPrefix + itemType + ' &Items')
	# dlg.SetSizerAndFit(dlg.Sizers[0])
	dlg.Sizers[0].Layout()
	
	lst = dlg.Controls['ListBox_Items']
	iOldIndex = lst.GetSelection()
	lst.SourceType = itemType
	lst.SourceOrder = sOrderItems
	if not auto: lst.SourceItems = []
	if not auto: lst.SourceOriginal = []
	if not auto: lst.Clear()
	if not auto: lst.SetFocus()
	if len(lMsg) == 0: return
	# for iMsg in range(len(lMsg)):
		# msg = lMsg[iMsg]
	for msg in lMsg:
		# msg.Type = itemType
		lst.SourceItems.append(msg)
		iMsg = len(lst.SourceItems) - 1
		# user = GetUser(msg, itemType)
		user = GetUser(msg, msg.Type, sent)
		# print 'get user', user.screen_name
		# if user: sText = msg.user.screen_name + ': '
		# if user: sText = user.screen_name.ljust(15) + ': '
		if user: sText = getattr(user, sNameType).ljust(15) + ': '
		else: sText = ''
		if hasattr(msg, 'name'): sText += msg.name
		else: sText += msg.text
		sText = sText.replace('\n', ' ').replace('\r', '')
		# lst.SourceOriginal.append((sText, iMsg))
		lst.SourceOriginal.insert(0, (sText, iMsg))
		# lst.Append(sText, clientData=iMsg)
		lst.Insert(sText, 0, iMsg)

	lst.SetSelection(0)
	# msg = lst.SourceItems[0]
	# user = GetUser(msg, msg.Type)
	SetCurrentView()
	# sTime = lMsg.get_last_time()
	sTime = msg.created_at
	# if sTime and not combined:  WriteValue(itemType + ' Time', sTime, section=sUserName)
	if not combined and sTime:  WriteValue(itemType + ' Time', sTime, section=sUserName)
	# sID = lMsg.get_last_id()
	sID = utf16str(msg.id)
	if not combined and sID: WriteValue(itemType + ' ID', sID, section=sUserName)
	if combined and lMsg and iOldIndex >=0: lst.SetSelection(iOldIndex + len(lMsg))
	lbc.ActivateWindow(h)

	if not bDuplic8: return
	for iIndex in range(len(lst.SourceItems)): AppendExport(GetMemoText(iIndex))

def PopulateUsers(dlg, lUser, itemType='User'):
	global sUserID, sUserName
	h = dlg.GetHandle()
	iCount = len(lUser)
	AddStatus(Pluralize('item', iCount))
	memo = dlg.Controls['Memo_View']
	memo.Clear()
	lbl = dlg.Controls['StaticText_Items']
	lbl.SetLabel(sUserName + ' ' + itemType + ' &Items')
	lst = dlg.Controls['ListBox_Items']
	lst.SourceType = itemType
	# lst.SourceItems.reverse()
	lst.SourceOriginal = []
	lst.Clear()
	lst.SetFocus()
	if len(lUser) == 0: return

	sNameType = 'screen_name'
	# if bFullName: sNameType = 'name'
	if sOrderItems == 'a' and len(lUser) and GetUser(lUser[0]): lUser.sort(cmp=lambda x, y: cmp(getattr(GetUser(x), sNameType).lower(), getattr(GetUser(y), sNameType).lower()))
	elif sOrderItems == 'c': lUser.reverse()
	lst.SourceItems = lUser[:]

	for iUser in range(len(lUser)):
		user = lUser[iUser]
		# sText = FormatUser(user)
		sText = user.screen_name.ljust(15) + ': ' + user.name
		lst.SourceOriginal.append((sText, iUser))
		# lst.SourceOriginal.append((sText, len(lUser) - iUser - 1))
		lst.Append(item=sText, clientData=iUser)

	lst.SourceOriginal.reverse()
	lst.SetSelection(0)
	msg = None
	user = lst.SourceItems[0]
	SetCurrentView()
	lbc.ActivateWindow(h)

	if not bDuplic8: return
	for iIndex in range(len(lst.SourceItems)): AppendExport(GetMemoText(iIndex))

def SetCurrentView():
	memo.Clear()
	sText = GetMemoText()
	sText = utf16str(sText)
	memo.SetValue(sText)
	memo.SetInsertionPoint(0)
	memo.Refresh()
	item = GetSourceItem()
	if not item: return
	sType = item.Type.split()[0]
	if 'Combined Message' in lbl.GetLabel() and (sType[0] in sCombinedProcessing or 'N' in sCombinedProcessing): SetStatus(sType)

def GetUserText(user):
	sText = ''
	sKeys = 'id name screen_name source location description profile_image_url url protected'
	lKeys = sKeys.split()
	for k in lKeys:
		v = getattr(user, k)  
		if utf16str(v): sText += k.replace('_', '') +': ' + utf16str(v) + '\n'
	# print 'stext', sText
	return sText.strip()
	
def WriteValue(key, value, ini='', section='', cfg_ini=None):
	if not ini: ini = file_ini
	if not section: section = 'Configuration'
	# print 'ini', ini
	if not cfg_ini: cfg_ini = ConfigObj(ini, list_values=False, create_empty=False, interpolation=False, indent_type='', write_empty_values= False, encoding='utf-8', default_encoding=sDefaultEncoding)
	if not cfg_ini.has_key(section): cfg_ini[section] = {}
	cfg_ini[section][key] = value
	# cfg_ini.BOM = True
	cfg_ini.BOM = False
	cfg_ini.write()

def ReadValue(key='', default='', ini='', section='', cfg_ini=None):
	if not ini: ini = file_ini
	if not section: section = 'Configuration'
	# print 'ini', ini
	if not cfg_ini: cfg_ini = ConfigObj(ini, list_values=False, create_empty=False, interpolation=False, indent_type='', write_empty_values= False, encoding='utf-8', default_encoding=sDefaultEncoding)
	if not cfg_ini.has_key(section): return default
	if not cfg_ini[section].has_key(key): return default
	# print 'key', key, 'default', default, 'ini', ini, 'section', section
	return cfg_ini[section][key].replace('"', '').strip()



# Main program
sDefaultEncoding = locale.getdefaultlocale()[1]
sys.stderr = sys.stdout
sys.__stderr__ = sys.__stdout__

oSt = McSay.SayTools()

# h = lbc.FindWindow(classname='#32770', title='McTwit')
# h = win32gui.FindWindow('#32770', 'McTwit')
# l = pywinauto.findwindows.find_windows(title_re=r'^McTwit - ')
l = findwindows.find_windows(class_name='#32770', title_re=r'^McTwit - ')
h = l[0] if l else 0
# print 'h', h
if h:
	oSt.SayLine('Activating')
	lbc.ActivateWindow(h)
	sys.exit(0)

oSt.SayLine('Loading')
app = lbc.App()
dir_app = sys.prefix
if dir_app.lower() == r'c:\python25': dir_app = r'C:\McTwit'

# paths = wx.StandardPaths.Get()
#dir_data = paths.GetUserConfigDir()
dir_data = os.environ['APPDATA']
dir_data = os.path.join(dir_data, 'McTwit')
if not os.path.isdir(dir_data): os.mkdir(dir_data)
file_ini = os.path.join(dir_data, 'McTwit.ini')
if len(sys.argv) > 1: 
	file_ini = sys.argv[1]
	file_ini = win32api.ExpandEnvironmentStrings(file_ini)
	# file_ini = win32api.GetFullPathName(file_ini)
	dir_data = os.path.dirname(file_ini)
	if not dir_data: dir_data = dir_app; file_ini = os.path.join(dir_data, os.path.basename(file_ini))
# print 'file_ini', file_ini
# print 'dir_data', dir_data

file_extensions = os.path.join(dir_data, 'Extensions.ini')
win32api.WriteProfileVal('Configuration', 'MainIni', file_ini, file_extensions)
file_help = os.path.join(dir_app, 'McTwit.cfg')
file_guide = os.path.join(dir_app, 'McTwit.htm')
twitter_guide = os.path.join(dir_app, 'TwitterHelpGuide.htm')
file_urls = os.path.join(dir_app, 'TwitterURLs.txt')
file_chimes = os.path.join(dir_app, 'chimes.wav')
file_chimes = ReadValue('SoundFile', file_chimes)
file_elevate = os.path.join(dir_app, 'Elevate.exe')
file_elevate_ini = os.path.join(dir_app, 'Elevate.ini')
file_export = os.path.join(dir_data, 'Export.txt')
file_junk = os.path.join(dir_data, 'Junk.txt')

t = twitter.Twitter()
sMyUserName = ReadValue('User')
sMyUserID = ReadValue('UserID')
sMyUserFullName = ReadValue('FullName')
sMyPassword = ReadValue('Password')
if not sMyUserName or not sMyPassword:
	lLabels = ['User', 'Password']
	lValues = [sMyUserName, sMyPassword]
	lResults = lbc.DialogMultiInput(title='Settings', labels=lLabels, values=lValues)
	if not lResults: sys.exit(0)
	for i in range(len(lResults)): WriteValue(lLabels[i], lResults[i])
	sMyUserName = ReadValue('User')
	sMyPassword = ReadValue('Password')

t.set_auth(sMyUserName, sMyPassword)

if not sMyUserFullName or not sMyUserID:
	try:
		sResponse = t.user_show(id=sMyUserName)
		dResponse = simplejson.loads(sResponse)
		sMyUserID = utf16str(dResponse['id'])
		sMyUserName = dResponse['screen_name']
		sMyUserFullName = dResponse['name']
		WriteValue('FullName', sMyUserFullName)
		WriteValue('User', sMyUserName)
		WriteValue('UserID', sMyUserID)
	except Exception, e: oSt.SayLine('Error!  ' + utf16str(e))
	
t.set_user_agent('McTwit')

dlg = lbc.Dialog(title='McTwit')
# dlg = lbc.Dialog(title='McTwit - ' + sMyUserName, size=(1000,1000))
# dlg = lbc.Dialog(title='McTwit', style=wx.DEFAULT_FRAME_STYLE | wx.FRAME_NO_TASKBAR)
# dlg = lbc.Dialog(title='McTwit', style=wx.DEFAULT_FRAME_STYLE | wx.FRAME_TOOL_WINDOW)
app.Export = False
# lst = dlg.AddListBox(label='Items', size=(700, 280))
lst = dlg.AddListBox(label='Items', size=(700, 285))
# lst.SetFont(wx.Font(7, wx.MODERN, wx.NORMAL, wx.NORMAL))
lst.SetFont(wx.Font(6, wx.MODERN, wx.NORMAL, wx.NORMAL))
# e = wx.FontEnumerator(fixedWidth=True)
# for font in e.GetFacenames(): print font
lbl = dlg.Controls['StaticText_Items']
lst.SourceType = ''
lst.SourceItems = []
lst.SourceOriginal = []
lst.SourceMsgMessages = []
lst.SourceMsgNew = []
lst.SourceMsgPublic = []
lst.SourceMsgReplies = []
lst.SourceMsgSent = []
lst.SourceUserFollowers = []
lst.SourceUserLeaders = []
lst.Combined = []
dlg.AddBand()
# memo = dlg.AddMemo(label='View:', readonly=True)
memo = dlg.AddMemo(label='View:', readonly=True, size=(700,285))
# memo.SetFont(wx.Font(16, wx.MODERN, wx.NORMAL, wx.NORMAL))
sb = None
sUserID = ''
sUserName = ''
sUserFullName = ''
s1otherName = ReadValue('1otherName', '')
s1otherFullName = ReadValue('1otherFullName', '')
s1otherID = ReadValue('1otherID', '')
iPageBoundary = str2int(ReadValue('PageBoundary', '0'))
iPeriodAuto = str2int(ReadValue('PeriodAuto', '0'))
sQueryExp = ''
b4get = str2bool(ReadValue('4get', 'n'))
bDuplic8 = str2bool(ReadValue('Duplic8', 'n'))
bEnhancedSpeech = str2bool(ReadValue('EnhancedSpeech', 'y'))
bFullName = str2bool(ReadValue('FullName', 'n'))
bRelativeTime = str2bool(ReadValue('RelativeTime', 'n'))
sCombinedProcessing = ReadValue('CombinedProcessing', 'DRN')
sPriorityQuery = ReadValue('PriorityQuery', '')
sJunkFilter = ReadValue('JunkFilter', '')

# wx.FutureCall(10000, OnTimer, dlg, None)
# tmr = wx.Timer(dlg)
tmr = Timer()
# tmr.Notify = GetCombinedMessages
# dlg.Bind(wx.EVT_TIMER, OnTimer, tmr)
if iPeriodAuto: bResult = tmr.Start(iPeriodAuto * 60000)
sSlashSearch = ''
sOrderItems = ReadValue('OrderItems', 'r')

sOldSourceLabel = None
sOldSourceType = None
lOldSourceItems = None
lOldSourceOriginal = None
iOldSelectedIndex = None
sOldView = None
iOldPoint = None
lOldItemData = []
iOldEventIndex = -1

dlg.AddButtonBand(buttons=r'New Again Boundary Configure Direct Export Followers Go Join Keywords Leaders Messages Order Public'.split())
dlg.AddButtonBand(buttons=r'Query Replies Sent Tweet 2tweet 3tweet Utilities Write E&xtra Yield Zap 0items'.split())
dlg.Complete(buttons=r'1other 4get 5orite \cache |blocked 7update Duplic&8 9rewind ,bine .auto [store ]restore /search ?relationship -trends =balance +elevate Help Close'.split(), handler=OnEvent, statusbar=True)
if app.Export: os.startfile(file_export)
app.Exit()
