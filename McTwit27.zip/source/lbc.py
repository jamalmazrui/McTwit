"""
Layout by Code for Python
Version 1.2
April 26, 2009
Copyright 2009 by Jamal Mazrui
LGPL Licence 
"""

import wx
import locale
import ctypes, os, sys, time
import comtypes.client
from configobj import ConfigObj
from odict import OrderedDict
import win32api
import win32gui

DEFAULT_PARENT = -1
DEFAULT_STYLE = 0
BorderPad = 2
CharHeight = 16
LabelWidth = -1
ButtonWidth = 100
ButtonHeight = 16
CheckBoxWidth = -1
RadioBoxWidth = -1
RadioBoxHeight = -1
RadioButtonWidth = -1
InputWidth = 200
EditWidth = 200
EditHeight = 200
ListWidth = 200
ListHeight = 100
HORIZONTAL_LABEL_PAD = 6
HORIZONTAL_RELATED_PAD = 8
HORIZONTAL_DIVIDER_PAD = 14
VERTICAL_RELATED_PAD = 8
VERTICAL_DIVIDER_PAD = 14

sDefaultEncoding = locale.getdefaultlocale()[1]

def StrDefault(sText): return sText.encode(sDefaultEncoding, 'ignore')

def utf16str(sText):
	if sText == None: return''
	# elif isinstance(sText, bool) or isinstance(sText, int): return utf16str(sText)
	elif isinstance(sText, unicode): return unicode(sText)
	# elif isinstance(sText, str): return unicode(sText, sDefaultEncoding, 'ignore')
	elif isinstance(sText, str): return unicode(sText, 'utf-8', 'ignore')
	else: return unicode(sText)

def utf8str(sText): return utf16str(sText).encode('utf-8', 'ignore')

def utf8urlencode(l): return urllib.urlencode([(utf8str(k), utf8str(v)) for k, v in dict(l).items()])

def ActivateWindow(hWindow):
	KERNEL32 = ctypes.windll.KERNEL32
	GetCurrentThreadId = KERNEL32.GetCurrentThreadId
	
	USER32 = ctypes.windll.USER32
	AttachThreadInput = USER32.AttachThreadInput
	BringWindowToTop = USER32.BringWindowToTop
	GetForegroundWindow = USER32.GetForegroundWindow
	GetWindowThreadProcessId = USER32.GetWindowThreadProcessId
	ShowWindow=USER32.ShowWindow
	
	iForegroundThread = GetWindowThreadProcessId(GetForegroundWindow(), 0)
	#print 'foreground thread', iForegroundThread
	iAppThread = GetCurrentThreadId()
	#print 'app thread', iAppThread
	if iForegroundThread == iAppThread:
		BringWindowToTop(hWindow)
		ShowWindow(hWindow,3)
	else:
		iResult = AttachThreadInput(iForegroundThread, iAppThread, 1)
		#print 'result', iResult
		iResult = BringWindowToTop(hWindow)
		iResult = ShowWindow(hWindow,3)
		iResult = AttachThreadInput(iForegroundThread, iAppThread, 0)
		#print 'result', iResult

def Activator(event):
	dlg = event.GetEventObject()
	h = dlg.GetHandle()
	ActivateWindow(h)

def AddText(existing='', new='', delimiter="\n"):
	sText = str(existing)
	if sText: sText += delimiter
	sText += str(new)
	return sText

def DialogBrowseForFolder(parent=DEFAULT_PARENT, message='', value='', style=wx.DD_DEFAULT_STYLE | wx.DD_NEW_DIR_BUTTON):
	sResult = ''
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	dlg = wx.DirDialog(parent=parent, message=message, defaultPath=value, style=style)
	dlg.Bind(wx.EVT_INIT_DIALOG, Activator)
	if dlg.ShowModal() == wx.ID_OK: sResult = dlg.GetPath()
	#dlg.Destroy() 
	if app: app.Exit()
	return sResult
	# end def

def DialogChoose(parent=DEFAULT_PARENT, title='Choose', message = '', names=[], index=0):
	sResult = ''
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	dlg = Dialog(parent=parent, title=title)
	if message:
		dlg.AddStaticText(label=message)
		dlg.AddBand()
	lNames = names[:]
	lNames.append('Cancel')
	# print 'lNames', lNames
	for i in range(len(lNames)):
		if i > 0: dlg.AddBand()
		btn = dlg.AddButton(label=lNames[i])
		dlg.Bind(wx.EVT_BUTTON, dlg.DefaultHandler, id=btn.GetId())
		if i == index: btn.SetFocus()
	# end for
	iID = dlg.Complete(buttons=[])
	btn = dlg.FindWindowById(iID)
	sResult = FixName(btn.GetLabel())
	sResult = sResult.replace('_', '')
	if app: app.Exit()
	return sResult
# end def

def DialogConfirm(parent=DEFAULT_PARENT, title='Confirm', message='', value='Y'):
	iStyle = wx.YES_NO | wx.CANCEL | wx.ICON_QUESTION
	if value == 'Y':
		iStyle |= wx.YES_DEFAULT
	# end if
	else:
		iStyle |= wx.NO_DEFAULT
	# end else
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	#btn = wx.MessageBox(parent=parent, caption=title, message=message, style=iStyle)
	btn = wx.MessageBox(message, title, iStyle)
	if btn == wx.YES:
		# oST.Say('Yes')
		sResult = 'Y'
	# end if
	elif btn == wx.NO:
		# oST.Say('No')
		sResult = 'N'
	# end elif
	else:
		# oST.Say('Cancel')
		sResult = ''
	# end else
	#dlg.Destroy()
	if app: app.Exit()
	return sResult
# end def

def DialogInput(parent=DEFAULT_PARENT, title='Input', label='', value='', ):
	result = None
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	#dlg = wx.TextEntryDialog(parent=parent, caption=title, label=label, value=value)
	dlg = wx.TextEntryDialog(parent, label, title, value)
	dlg.Bind(wx.EVT_INIT_DIALOG, Activator)
	if dlg.ShowModal() == wx.ID_OK: result = dlg.GetValue()
	dlg.Destroy()
	if app: app.Exit()
	return result
# end def

def DialogMemo(parent=DEFAULT_PARENT, title='Memo', label='', value='', readonly=False):
	sResult = ''
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	dlg = Dialog(parent=parent, title=title)
	iStyle = style
	if readonly: iStyle |= wx.TE_READONLY
	dlg.AddRichEdit(label=label, value=value, style=iStyle)
	if readonly: iID = dlg.Complete(['Close'])
	else: iID = dlg.Complete()
	if iID == wx.ID_OK: sResult = dlg.Results['RichEdit_' + FixName(label)] 
		#dlg.Destroy()
	if app: app.Exit()
	return sResult
# end def

def DialogMultiInput(parent=DEFAULT_PARENT, title='MultiInput', labels=[], values=[], options=[], statusbar=False, ini=''):
	sResults = ''
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	dlg = Dialog(parent=parent, title=title)
	#print 'labels', len(labels), labels
	#print 'values', len(values), values
	for i in range(len(labels)):
		if i > 0: dlg.AddBand()
		sLabel, sValue = labels[i], values[i]
		dlg.AddTextCtrl(label=sLabel, value=sValue)
	# end for
	iID = dlg.Complete(statusbar=statusbar, ini=ini)
	lResults = []
	if iID == wx.ID_OK:
		for control in dlg.Controls.keys():
			if control.startswith('TextCtrl_'): lResults.append(dlg.Results[control])
		# end for
		#dlg.Destroy()
		if app: app.Exit()
	return lResults
# end def

def OldDialogMultiPick(parent=DEFAULT_PARENT, title='Multi Pick', message='', names=[], values=[], sort=False, index=0):
	if len(values) == 0: values = names
	if sort: names, values = SortNamesAndValues(names, values) 	 	
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	dlg = wx.MultiChoiceDialog(parent, message, title, names, )
	dlg.Bind(wx.EVT_INIT_DIALOG, Activator)
	if dlg.ShowModal() == wx.ID_OK: 
		l = dlg.GetSelections()
		lResults = []
		for i in l: lResults.append(values[i])
	#dlg.Destroy()
	if app: app.Exit()
	return lResults
# end def

def DialogMultiPick(parent=DEFAULT_PARENT, title='Multi Pick', message='', names=[], values=[], sort=False, index=0):
	lResults = []
	if len(values) == 0: values = names
	if sort: names, values = SortNamesAndValues(names, values) 	 	
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	dlg = Dialog(parent=parent, title=title)
	lst = dlg.AddListBox(label=message, names=names, style=DEFAULT_STYLE | wx.LB_MULTIPLE)
	dlg.Bind(wx.EVT_INIT_DIALOG, Activator)
	iID = dlg.Complete()
	if iID == wx.ID_OK: lResults = [values[i] for i in lst.GetSelections()]
	#dlg.Destroy()
	if app: app.Exit()
	return lResults
# end def

def DialogOpenFile(parent=DEFAULT_PARENT, message='', value='', wildcard='All files (*.*)|*.*'):
	sResult = ''
	path = value
	sDir, sFile = os.path.split(path)
	if os.path.isfile(path): sDir, sFile = os.path.split(path)
	elif os.path.isdir(path): sDir, sFile = (path, '')
	elif not os.path.isdir(sDir): sDir, sFile = ('', '')
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	dlg = wx.FileDialog(parent, message=message, defaultDir=sDir, defaultFile=sFile, wildcard=wildcard, style=wx.OPEN)
	dlg.Bind(wx.EVT_INIT_DIALOG, Activator)
	if dlg.ShowModal() == wx.ID_OK: sResult = dlg.GetPath()
	#dlg.Destroy()
	if app: app.Exit()
	return sResult
	# end def

def DialogPick(parent=DEFAULT_PARENT, title='Pick', message='', names=[], values=[], sort=False, index=0):
	vResult = ''
	if len(values) == 0: values = names
	if sort: names, values = SortNamesAndValues(names, values) 	
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	#dlg = wx.SingleChoiceDialog(parent=parent, id=wx.ID_ANY, message=message, title=title, choices=names, style=wx.OK | wx.CANCEL)
	dlg = wx.SingleChoiceDialog(parent, message, title, names, style=wx.OK | wx.CANCEL)
	dlg.SetSelection(index)
	dlg.Bind(wx.EVT_INIT_DIALOG, Activator)
	if dlg.ShowModal() == wx.ID_OK:
		i = dlg.GetSelection()
		vResult = values[i]
	# end if
	else:
		# oST.Say('Cancel')
		pass
	# end else
#	iIndex = wx.GetSingleChoiceIndex(message, title, names, parent)    
#	vResult = values[iIndex]
	#dlg.Destroy()
	if app: app.Exit()
	return vResult
# end def

def DialogSaveFile(parent=DEFAULT_PARENT, message='', value='', wildcard='All files (*.*)|*.*'):
	sResult = ''
	path = value
	sDir, sFile = os.path.split(path)
	if os.path.isfile(path): sDir, sFile = os.path.split(path)
	elif os.path.isdir(path): sDir, sFile = (path, '')
	elif not os.path.isdir(sDir): sDir, sFile = ('', '')
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	dlg = wx.FileDialog(parent, message=message, defaultDir=sDir, defaultFile=sFile, wildcard=wildcard, style=wx.SAVE | wx.OVERWRITE_PROMPT)
	dlg.Bind(wx.EVT_INIT_DIALOG, Activator)
	if dlg.ShowModal() == wx.ID_OK: sResult = dlg.GetPath()
	#dlg.Destroy()
	if app: app.Exit()
	return sResult
	# end def

def DialogShow(parent=DEFAULT_PARENT, title='Show', message=''):
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	# wx.MessageBox(parent=parent, caption=str(title), message=str(message), style=wx.OK)
	wx.MessageBox(parent=parent, caption=unicode(title), message=unicode(message), style=wx.OK)
	if app: app.Exit()
# end def

def DialogTweet(parent=DEFAULT_PARENT, title='Tweet', label='', value='', max=140):
	sResult = None
	app = None
	if not wx.GetApp(): app = App()
	if parent == DEFAULT_PARENT: parent = GetDefaultParent()
	dlg = Dialog(parent=parent, title=title)
	txt = dlg.AddTextCtrl(label=label, value=value, size=(700, 21))
	txt.SetMaxLength(max)
	txt.SetFont(wx.Font(6, wx.MODERN, wx.NORMAL, wx.NORMAL))
	iID = dlg.Complete(handler=HandleTweet, statusbar=True, idle=True)
	if iID == wx.ID_OK: sResult = dlg.Results['TextCtrl_' + FixName(label)] 
	# print 'id', iID, 'name', dlg.FindWindowById(iID).GetName()
	# print 'OK', (iID == wx.ID_OK)
	# print 'Cancel', (iID == wx.ID_CANCEL)
		#dlg.Destroy()
	if app: app.Exit()
	return sResult

def HandleTweet(dlg, event, name):
	# if not 'idle' in str(event).lower(): print 'event', event, 'name', name, 'type', event.GetEventType(), 'id', event.GetId()
	if name.startswith('Button_') and IsClickEvent(event): dlg.EndModal(dlg.Controls[name].GetId())
	name='TextCtrl_Text'
	txt = dlg.Controls[name]
	sOldText = dlg.GetStatus()
	sNewText = 'Position ' + str(txt.GetInsertionPoint() + 1) + '   Length ' + str(txt.GetLastPosition())
	if sNewText != sOldText: dlg.SetStatus(sNewText)

def GetDefaultParent():
	app = None
	if not wx.GetApp(): app = App()
	parent = wx.GetActiveWindow()
	if not parent: parent = wx.FindWindowByName('desktop') # ctypes.windll.USER32.GetDesktopWindow()
	if app: app.Destroy()
	return parent

def FindWindow(classname='', title=''):
	try: h = win32gui.FindWindow(sClass, sTitle)
	except: h = 0
	return h

def FixName(name=''):
	sName = name
	sName = sName.replace('&', '')
	sName = sName.replace(':', '')
	sName = sName.replace(' ', '_')
	return sName

def FixLabel(label = ''):
	sLabel = label
	if len(sLabel) == 0: return sLabel
	sLabel = sLabel.replace('_', '')
	if sLabel.find('&') == -1: sLabel = '&' + sLabel
	if not sLabel.endswith(':'): sLabel += ':'
	return sLabel
# end def

def IsClickEvent(event):
	iID = event.GetId()
	iType = event.GetEventType()
	if iType == 10008: return True
	else: return False

def IsCloseEvent(event):
	iID = event.GetId()
	iType = event.GetEventType()
	if iType in wx.EVT_CLOSE.evtType or iType == 10081 or iID in (5101, 5001): return True
	else: return False

def IsFocusEvent(event):
	iID = event.GetId()
	iType = event.GetEventType()
	if iType == 10039: return True
	else: return False

def IsInitEvent(event):
	iID = event.GetId()
	iType = event.GetEventType()
	if iType == 10116: return True
	else: return False

def SortNamesAndValues(names, values):
	l = [(names[i].lower(), i, names[i], values[i]) for i in range(len(names))]
	l.sort()
	names = [name for name_lower, i, name, value in l]
	values = [value for name_lower, i, name, value in l]
	return names, values
	# end def

class App(wx.App):

	def __init__(self, redirect=False, filename=None, useBestVisual=False, clearSigInt=True):
		wx.App.__init__(self, redirect, filename, useBestVisual, clearSigInt)

	def OnInit(self): return True

class Dialog(wx.Dialog):
	
	# def __init__(self, parent=None, title='Dialog', pos=wx.DefaultPosition, size=wx.DefaultSize, style=wx.DEFAULT_DIALOG_STYLE):
	def __init__(self, parent=None, title='Dialog', pos=wx.DefaultPosition, size=wx.DefaultSize, style=wx.DEFAULT_FRAME_STYLE):
		wx.Dialog.__init__(self, parent=parent, title=title, pos=pos, size=size, style=style)
		# self.Bind(wx.EVT_INIT_DIALOG, self.DefaultHandler)
		self.SetName('Dialog_' + title)
		self.CustomHandler = None
		self.Results = {}
		self.Tips = {}
		self.Sizers = []
		self.Controls = OrderedDict()
		self.Sizers.append(wx.BoxSizer(wx.VERTICAL))
		self.band = 0
		self.Sizers[0].Add(wx.Size(1, VERTICAL_DIVIDER_PAD))
		self.AddBand()
#		super(self, '__init__')
#		wx.Dialog.__init__(self, parent=parent, id=id, title=title, pos=pos, size=size, style=style)
	# end def
	
	def AddBand(self):
		if self.band > 0: 
			self.Sizers[self.band].Add(wx.Size(HORIZONTAL_LABEL_PAD, 1))
			iFlags = wx.GROW
			self.Sizers[0].Add(self.Sizers[self.band], 1, iFlags)

		self.Sizers[0].Add(wx.Size(1, VERTICAL_RELATED_PAD))
		self.Sizers.append(wx.BoxSizer(wx.HORIZONTAL))
		self.band += 1
		self.Sizers[self.band].Add(wx.Size(HORIZONTAL_DIVIDER_PAD, 1))
	# end def

	def AddButtonBand(self, buttons=[], handler=None):
		self.CustomHandler = handler
		self.AddBand()
		for i in range(len(buttons)):
			sButton = buttons[i]
			btn = self.AddButton(label=sButton)
			if i == 0: btn.SetDefault()
			#print 'handler', handler
			# # self.Bind(wx.EVT_BUTTON, self.DefaultHandler, id=btn.GetId())
		# end for
	# end def
	
	def AddButton(self, id=wx.ID_ANY, label='', pos=wx.DefaultPosition, size=wx.DefaultSize, style=DEFAULT_STYLE, name=''):
		sLabel = label
		if sLabel == 'OK':
			iID = wx.ID_OK
		# end if
		elif label == 'Cancel':
			iID = wx.ID_CANCEL
		# end elif
		elif label == 'Close':
			iID = wx.ID_CANCEL
			# iID = wx.ID_CLOSE
			# iID = 2
		# end elif
		else:
			iID = wx.ID_ANY
			if sLabel.find('&') == -1: sLabel = '&' + sLabel
		# end else
		sName = name
		if len(sName) == 0: sName = 'Button_' + FixName(label)
		btn = wx.Button(parent=self, id=iID, label=sLabel, pos=pos, size=size, style=style, name=sName)
		self.Sizers[self.band].Add(btn, 0, wx.ALIGN_LEFT | wx.ALIGN_TOP)
		self.Sizers[self.band].Add(wx.Size(HORIZONTAL_RELATED_PAD, 1))
		self.Bind(wx.EVT_BUTTON, self.DefaultHandler, id=btn.GetId())
		self.Controls[sName] = btn
		# print sName, iID
		return btn
	# end def
	
	def AddCheckBox(self, id=wx.ID_ANY, label='', value=False, pos=wx.DefaultPosition, size=wx.DefaultSize, style=DEFAULT_STYLE, name=''):
		sLabel = label
		if sLabel.find('&') == -1: sLabel = '&' + sLabel
		sName = name
		if len(sName) == 0: sName = 'CheckBox_' + FixName(label)
		chk = wx.CheckBox(parent=self, id=id, label=sLabel, pos=pos, size=size, style=style, name=sName)
		chk.SetValue(value)
		self.Sizers[self.band].Add(chk, 0, wx.ALIGN_LEFT | wx.ALIGN_TOP)
		self.Sizers[self.band].Add(wx.Size(HORIZONTAL_RELATED_PAD, 1))
		self.Bind(wx.EVT_CHECKBOX, self.DefaultHandler, id=chk.GetId())
		self.Controls[sName] = chk
		return chk
	# end def
	
	def AddListBox(self, id=wx.ID_ANY, label='', names=[], values=[], sort=False, pos=wx.DefaultPosition, size=wx.DefaultSize, style=wx.LB_HSCROLL, name=''):
		if len(label) > 0: self.AddStaticText(label=label)
		sName = name
		if len(sName) == 0: sName = 'ListBox_' + FixName(label)
		iStyle = style
		if sort: iStyle |= wx.LB_SORT
		lst = wx.ListBox(parent=self, id=id, pos=pos, size=size, style=iStyle, name=sName)
		for i in range(len(names)):
			lst.Append(item=names[i], clientData=i)
		# end for
		
		if lst.GetCount(): lst.SetSelection(0)
		self.Sizers[self.band].Add(lst, 1, wx.ALIGN_LEFT | wx.ALIGN_TOP | wx.GROW)
		self.Sizers[self.band].Add(wx.Size(HORIZONTAL_RELATED_PAD, 1))
		self.Bind(wx.EVT_LISTBOX, self.DefaultHandler, id=lst.GetId())
		self.Controls[sName] = lst
		return lst
	# end def
	
	def AddMemo(self, id=wx.ID_ANY, label='', value='', readonly=False, pos=wx.DefaultPosition, size=wx.DefaultSize, style= wx.TE_MULTILINE | wx.TE_PROCESS_ENTER, name=''):
		if len(label) > 0: self.AddStaticText(label=label)
		sName = name
		if len(sName) == 0: sName = 'Memo_' + FixName(label)
		iStyle = style
		if readonly: iStyle |= wx.TE_READONLY
		txt = wx.TextCtrl(parent=self, id=id, pos=pos, size=size, style=iStyle, name=sName)
		txt.SetValue(value)
		self.Sizers[self.band].Add(txt, 1, wx.ALIGN_LEFT | wx.ALIGN_TOP | wx.GROW)
		self.Sizers[self.band].Add(wx.Size(HORIZONTAL_RELATED_PAD, 1))
		self.Controls[sName] = txt
		# self.Bind(wx.EVT_SET_FOCUS, self.DefaultHandler, id=txt.GetId())
		# self.Bind(wx.EVT_KEY_DOWN, self.DefaultHandler, id=txt.GetId())
		return txt
	# end def

	def AddRadioButton(self, id=wx.ID_ANY, label='', value=False, pos=wx.DefaultPosition, size=wx.DefaultSize, style=DEFAULT_STYLE, name=''):
		sLabel = label
		if sLabel.find('&') == -1: sLabel = '&' + sLabel
		iStyle = style
		if len(self.Controls) > 0 and not self.Controls[-1].startswith('RadioButton_'): iStyle = wx.RB_GROUP
		sName = name
		if len(sName) == 0: sName = 'RadioButton_' + FixName(label)
		rdn = wx.RadioButton(parent=self, id=id, label=sLabel, pos=pos, size=size, style=style, name=sName)
		rdn.SetValue(value)
		self.Sizers[self.band].Add(rdn, 0, wx.ALIGN_LEFT | wx.ALIGN_TOP)
		self.Sizers[self.band].Add(wx.Size(HORIZONTAL_RELATED_PAD, 1))
		self.Bind(wx.EVT_RADIOBUTTON, self.DefaultHandler, id=rbn.GetId())
		self.Controls[sName] = rdn
		return rdn
	# end def
	
	def AddRichEdit(self, id=wx.ID_ANY, label='', value='', readonly=False, pos=wx.DefaultPosition, size=wx.DefaultSize, style= wx.TE_MULTILINE | wx.TE_PROCESS_ENTER | wx.TE_RICH2, name=''):
		if len(label) > 0: self.AddStaticText(label=label)
		sName = name
		if len(sName) == 0: sName = 'RichEdit_' + FixName(label)
		iStyle = style
		if readonly: iStyle |= wxTE_READONLY
		rtb = wx.TextCtrl(parent=self, id=id, pos=pos, size=size, style=iStyle, name=sName)
		rtb.SetValue(value)
		self.Sizers[self.band].Add(rtb, 1, wx.ALIGN_LEFT | wx.ALIGN_TOP | wx.GROW)
		self.Sizers[self.band].Add(wx.Size(HORIZONTAL_RELATED_PAD, 1))
		self.Bind(wx.EVT_RADIOBUTTON, self.DefaultHandler, id=lst.GetId())
		self.Controls[sName] = rtb
		return rtb
	# end def

	def AddStaticText(self, id=wx.ID_ANY, label='', pos=wx.DefaultPosition, size=wx.DefaultSize, style=DEFAULT_STYLE, name=''):
		sName = name
		if len(sName) == 0: sName = 'StaticText_' + FixName(label)
		sLabel = FixLabel(label)
		lbl = wx.StaticText(self, id=id, label=sLabel, pos=pos, size=size, style=style, name=sName)
		self.Sizers[self.band].Add(lbl, 0, wx.ALIGN_LEFT | wx.ALIGN_TOP)
		self.Sizers[self.band].Add(wx.Size(HORIZONTAL_LABEL_PAD, 1))
		self.Controls[sName] = lbl
		return lbl
	# end def
	
	def AddTextCtrl(self, id=wx.ID_ANY, label='', value='', pos=wx.DefaultPosition, size=wx.DefaultSize, style=DEFAULT_STYLE, name=''):
		if len(label) > 0: self.AddStaticText(label=label)
		sName = name
		if len(sName) == 0: sName = 'TextCtrl_' + FixName(label)
		iStyle = style
		if sName == 'TextCtrl_Password': iStyle |= wx.TE_PASSWORD
		aSize = size
		if aSize == wx.DefaultSize: aSize = (300, 21)
		txt = wx.TextCtrl(parent=self, id=id, pos=pos, size=aSize, style=iStyle, name=sName)
		txt.SetMaxLength(0)
		txt.SetValue(value)
		# sValue = unicode(value)
		# txt.SetValue(sValue)
		#txt.SetSize((2 * (txt.GetSize()[0]), txt.GetSize()[1]))
		# print txt.GetSize()
		self.Sizers[self.band].Add(txt, 1, wx.ALIGN_LEFT | wx.ALIGN_TOP)
		self.Sizers[self.band].Add(wx.Size(HORIZONTAL_RELATED_PAD, 1))
		self.Bind(wx.EVT_TEXT, self.DefaultHandler, id=txt.GetId())
		self.Bind(wx.EVT_TEXT_MAXLEN, self.DefaultHandler, id=txt.GetId())
		# self.Bind(wx.EVT_KEY_DOWN, self.DefaultHandler, id=txt.GetId())
		self.Controls[sName] = txt
		return txt
	# end def
	
	def DefaultHandler(self, event):
		# print 'event', str(event), 'id', event.GetId(), 'type', event.GetEventType()
		iEventID = event.GetId()
		iEventType = event.GetEventType()
		oWindow = event.GetEventObject()
		iID = oWindow.GetId()
		#print 'event', event, 'eventID', iEventID, 'eventType', iEventType, 'windowID', iID
		oParent = oWindow.GetParent()
		# for control in self.Controls.keys(): 
			# window = self.FindWindowByName(control)
		for control, window in self.Controls.items(): 
			try: result = window.GetValue()
			except:
				try: result = window.GetSelection()
				except: 
					try: result = window.GetLabel()
					except: 
						try: result = window.GetSelections()
						except: result = None
			self.Results[control] = result
		sName = event.GetEventObject().GetName()
		if self.ini and IsFocusEvent(event):
			sSection = self.GetTitle()
			# sIni = win32api.GetModuleFileName(0)
			# sIni = sIni[0 : -3] + 'cfg'
			sIni = self.ini
			sValue = win32api.GetProfileVal(sSection, sName, '', sIni)
			i = sValue.find(',')
			# if i >= 0: sValue = sValue[i + 1:].strip()
			# print sIni, sSection, sName, sValue
			# print sValue
			# sValue = ' ' + sValue
			self.SetStatus(sValue)

		if self.CustomHandler: return self.CustomHandler(self, event, sName)
		# self.Close()
		# if self.IsModal() and IsCloseEvent(event): self.EndModal(iID)
		if self.IsModal() and not IsFocusEvent(event) and sName.startswith('Button_'): self.EndModal(iID)
	# end def
	
	def Complete(self, buttons = ['OK', 'Cancel'], handler=None, statusbar=False, ini='', idle=False):
		if len(buttons) > 0: self.AddButtonBand(buttons=buttons, handler=handler)
		self.Bind(wx.EVT_INIT_DIALOG, Activator)
		self.Bind(wx.EVT_INIT_DIALOG, self.DefaultHandler)
		self.Bind(wx.EVT_CLOSE, self.DefaultHandler)
		# self.Bind(wx.EVT_CHAR, self.DefaultHandler)
		# self.Bind(wx.EVT_KEY_DOWN, self.DefaultHandler)
		# self.Bind(wx.EVT_SET_FOCUS, self.DefaultHandler)

		# at = wx.AcceleratorTable([(0, wx.WXK_ESCAPE, wx.ID_CANCEL)])
		# self.SetAcceleratorTable(at)
		# self.SetEscapeId(wx.ID_CANCEL)

		# self.Bind(wx.EVT_COMMAND_SET_FOCUS, self.DefaultHandler)
		self.Bind(wx.EVT_CHILD_FOCUS, self.DefaultHandler)
		if idle: self.Bind(wx.EVT_IDLE, self.DefaultHandler)
		# self.Bind(wx.EVT_CHAR, self.DefaultHandler)
		# self.Bind(wx.EVT_KEY_DOWN, self.DefaultHandler)

		self.ini = ini
		if statusbar:
			self.AddBand()
			self.AddStaticText(label='', name='StaticText_Status')

		self.Sizers[self.band].Add(wx.Size(HORIZONTAL_LABEL_PAD, 1))
		iFlags = wx.GROW | wx.ALIGN_CENTER
		iFlags = wx.ALIGN_RIGHT
		iFlags = wx.ALIGN_CENTER
		self.Sizers[0].Add(self.Sizers[self.band], 1, iFlags)
		self.Sizers[0].Add(wx.Size(1, VERTICAL_DIVIDER_PAD))
		self.SetSizerAndFit(self.Sizers[0])
		self.Center()
		iID = self.ShowModal()
		# iID = self.Show()
		# wx.GetApp().MainLoop()
		# self.Close()
		return iID
	# end def

	def SetStatus(self, text=''):
		sb = self.Controls['StaticText_Status']
		sb.SetLabel(text)
	def GetStatus(self):
		sb = self.Controls['StaticText_Status']
		return sb.GetLabel()





class WebPage(object):
	def __init__(self, title='Test Page'):
		# self.ie = win32com.client.Dispatch('InternetExplorer.Application', 'IE_')
		self.ie = comtypes.client.CreateObject('InternetExplorer.Application')
		#self.ie = win32com.client.Dispatch('InternetExplorer.Application')
		self.ie.Navigate('about:Blank')
		time.sleep(1)
		self.ie.ToolBar = 0
		self.ie.StatusBar = 0
		#self.ie.Width = 800
		#self.ie.Height = 600
		#self.ie.Left = 75
		#self.ie.Top = 0
		self.ie.Visible = 1
		self.doc = self.ie.Document
		self.doc.Open()
		self.doc.WriteLn('<html>')
		self.doc.WriteLn('	<head>')
		self.doc.WriteLn('<title>' + title + '</title>')
		self.doc.WriteLn('</head>')
		self.doc.WriteLn('<body>')
# self.doc.WriteLn('<table>')
# self.doc.WriteLn('<tr><td>')
	
	def WriteLine(self, text=''):
		self.doc.WriteLn(text + '<br>')

	def Complete(self):
		self.doc.WriteLn('</body>')
		self.doc.WriteLn('</html>')
		self.doc.Close()

if __name__ == '__main__':
	print 'starting Web Page test'
	page = WebPage('WebFido Log')
	page.WriteLine('This is line 1')
	page.WriteLine('This is line 2')
	page.WriteLine('This is line 3')
	page.Complete()



