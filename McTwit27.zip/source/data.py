# Copyright (c) 2007-2009 Andrew Price
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
# NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

"""Data structures representing Twitter API return values"""

import unescaper
import sys, re
import time
import htmllib
import simplejson
import locale

sDefaultEncoding = locale.getdefaultlocale()[1]

def StrDefault(sText): return sText.encode(sDefaultEncoding, 'ignore')

def utf16str(sText):
	if sText == None: return''
	# elif isinstance(sText, bool) or isinstance(sText, int): return utf16str(sText)
	elif isinstance(sText, unicode): return unicode(sText)
	# elif isinstance(sText, str): return unicode(sText, sDefaultEncoding, 'ignore')
	elif isinstance(sText, str): return unicode(sText, 'utf-8', 'ignore')
	else: return unicode(sText)

def utf8str(sText): return utf16str(sText).encode('utf-8', 'ignore')

def utf8urlencode(l): return urllib.urlencode([(utf8str(k), utf8str(v)) for k, v in dict(l).items()])

class User:

	"""A Twitter user"""

	def __init__(self, user, itemType='User'):

		"""
		Initialise a user. The user argument should be of the format
		returned by Twitter functions after being translated into a
		python dict.
		"""

		self.Type=itemType
		self.id = user[u'id']
		self.user_id = self.id
		self.name = user[u'name']
		self.screen_name = user[u'screen_name']
		self.location = user[u'location']
		self.description = user[u'description']
		self.notifications = user[u'notifications']
		self.profile_image_url = user[u'profile_image_url']
		self.url = user[u'url']
		self.protected = user[u'protected']
		self.created_at = user[u'created_at']


class Status:

	"""A Twitter status message"""

	def __init__(self, status=None, itemType='Status Message'):

		"""
		Initialise the message. If status is given and is a dict
		containing the fields which Twitter returns about a status
		message, the object's fields ares populated with that data.
		"""

		if status:
			self.Type = itemType
			self.set(status)

	def old___str__(self):

		"""
		Return a string representation of this Status message in the
		form:
		[id] name: message (date via source)
		"""

		string = ""
		try:
			# Sure takes a lot to do UTC -> local time...
			utc = time.mktime(time.strptime(
				"%s UTC" % self.created_at,
				"%a %b %d %H:%M:%S +0000 %Y %Z"))
			stamp = time.strftime("%a %b %d %H:%M:%S %Y",
					time.localtime(utc))

			string = "[%d] %s: %s (%s via %s)" % (int(self.id),
							self.user.screen_name,
							self.text,
							stamp,
							self.source)
		except AttributeError, e:
			print >>sys.stderr, e

		return string

	def set(self, status):

		"""
		Populate the object fields with data from the status argument.
		The status dict must provide the fields which Twitter returns
		in its status message structures.
		"""

		p = htmllib.HTMLParser(None)
		"""
		p.save_bgn()
		p.feed(status[u'text'])
		self.text = p.save_end()
		"""
		# self.text = status[u'text']
		self.text = unescaper.unescape(status[u'text'])
		self.source = ''
		self.created_at = status[u'created_at']
		self.id = status[u'id']
		self.message_id = self.id
		self.in_reply_to_status_id = status[u'in_reply_to_status_id']
		self.in_reply_to_user_id = status[u'in_reply_to_user_id']

		p.save_bgn()
		p.feed(status[u'source'])
		self.source = p.save_end()
		if self.source.endswith("[1]"):
			self.source = self.source[:-3]

		self.truncated = status[u'truncated']
		self.user = User(status[u'user'])
		if status.has_key(u'retweeted_status'): self.retweeted_status = status[u'retweeted_status']; print 'retweet here'
		else: self.retweeted_status = None

	def load_json(self, s):

		"""
		Populate this object with data from JSON encoded string s
		"""

		if s:
			jsobj = simplejson.loads(s)
			self.set(jsobj)

class DirectMsg:

	"""A direct message"""

	def __init__(self, msg=None, itemType='Direct Message'):

		"""
		Initialise the direct message. If msg is given and is a dict
		containing the fields which Twitter returns about a direct
		message, the object's fields ares populated with that data.
		"""

		if msg:
			self.Type = itemType
			self.set(msg)

	def old___str__(self):
	
		"""
		Return a string representation of a direct message of the form:
		[id] sender -> recipient: message (date)
		"""

		string = ""
		try:
			# Sure takes a lot to do UTC -> local time...
			utc = time.mktime(time.strptime(
				"%s UTC" % self.created_at,
				"%a %b %d %H:%M:%S +0000 %Y %Z"))
			stamp = time.strftime("%a %b %d %H:%M:%S %Y",
					time.localtime(utc))

			string = "[%d] %s -> %s: %s (%s)" % (self.id,
							self.sender.name,
							self.recipient.name,
							self.text,
							stamp)
		except AttributeError, e:
			print >>sys.stderr, e
		return string

	def set(self, msg):

		"""
		Populate the object fields with data from the msg argument.
		The msg dict must provide the fields which Twitter returns
		in its direct message structures.
		"""

		p = htmllib.HTMLParser(None)
		p.save_bgn()
		p.feed(msg[u'text'])

		self.text = p.save_end()
		self.source = ''
		self.created_at = msg[u'created_at']
		self.id = msg[u'id']
		self.message_id = self.id
		self.recipient_id = msg[u'recipient_id']
		self.recipient = User(msg[u'recipient'])
		self.recipient_screen_name = msg[u'recipient_screen_name']
		self.sender_id = msg[u'sender_id']
		self.sender = User(msg[u'sender'])
		self.sender_screen_name = msg[u'sender_screen_name']
		self.user = self.sender

	def load_json(self, s):

		"""Populate this object with data from JSON encoded string s"""

		if s:
			jsobj = simplejson.loads(s)
			self.set(jsobj)


class StatusList(list):

	"""A list of status messages"""

	def __init__(self, json=None, itemType='Status Message'):

		"""
		Initialise a list of status messages. If the json parameter is
		given and is a JSON encoded string containing a list of status
		messages encoded as JSON, the list will be populated with
		Status objects.
		"""

		self.error = False
		self.lastts = ""
		self.lastid = 0
		if json is not None:
			try:
				self.jsobj = simplejson.loads(json)
				# if self.jsobj.has_key('error'):
				if 'error' in self.jsobj:
					raise Exception(self.jsobj['error'])
			except ValueError:
				self.error = True
				self.jsobj = []

			print self.jsobj
			for i in self.jsobj:
				self.append(Status(i, itemType=itemType))
			if len(self) > 0:
				self.lastts = self[0].created_at
				self.lastid = self[0].id

	def get_last_time(self):

		"""
		Returns the most recent timestamp from the list of status
		messages.
		"""

		return self.lastts
	
	def get_last_id(self):

		"""
		Returns the id of most recent status message in the list
		"""

		return self.lastid


class DirectList(list):

	"""A list of direct messages"""

	def __init__(self, json=None, itemType='Direct Message'):

		"""
		Initialise a list of direct messages. If the json parameter is
		given and is a JSON encoded string containing a list of direct
		messages encoded as JSON, the list will be populated with
		DirectMsg objects.
		"""

		self.error = False
		self.lastts = ""
		self.lastid = 0
		if json is not None:
			try:
				self.jsobj = simplejson.loads(json)
			except ValueError:
				self.error = True
				self.jsobj = []

			for i in self.jsobj:
				self.append(DirectMsg(i))
			if len(self) > 0:
				self.lastts = self[0].created_at
				self.lastid = self[0].id

	def get_last_time(self):

		"""
		Returns the most recent timestamp from the list of direct messages.
		"""

		return self.lastts
	
	def get_last_id(self):

		"""
		Returns the id of most recent direct message in the list
		"""

		return self.lastid

class UserList(list):

	"""A list of users"""

	def __init__(self, json=None, itemType='User'):

		"""
		Initialise a list of users. If the json parameter is
		given and is a JSON encoded string containing a list of users
		encoded as JSON, the list will be populated with
		user objects.
		"""

		self.error = False
		if json is not None:
			try:
				self.jsobj = simplejson.loads(json)
				if 'error' in self.jsobj:
					raise Exception(self.jsobj['error'])
			except ValueError:
				self.error = True
				self.jsobj = []

			# for i in self.jsobj:
			try: self.cursor = self.jsobj['next_cursor']; lUsers = self.jsobj['users']
			except: self.cursor = None; lUsers = self.jsobj
			for i in lUsers:
				self.append(User(i, itemType=itemType))




class SearchMsg:

	"""A search message"""

	def __init__(self, msg=None):

		"""
		Initialise the search message. If msg is given and is a dict
		containing the fields which Twitter returns about a search
		message, the object's fields ares populated with that data.
		"""

		if msg:
			self.Type = 'Search Message'
			self.set(msg)

	def old___str__(self):
	
		"""
		Return a string representation of a search message of the form:
		[id] sender -> recipient: message (date)
		"""

		string = ""
		try:
			# Sure takes a lot to do UTC -> local time...
			utc = time.mktime(time.strptime(
				"%s UTC" % self.created_at,
				"%a %b %d %H:%M:%S +0000 %Y %Z"))
			stamp = time.strftime("%a %b %d %H:%M:%S %Y",
					time.localtime(utc))

			string = "[%d] %s -> %s: %s (%s)" % (self.id,
							self.sender.name,
							self.recipient.name,
							self.text,
							stamp)
		except AttributeError, e:
			print >>sys.stderr, e
		return string

	def set(self, msg):

		"""
		Populate the object fields with data from the msg argument.
		The msg dict must provide the fields which Twitter returns
		in its search message structures.
		"""

		self.id = ''
		p = htmllib.HTMLParser(None)
		p.save_bgn()
		p.feed(msg[u'text'])
		self.text = p.save_end()

		p = htmllib.HTMLParser(None)
		p.save_bgn()
		p.feed(msg[u'source'])
		self.source = p.save_end()
		# print 'self.source', self.source
		if 'href' in self.source.lower():
			# sMatch = r'(\bwww\.|\w+://)\S+'
			sMatch = r'(\bwww\.|\w+://)[^\s"]+'
			regexp = re.compile(sMatch, re.I)
			oMatch = regexp.search(self.source)
			if oMatch: self.source = oMatch.group()

		self.created_at = msg[u'created_at']
		self.from_user = msg[u'from_user']
		self.from_user_id = msg[u'from_user_id']
		self.profile_image_url = msg[u'profile_image_url']
		# self.user = SearchUser(id=self.from_user_id, screen_name=self.from_user, profile_image_url=self.profile_image_url)
		self.user = SearchUser(id=None, screen_name=self.from_user, profile_image_url=self.profile_image_url)
		if msg.has_key(u'to_user'): self.to_user = msg[u'to_user']
		else: self.to_user = ''
		if msg.has_key(u'to_user_id'): self.to_user_id = msg[u'to_user_id']
		else: self.to_user_id = ''

	def load_json(self, s):

		"""Populate this object with data from JSON encoded string s"""

		if s:
			jsobj = simplejson.loads(s)
			self.set(jsobj)


class SearchList(list):

	"""A list of search messages"""

	def __init__(self, json=None):

		"""
		Initialise a list of search messages. If the json parameter is
		given and is a JSON encoded string containing a list of search
		messages encoded as JSON, the list will be populated with
		SearchMsg objects.
		"""

		self.error = False
		self.lastts = ""
		self.lastid = 0
		if json is not None:
			try:
				# self.jsobj = simplejson.loads(json)
				self.jsobj = json
			except ValueError:
				self.error = True
				self.jsobj = []

			for i in self.jsobj:
				self.append(SearchMsg(i))
			if len(self) > 0:
				self.lastts = self[0].created_at
				# self.lastid = self[0].id

	def get_last_time(self):

		"""
		Returns the most recent timestamp from the list of search messages.
		"""

		return self.lastts
	
	def get_last_id(self):

		"""
		Returns the id of most recent search message in the list
		"""

		return self.lastid

class SearchUser(object):
	def __init__(self, id='', screen_name='', profile_image_url='', description='', location='', name='', protected='', url='', source=''):
		self.Type = 'Search User'
		self.id = id
		self.user_id = self.id
		self.screen_name = screen_name
		self.profile_image_url = profile_image_url
		self.description = description
		self.location = location
		self.name = name
		self.protected = protected
		self.url = url


class TrendMsg:

	"""A trend message"""

	def __init__(self, msg=None):

		"""
		Initialise the trend message. If msg is given and is a dict
		containing the fields which Twitter returns about a trend
		message, the object's fields ares populated with that data.
		"""

		if msg:
			self.Type = 'Trend Message'
			self.set(msg)

	def old___str__(self):
	
		"""
		Return a string representation of a trend message of the form:
		[id] sender -> recipient: message (date)
		"""

		string = ""
		try:
			# Sure takes a lot to do UTC -> local time...
			utc = time.mktime(time.strptime(
				"%s UTC" % self.created_at,
				"%a %b %d %H:%M:%S +0000 %Y %Z"))
			stamp = time.strftime("%a %b %d %H:%M:%S %Y",
					time.localtime(utc))

			string = "[%d] %s -> %s: %s (%s)" % (self.id,
							self.sender.name,
							self.recipient.name,
							self.text,
							stamp)
		except AttributeError, e:
			print >>sys.stderr, e
		return string

	def set(self, msg):

		"""
		Populate the object fields with data from the msg argument.
		The msg dict must provide the fields which Twitter returns
		in its trend message structures.
		"""

		self.id = ''
		self.message_id = self.id
		self.created_at = ''
		self.source = ''
		self.url = msg[u'url']
		self.name = msg[u'name']
		self.text = ''
		# self.user = TrendUser(url=self.url)
		self.user = None

	def load_json(self, s):

		"""Populate this object with data from JSON encoded string s"""

		if s:
			jsobj = simplejson.loads(s)
			self.set(jsobj)


class TrendList(list):

	"""A list of trend messages"""

	def __init__(self, json=None):

		"""
		Initialise a list of trend messages. If the json parameter is
		given and is a JSON encoded string containing a list of trend
		messages encoded as JSON, the list will be populated with
		TrendMsg objects.
		"""

		self.error = False
		self.lastts = ""
		self.lastid = 0
		if json is not None:
			try:
				# self.jsobj = simplejson.loads(json)
				self.jsobj = json
			except ValueError:
				self.error = True
				self.jsobj = []

			for i in self.jsobj:
				self.append(TrendMsg(i))
			if len(self) > 0: pass
				# self.lastts = self[0].created_at
				# self.lastid = self[0].id

	def get_last_time(self):

		"""
		Returns the most recent timestamp from the list of trend messages.
		"""

		return self.lastts
	
	def get_last_id(self):

		"""
		Returns the id of most recent trend message in the list
		"""

		return self.lastid




class TrendUser(object):
	def __init__(self, id='', screen_name='', profile_image_url='', description='', location='', name='', protected='', url='', source=''):
		self.Type = 'Trend User'
		self.id = id
		self.message_id = self.id
		self.screen_name = screen_name
		self.profile_image_url = profile_image_url
		self.description = description
		self.location = location
		self.name = name
		self.protected = protected
		self.source = protected
		self.url = url





