using Microsoft.VisualBasic;
using System;
using System.Text;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

class Program {
static void Main(string[] aArgs) {
string sFile = Interaction.Command();
string sText = File.ReadAllText(sFile, Encoding.Default);
Say(sText);
} // Main method

[DllImport("user32.dll")]
public static extern IntPtr FindWindow(string sClass, string sTitle);

public static bool Say(object oText) {
string sText = oText.ToString();
if (sText.Trim().Length == 0) sText = "Blank";
if (JAWSSay(sText)) return true;
else if (SASay(sText)) return true;
else if (WESay(sText)) return true;
else if (SAPISay(sText)) return true;
else return false;
} // Say method

[DllImport("user32.dll")]
static extern bool SystemParametersInfo(int iAction, int iParam, out bool bActive, int iUpdate);
public static bool IsScreenReaderActive() {
int iAction = 70; // SPI_GETSCREENREADER constant;
int iParam = 0;
bool bActive;
int iUpdate = 0;
bool bReturn = SystemParametersInfo(iAction, iParam, out bActive, iUpdate);
return bReturn && bActive;
} // IsScreenReaderActive method

public static bool IsJAWSActive(){
string sClass = "JFWUI2";
string sTitle = "JAWS";
return (int) FindWindow(sClass, sTitle) != 0;
} // IsJAWSActive method

public static bool IsWinEyesActive(){
string sClass = "GWMExternalControl";
string sTitle = "External Control";
return (int) FindWindow(sClass, sTitle) != 0;
} // IsWinEyesActive method

[DllImport("jfwapi.dll")]
public static extern int JFWRunFunction(string sText);

[DllImport("jfwapi.dll")]
public static extern int JFWRunScript(string sText);

public static bool JAWSSay(string sText) {
if (JFWSay(sText)) return true;
else if (!IsJAWSActive()) return false;
else return false;
} // JAWSSay method

[DllImport("jfwapi.dll")]
public static extern int JFWSayString(string sText, int iInterrupt);

public static bool JFWSay(string sText) {
try {
return JFWSayString(sText, 0) == 1;
}
catch {
return false;
}
} // JFWSay method

[DllImport("saapi32.dll")]
public static extern int SA_IsRunning();

public static bool IsSAActive() {
try {
return SA_IsRunning() == 1;
}
catch {
return false;
}
} // IsSAActive method

[DllImport("saapi32.dll")]
public static extern int SA_SayU(string sText);

public static bool SASay(string sText) {
try {
return SA_SayU(sText) == 1;
}
catch {
return false;
}
} // SASay method

public static bool WESay(string sText) {
if (!IsWinEyesActive()) return false;
try {
object oWE = Interaction.CreateObject(null, "WindowEyes.Application");
object oSpeech = GetProperty(oWE, "Speech");
CallMethod(oSpeech, "Speak", sText);
return true;
}
catch {
try {
object oWE = Interaction.CreateObject(null, "GwSpeak.Speak");
CallMethod(oWE, "SpeakString", sText);
return true;
}
catch {
return false;
}
}
} // WESay method

public static bool SAPISay(string sText) {
try {
object oSAPI = Interaction.CreateObject(null, "SAPI.SPVoice");
CallMethod(oSAPI, "Speak", sText);
return true;
}
catch {
return false;
}
} // SAPISay method

public static object GetProperty(object o, string sProperty) {
object[] args = new object[] {};
return GetProperty(o, sProperty, args);
} // GetProperty method

public static object GetProperty(object o, string sProperty, object[] args) {
Type t = o.GetType();
object oResult = t.InvokeMember(sProperty, BindingFlags.GetProperty, null, o, args);
return oResult;
} // GetProperty method

public static object CallMethod(object o, string sMethod, string sValue) {
object[] args = {sValue};
return CallMethod(o, sMethod, args);
} // CallMethod method

public static object CallMethod(object o, string sMethod, int iValue) {
object[] args = {iValue};
return CallMethod(o, sMethod, args);
} // CallMethod method

public static object CallMethod(object o, string sMethod, object[] args) {
Type t = o.GetType();
object oResult = t.InvokeMember(sMethod, BindingFlags.InvokeMethod, null, o, args);
return oResult;
} // CallMethod method
} // Program class

