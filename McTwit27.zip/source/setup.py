from distutils.core import setup
import py2exe

setup(
    options = {"py2exe": {"compressed": 1,
                          "optimize": 2,
                          "bundle_files": 3}},
    zipfile = None,
    version = "2.0",
    description = "Dialog for using twitter.com",
    name = "McTwit",

    windows = ["McTwit.py"],
    console = ["McTwitC.py"],
    )
